using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [FacilityLocationNetwork]
	/// </summary>
	[SPAutoGen("usp_GetFacilityLocationNetworksByNetwork","SelectAllByGivenArgs.sptpl","networkID")]
	[SPAutoGen("usp_GetFacilityLocationNetworksByFacilityLocation","SelectAllByGivenArgs.sptpl","facilityLocationID")]
	[SPInsert("usp_InsertFacilityLocationNetworkLink")]
	[SPUpdate("usp_UpdateFacilityLocationNetworkLink")]
	[SPDelete("usp_DeleteFacilityLocationNetworkLink")]
	[SPLoad("usp_LoadFacilityLocationNetworkLink")]
	[TableMapping("FacilityLocationNetwork","facilityLocationNetworkID")]
	public class FacilityLocationNetworkLink : BaseData
	{
		[NonSerialized]
		private FacilityLocationNetworkLinkCollection parentFacilityLocationNetworkLinkCollection;
		[ColumnMapping("FacilityLocationNetworkID",(int)0)]
		private int facilityLocationNetworkID;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("NetworkID",StereoType=DataStereoType.FK)]
		private int networkID;
		[ColumnMapping("FacilityLocationID",(int)0)]
		private int facilityLocationID;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
		[ColumnMapping("AlternateID")]
		private string alternateID;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		private FacilityLocationNetworkHistoryCollection effectiveDatesHistory;
		private DateTime terminatedTimeWhenLoaded;
		private FacilityLocation facilityLocation;

		public FacilityLocationNetworkLink()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)-1)]
		public int FacilityLocationNetworkID
		{
			get { return this.facilityLocationNetworkID; }
			set { this.facilityLocationNetworkID = value; }
		}
		
		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)-1)]
		public int Code
		{
			get { return this.facilityLocationNetworkID ; }
			//set { this.providerLocationNetworkID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)-1)]
		public string Description
		{
			get { return this.NetworkName;  }
			//set { this.NetworkName = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int,ValueForNull=0, IsRequired=true)]
		public int NetworkID
		{
			get { return this.networkID; }
			set { this.networkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int FacilityLocationID
		{
			get { return this.facilityLocationID; }
			set { this.facilityLocationID = value; }
		}
		
		public string NetworkType
		{
			get 
			{
				Network		net		= new Network();
				net.Load(this.NetworkID);
				NetworkType netType = new NetworkType();
				netType.Load(net.TypeID);
				return netType.Description;
			}
		}
		
		public string NetworkAddress
		{
			get 
			{
				Network net = new Network();
				Address addr = new Address();
				net.Load(this.NetworkID);
				addr.Load(net.AddressID);
				return addr.ToString();
			}
		}
		public string NetworkName
		{
			get 
			{ 
				Network net = new Network();
				net.Load (this.NetworkID);
				return net.Name;
			}
		}

		
		[FieldValuesMember("LookupOf_NetwokSearchID","NetworkID","Name")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		[FieldDescription("@NETWORKID@")]
		public int NetwokSearchID
		{
			get { return this.networkID; }
			set { this.networkID = value; }
		}

		
		public NetworkCollection LookupOf_NetwokSearchID
		{
			get
			{
				NetworkCollection netCol = new NetworkCollection();
				netCol.GetAllNetworks(-1);
				return netCol;
			}
		}
		public void New()
		{
			this.ModifiedBy = 1;
			//this.CreatedBy  = 1;
			//this.TerminatedBy = 1;
			//this.TerminateTime = DateTime.Now;
			this.active		= true;
			this.asOfDate	= DateTime.Now;
			this.NewRecord(); // initialize record state
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}
		
		public int FacilityID
		{
			get 
			{
				FacilityLocation facNet = new FacilityLocation ();
				facNet.Load(facilityLocationID);
				return facNet.FacilityID;
			}
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// track the change of statusID.
			this.terminatedTimeWhenLoaded = this.terminateTime;
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				if ((this.terminateTime != DateTime.MinValue) || (this.terminateTime != this.terminatedTimeWhenLoaded))
				{
					// status changed.
					this.SetTerminatingUser();
				}

				base.Save();
				if (this.EffectiveDatesHistory != null)
					this.SaveEffectiveDatesHistory();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int facilityLocationNetworkID)
		{
			return base.Load(facilityLocationNetworkID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int facilityLocationNetworkID)
		{
			base.Delete(facilityLocationNetworkID);		
		}

		/// <summary>
		/// Parent FacilityLocationNetworkLinkCollection that contains this element
		/// </summary>
		public FacilityLocationNetworkLinkCollection ParentFacilityLocationNetworkLinkCollection
		{
			get
			{
				return this.parentFacilityLocationNetworkLinkCollection;
			}
			set
			{
				this.parentFacilityLocationNetworkLinkCollection = value; // parent is set when added to a collection
			}
		}

		
		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string AlternateID
		{
			get { return this.alternateID; }
			set { this.alternateID = value; }
		}
		
		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}
		
		/// <summary>
		/// Child EffectiveDatesHistory mapped to related rows of table ProviderLocationNetworkHistory where [ProviderLocationNetworkID] = [ProviderLocationNetworkID]
		/// </summary>
		[SPLoadChild("usp_LoadFacilityLocationNetworkLinkHistory", "facilityLocationNetworkID")]
		public FacilityLocationNetworkHistoryCollection EffectiveDatesHistory
		{
			get { return this.effectiveDatesHistory; }
			set
			{
				this.effectiveDatesHistory  = value;
				if (value != null)
				{
					value.ParentFacilityLocationNetworkLink = this; // set this as a parent of the child collection

				}	
			}
		}
	

		/// <summary>
		/// Loads the EffectiveDatesHistory collection
		/// </summary>
		public void LoadEffectiveDatesHistory(bool forceReload)
		{
			if (this.effectiveDatesHistory != null)
				this.effectiveDatesHistory.Clear();
			this.effectiveDatesHistory = (FacilityLocationNetworkHistoryCollection)FacilityLocationNetworkHistoryCollection.LoadChildCollection("EffectiveDatesHistory", this, typeof(FacilityLocationNetworkHistoryCollection), effectiveDatesHistory, forceReload, null);
		}

		/// <summary>
		/// Saves the EffectiveDatesHistory collection
		/// </summary>
		public void SaveEffectiveDatesHistory()
		{
			FacilityLocationNetworkHistoryCollection.SaveChildCollection(this.effectiveDatesHistory, true);
		}

		/// <summary>
		/// Synchronizes the EffectiveDatesHistory collection
		/// </summary>
		public void SynchronizeEffectiveDatesHistory()
		{
			FacilityLocationNetworkHistoryCollection.SynchronizeChildCollection(this.effectiveDatesHistory, true);
		}

		public FacilityLocation FacilityLocation
		{
			get
			{
				if(this.facilityLocationID == 0)
					return null;
				if(this.facilityLocation == null)
				{
					facilityLocation = new FacilityLocation();
					facilityLocation.Load(facilityLocationID);
				}
				return facilityLocation;
			}
		}
	}
	
	/// <summary>
	/// Strongly typed collection of FacilityLocationNetworkLink objects
	/// </summary>
	[ElementType(typeof(FacilityLocationNetworkLink))]
	public class FacilityLocationNetworkLinkCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(FacilityLocationNetworkLink elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentFacilityLocationNetworkLinkCollection = this;
			else
				elem.ParentFacilityLocationNetworkLinkCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (FacilityLocationNetworkLink elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public FacilityLocationNetworkLink this[int index]
		{
			get
			{
				return (FacilityLocationNetworkLink)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((FacilityLocationNetworkLink)oldValue, false);
			SetParentOnElem((FacilityLocationNetworkLink)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(FacilityLocationNetworkLink elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((FacilityLocationNetworkLink)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(FacilityLocationNetworkLink elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((FacilityLocationNetworkLink)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Parent Network that contains this collection
		/// </summary>
		public Network ParentNetwork
		{
			get { return this.ParentDataObject as Network; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Network */ }
		}

		/// <summary>
		/// Parent FacilityLocation that contains this collection
		/// </summary>
		public FacilityLocation ParentFacilityLocation
		{
			get { return this.ParentDataObject as FacilityLocation; }
			set { this.ParentDataObject = value; /* parent is set when contained by a FacilityLocation */ }
		}
	}
}
