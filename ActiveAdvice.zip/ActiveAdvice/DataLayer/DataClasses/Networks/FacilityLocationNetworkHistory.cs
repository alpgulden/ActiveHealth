using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	/// <summary>
	/// Data class that wraps the entity access functionality to table [FacilityLocationNetworkHistory]
	/// </summary>
	
	[SPInsert("usp_InsertFacilityLocationNetworkHistory")]
	[SPUpdate("usp_UpdateFacilityLocationNetworkHistory")]
	[SPDelete("usp_DeleteFacilityLocationNetworkHistory")]
	[SPLoad("usp_LoadFacilityLocationNetworkHistory")]
	[TableMapping("FacilityLocationNetworkHistory","FacilityLocationNetworkHistoryID")]
	public class FacilityLocationNetworkHistory : BaseData
	{
		[NonSerialized]
		private FacilityLocationNetworkHistoryCollection parentFacilityLocationNetworkHistoryCollection;
		[ColumnMapping("FacilityLocationNetworkHistoryID")]
		private int facilityLocationNetworkHistoryID;
		[ColumnMapping("FacilityLocationNetworkID")]
		private int facilityLocationNetworkID;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[ColumnMapping("Active")]
		private bool active;
		private DateTime terminatedTimeWhenLoaded;

		public FacilityLocationNetworkHistory()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int FacilityLocationNetworkHistoryID
		{
			get { return this.facilityLocationNetworkHistoryID; }
			set { this.facilityLocationNetworkHistoryID = value; }
		}	
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int FacilityLocationNetworkID
		{
			get { return this.facilityLocationNetworkID; }
			set { this.facilityLocationNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}
		
		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}
		
		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();	
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created

			if ((this.terminateTime != DateTime.MinValue) || (this.terminateTime != this.terminatedTimeWhenLoaded))
			{
				// status changed.
				this.SetTerminatingUser();
			}

			base.InternalSave();
			// Save the child collections here.
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// track the change of statusID.
			this.terminatedTimeWhenLoaded = this.terminateTime;
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				if ((this.terminateTime != DateTime.MinValue) || (this.terminateTime != this.terminatedTimeWhenLoaded))
				{
					// status changed.
					this.SetTerminatingUser();
				}

				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load()
		{
			return base.Load(facilityLocationNetworkHistoryID);
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public void Delete(int facilityLocationNetworkHistoryID)
		{
			base.Delete(facilityLocationNetworkHistoryID);
		}

		/// <summary>
		/// Parent GroupPracticeLocationNetworkHistoryCollection that contains this element
		/// </summary>
		public FacilityLocationNetworkHistoryCollection ParentFacilityLocationNetworkHistoryCollection
		{
			get
			{
				return this.parentFacilityLocationNetworkHistoryCollection;
			}
			set
			{
				this.parentFacilityLocationNetworkHistoryCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Reads the object from the given source data reader
		/// </summary>
		public bool Read(System.Data.SqlClient.SqlDataReader sourceReader)
		{
			return SqlData.ReadObj(sourceReader, this, true, false);
		}

		
		/// <summary>
		/// Updates/Inserts/Deletes/Loads a record depending on its status flags.
		/// </summary>
		public new void Synchronize()
		{
			base.Synchronize();		
		}
		
		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			//this.TerminatedBy = 1;
			//this.TerminateTime = DateTime.Now;
			this.NewRecord(); // initialize record state

		}

	}

	/// <summary>
	/// Strongly typed collection of FacilityLocationNetworkHistory objects
	/// </summary>
	[ElementType(typeof(FacilityLocationNetworkHistory))]
	public class FacilityLocationNetworkHistoryCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
			
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(FacilityLocationNetworkHistory elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentFacilityLocationNetworkHistoryCollection = this;
			else
				elem.ParentFacilityLocationNetworkHistoryCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (FacilityLocationNetworkHistory elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}
		
		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public FacilityLocationNetworkHistory this[int index]
		{
			get
			{
				return ( FacilityLocationNetworkHistory )List[index];
			}
			set
			{
				List[index] = value;
			}
		}
		
		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((FacilityLocationNetworkHistory)oldValue, false);
			SetParentOnElem((FacilityLocationNetworkHistory)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, FacilityLocationNetworkHistory elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((FacilityLocationNetworkHistory)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(FacilityLocationNetworkHistory elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(FacilityLocationNetworkHistory elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((FacilityLocationNetworkHistory)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Update the Status for GroupPractice Location Network table for the given groupPracticeLocationNetworkID based on the effective and Termination dates.
		/// </summary>
		public int UpdateStatusForFacilityLocationNetworkHistory(int maxRecords, FacilityLocationNetworkHistory facilityLocationNetworkhistory,int facilityLocationNetworkID)
		{
			this.Clear();
			return SqlData.SPExecNonQuery("usp_UpdateStatusForFacilityLocationNetworkHistory",facilityLocationNetworkhistory,false,
				new string[] { "facilityLocationNetworkID" },
				new object[] { facilityLocationNetworkID } );
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}
		
		/* Don't use this.  It was using Dynamic SQL!
		/// <summary>
		/// Executes an SQL statement and fills the collection with the mapped columns of the result
		/// </summary>
		public int ExecuteSQL( object param)
		{
			SQLParser sql = new SQLParser("select * from [FacilityLocationNetworkHistory] " +
				"");  //"where param=@param");
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForQuery(sql);
			//sd.SQLCommand.Parameters["@param"].Value = param;
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/
		
		/// <summary>
		/// Parent FacilityLocationNetworkLink that contains this collection
		/// </summary>
		public FacilityLocationNetworkLink ParentFacilityLocationNetworkLink
		{
			get { return this.ParentDataObject as FacilityLocationNetworkLink; }
			set { this.ParentDataObject = value; /* parent is set when contained by a FacilityLocationNetworkLink */ }
		}

		/// <summary>
		/// Calls Synchronize methods of all collection elements.
		/// </summary>
		public void Synchronize()
		{
			this.SynchronizeElements();		
		}
		
		/// <summary>
		/// Accessor to a shared GroupPracticeLocationNetworkHistoryCollection which is cached in NSGlobal
		/// </summary>
		public static FacilityLocationNetworkHistoryCollection FacilityLocationNetworkHistories
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				FacilityLocationNetworkHistoryCollection col = (FacilityLocationNetworkHistoryCollection)NSGlobal.EnsureCachedObject("FacilityLocationNetworkHistories", typeof(FacilityLocationNetworkHistoryCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
				}
				return col;
			}
			
		}

		/// <summary>
		/// Reads a max number of records from the given data reader and fills the collection. If maxRecords is negative, all records will be read.
		/// </summary>
		public int Read(System.Data.SqlClient.SqlDataReader sourceReader, int maxRecords)
		{
			return base.Read(sourceReader, maxRecords, false);
		}
	}
}
