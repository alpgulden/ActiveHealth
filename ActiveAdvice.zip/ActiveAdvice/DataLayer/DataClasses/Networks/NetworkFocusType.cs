using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [NetworkFocusTypes]
	/// </summary>
	[SPAutoGen("usp_GetAllNetworkFocusTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetNetworkFocusTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertNetworkFocusType")]
	[SPUpdate("usp_UpdateNetworkFocusType")]
	[SPDelete("usp_DeleteNetworkFocusType")]
	[SPLoad("usp_LoadNetworkFocusType")]
	[TableMapping("NetworkFocusType","networkFocusTypeID")]
	public class NetworkFocusType : BaseLookupWithCode
	{
		[NonSerialized]
		private NetworkFocusTypeCollection parentNetworkFocusTypeCollection;
		[ColumnMapping("NetworkFocusTypeID",(int)0)]
		private int networkFocusTypeID;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;

	
		public NetworkFocusType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)-1)]
		public int NetworkFocusTypeID
		{
			get { return this.networkFocusTypeID; }
			set { this.networkFocusTypeID = value; }
		}

		

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int networkFocusTypeID)
		{
			return base.Load(networkFocusTypeID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int networkFocusTypeID)
		{
			base.Delete(networkFocusTypeID);		
		}

		/// <summary>
		/// Parent NetworkFocusTypeCollection that contains this element
		/// </summary>
		public NetworkFocusTypeCollection ParentNetworkFocusTypeCollection
		{
			get
			{
				return this.parentNetworkFocusTypeCollection;
			}
			set
			{
				this.parentNetworkFocusTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of NetworkFocusType objects
	/// </summary>
	[ElementType(typeof(NetworkFocusType))]
	public class NetworkFocusTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(NetworkFocusType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentNetworkFocusTypeCollection = this;
			else
				elem.ParentNetworkFocusTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (NetworkFocusType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public NetworkFocusType this[int index]
		{
			get
			{
				return (NetworkFocusType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((NetworkFocusType)oldValue, false);
			SetParentOnElem((NetworkFocusType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(NetworkFocusType elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((NetworkFocusType)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Returns true if the collection contains the given object
		/// </summary>
		public bool Contains(NetworkFocusType elem)
		{
			return List.Contains(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(NetworkFocusType elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((NetworkFocusType)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}



		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadNetworkFocusTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetNetworkFocusTypesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared NetworkFocusTypeCollection which is cached in NSGlobal
		/// </summary>
		public static NetworkFocusTypeCollection ActiveNetworkFocusTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				NetworkFocusTypeCollection col = (NetworkFocusTypeCollection)NSGlobal.EnsureCachedObject("ActiveNetworkFocusTypes", typeof(NetworkFocusTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadNetworkFocusTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		///  Load all Network Focus Types.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			SqlData.SPExecReadCol("usp_GetAllNetworkFocusTypes", -1, this, false);
		}

		/// <summary>
		/// Searches for Network Focus Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchNetworkFocusTypes", -1, this, false, code, description, active);
		}
	}
}
