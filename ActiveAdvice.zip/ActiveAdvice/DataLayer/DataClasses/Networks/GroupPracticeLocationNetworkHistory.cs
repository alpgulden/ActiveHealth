using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	/// <summary>
	/// Data class that wraps the entity access functionality to table [GroupPracticeLocationNetworkHistory]
	/// </summary>
	[SPInsert("usp_InsertGroupPracticeLocationNetworkHistory")]
	[SPUpdate("usp_UpdateGroupPracticeLocationNetworkHistory")]
	[SPDelete("usp_DeleteGroupPracticeLocationNetworkHistory")]
	[SPLoad("usp_LoadGroupPracticeLocationNetworkHistory")]
	[TableMapping("GroupPracticeLocationNetworkHistory","GroupPracticeLocationNetworkHistoryID")]

	public class GroupPracticeLocationNetworkHistory : BaseData
	{
		[NonSerialized]
		private GroupPracticeLocationNetworkHistoryCollection parentGroupPracticeLocationNetworkHistoryCollection;
		[ColumnMapping("GroupPracticeLocationNetworkHistoryID")]
		private int groupPracticeLocationNetworkHistoryID;
		[ColumnMapping("GroupPracticeLocationNetworkID")]
		private int groupPracticeLocationNetworkID;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		private DateTime terminatedTimeWhenLoaded;


		public GroupPracticeLocationNetworkHistory()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int GroupPracticeLocationNetworkHistoryID
		{
			get { return this.groupPracticeLocationNetworkHistoryID; }
			set { this.groupPracticeLocationNetworkHistoryID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int GroupPracticeLocationNetworkID
		{
			get { return this.groupPracticeLocationNetworkID; }
			set { this.groupPracticeLocationNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}
		
		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// track the change of statusID.
			this.terminatedTimeWhenLoaded = this.terminateTime;
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				if ((this.terminateTime != DateTime.MinValue) || (this.terminateTime != this.terminatedTimeWhenLoaded))
				{
					// status changed.
					this.SetTerminatingUser();
				}
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int groupPracticeLocationNetworkHistoryID)
		{
			return base.Load(groupPracticeLocationNetworkHistoryID);
		}
		
		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int groupPracticeLocationNetworkHistoryID)
		{
			base.Delete(groupPracticeLocationNetworkHistoryID);
		}

	
		/// <summary>
		/// Parent GroupPracticeLocationNetworkHistoryCollection that contains this element
		/// </summary>
		public GroupPracticeLocationNetworkHistoryCollection ParentGroupPracticeLocationNetworkHistoryCollection
		{
			get
			{
				return this.parentGroupPracticeLocationNetworkHistoryCollection;
			}
			set
			{
				this.parentGroupPracticeLocationNetworkHistoryCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			//this.TerminatedBy = 1;
			//this.TerminateTime = DateTime.Now;
			this.NewRecord(); // initialize record state

		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			// this.ContainedObject.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			// if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			// {
			//	base.InternalSave();	// in that case, delete the base first
			//	ContainedObject.MarkDel();	// then allow the deletion of the conatined object
			// }
			// ContainedObject.Save();	
			// this.containedObjectFK = ContainedObject.PK; // set the fk if the contained object was newly created

			if ((this.terminateTime != DateTime.MinValue) || (this.terminateTime != this.terminatedTimeWhenLoaded))
			{
				// status changed.
				this.SetTerminatingUser();
			}

			base.InternalSave();
			// Save the child collections here.
		}
	}

	/// <summary>
	/// Strongly typed collection of GroupPracticeLocationNetworkHistory objects
	/// </summary>
	[ElementType(typeof(GroupPracticeLocationNetworkHistory))]
	public class GroupPracticeLocationNetworkHistoryCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(GroupPracticeLocationNetworkHistory elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentGroupPracticeLocationNetworkHistoryCollection = this;
			else
				elem.ParentGroupPracticeLocationNetworkHistoryCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (GroupPracticeLocationNetworkHistory elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public GroupPracticeLocationNetworkHistory this[int index]
		{
			get
			{
				return (GroupPracticeLocationNetworkHistory)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((GroupPracticeLocationNetworkHistory)oldValue, false);
			SetParentOnElem((GroupPracticeLocationNetworkHistory)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, GroupPracticeLocationNetworkHistory elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeLocationNetworkHistory)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(GroupPracticeLocationNetworkHistory elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(GroupPracticeLocationNetworkHistory elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((GroupPracticeLocationNetworkHistory)value, false);
			base.OnRemoveComplete (index, value);		
		}
		

		/// <summary>
		/// Update the Status for GroupPractice Location Network table for the given groupPracticeLocationNetworkID based on the effective and Termination dates.
		/// </summary>
		public int UpdateStatusForGroupPracticeLocationNetworkHistory(int maxRecords, GroupPracticeLocationNetworkHistory gpLocationNetworkhistory,int gpLocationNetworkID)
		{
			this.Clear();
			return SqlData.SPExecNonQuery("usp_UpdateStatusForGroupPracticeLocationNetworkHistory",gpLocationNetworkhistory,false,
				new string[] { "groupPracticeLocationNetworkID" },
				new object[] { gpLocationNetworkID } );
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}
		
		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();
			//UpdateStatusForProviderLocationNetworkHistory
			
		}
		
		/* Don't use this.  It was using Dynamic SQL!
		/// <summary>
		/// Executes an SQL statement and fills the collection with the mapped columns of the result
		/// </summary>
		public int ExecuteSQL( object param)
		{
			SQLParser sql = new SQLParser("select * from [GroupPracticeLocationNetworkHistory] " +
				"");  //"where param=@param");
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForQuery(sql);
			//sd.SQLCommand.Parameters["@param"].Value = param;
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/
		
		/// <summary>
		/// Parent GroupPracticeLocationNetworkLink that contains this collection
		/// </summary>
		public GroupPracticeLocationNetworkLink ParentGroupPracticeLocationNetworkLink
		{
			get { return this.ParentDataObject as GroupPracticeLocationNetworkLink; }
			set { this.ParentDataObject = value; /* parent is set when contained by a GroupPracticeLocationNetworkLink */ }
		}

		/// <summary>
		/// Accessor to a shared GroupPracticeLocationNetworkHistoryCollection which is cached in NSGlobal
		/// </summary>
		public static GroupPracticeLocationNetworkHistoryCollection GroupPracticeLocationNetworkHistories
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				GroupPracticeLocationNetworkHistoryCollection col = (GroupPracticeLocationNetworkHistoryCollection)NSGlobal.EnsureCachedObject("GroupPracticeLocationNetworkHistories", typeof(GroupPracticeLocationNetworkHistoryCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
				}
				return col;
			}
			
		}
	}
}
