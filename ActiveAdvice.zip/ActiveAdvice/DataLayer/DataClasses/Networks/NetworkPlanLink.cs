using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [NetworkPlans]
	/// </summary>
	[SPAutoGen("usp_GetNetworkPlanLinkByPlanIDNetworkID","SelectAllByGivenArgs.sptpl","planId, networkID")]
	[SPInsert("usp_InsertNetworkPlanLink")]
	[SPUpdate("usp_UpdateNetworkPlanLink")]
	[SPDelete("usp_DeleteNetworkPlanLink")]
	[SPLoad("usp_LoadNetworkPlanLink")]
	[TableMapping("NetworkPlan","networkPlanID")]
	public class NetworkPlanLink : BaseData
	{
		[NonSerialized]
		private NetworkPlanLinkCollection parentNetworkPlanLinkCollection;
		[ColumnMapping("NetworkPlanID",(int)0)]
		private int networkPlanID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("NoteID",(int)0)]
		private int noteID;
		[ColumnMapping("PreferenceLevel",(int)0)]
		private int preferenceLevel;
		[ColumnMapping("StartDate")]
		private DateTime startDate;
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("NetworkID",(int)0)]
		private int networkID;
		[ColumnMapping("PlanId",(int)0)]
		private int planId;
		[ColumnMapping("CreatedBy",(int)0)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",(int)0)]
		private int modifiedBy;
		[ColumnMapping("Active")]
		private bool active;
		private NetworkPlanHistoryCollection effectiveDatesHistory;

		public NetworkPlanLink()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int NetworkPlanID
		{
			get { return this.networkPlanID; }
			set { this.networkPlanID = value;}
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=100)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int NoteID
		{
			get { return this.noteID; }
			set { this.noteID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PreferenceLevel
		{
			get { return this.preferenceLevel; }
			set { this.preferenceLevel = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate,IsRequired=true)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int NetworkID
		{
			get { return this.networkID; }
			set { this.networkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PlanId
		{
			get { return this.planId; }
			set { this.planId = value; }
		}
		
		/// <summary>
		/// Child EffectiveDatesHistory mapped to related rows of table ProviderLocationNetworkHistory where [ProviderLocationNetworkID] = [ProviderLocationNetworkID]
		/// </summary>
		[SPLoadChild("usp_LoadNetworkPlanLinkHistory", "NetworkPlanID")]
		public NetworkPlanHistoryCollection EffectiveDatesHistory
		{
			get { return this.effectiveDatesHistory ; }
			set
			{
				this.effectiveDatesHistory  = value;
				if (value != null)
				{
					value.ParentNetworkPlanLink = this; // set this as a parent of the child collection

				}	
			}
		}
	

		/// <summary>
		/// Loads the EffectiveDatesHistory collection
		/// </summary>
		public void LoadEffectiveDatesHistory(bool forceReload)
		{
			if (this.effectiveDatesHistory != null)
				this.effectiveDatesHistory.Clear();
			this.effectiveDatesHistory = (NetworkPlanHistoryCollection)NetworkPlanHistoryCollection.LoadChildCollection("EffectiveDatesHistory", this, typeof(NetworkPlanHistoryCollection), effectiveDatesHistory, forceReload, null);
		}

		/// <summary>
		/// Saves the EffectiveDatesHistory collection
		/// </summary>
		public void SaveEffectiveDatesHistory()
		{
			NetworkPlanHistoryCollection.SaveChildCollection(this.effectiveDatesHistory, true);
		}

		/// <summary>
		/// Synchronizes the EffectiveDatesHistory collection
		/// </summary>
		public void SynchronizeEffectiveDatesHistory()
		{
			FacilityLocationNetworkHistoryCollection.SynchronizeChildCollection(this.effectiveDatesHistory, true);
		}






		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int networkPlanID)
		{
			return base.Load(networkPlanID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int networkPlanID)
		{
			base.Delete(networkPlanID);		
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			this.asOfDate	= DateTime.Now;
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state
		}

		/// <summary>
		/// Parent NetworkPlanLinkCollection that contains this element
		/// </summary>
		public NetworkPlanLinkCollection ParentNetworkPlanLinkCollection
		{
			get
			{
				return this.parentNetworkPlanLinkCollection;
			}
			set
			{
				this.parentNetworkPlanLinkCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public bool LoadNetworkPlanLinkByPlanIDNetworkID(int planId, int networkID)
		{
			return SqlData.SPExecReadObj("usp_GetNetworkPlanLinkByPlanIDNetworkID", this, false, new object[] { planId, networkID });
		}
	}

	/// <summary>
	/// Strongly typed collection of NetworkPlanLink objects
	/// </summary>
	[ElementType(typeof(NetworkPlanLink))]
	public class NetworkPlanLinkCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(NetworkPlanLink elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentNetworkPlanLinkCollection = this;
			else
				elem.ParentNetworkPlanLinkCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (NetworkPlanLink elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public NetworkPlanLink this[int index]
		{
			get
			{
				return (NetworkPlanLink)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((NetworkPlanLink)oldValue, false);
			SetParentOnElem((NetworkPlanLink)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(NetworkPlanLink elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((NetworkPlanLink)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(NetworkPlanLink elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((NetworkPlanLink)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Parent Network that contains this collection
		/// </summary>
		public Network ParentNetwork
		{
			get { return this.ParentDataObject as Network; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Network */ }
		}
	}
}
