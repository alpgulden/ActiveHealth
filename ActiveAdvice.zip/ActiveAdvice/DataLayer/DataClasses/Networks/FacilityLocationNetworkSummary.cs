using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for FacilityLocationNetworkSummary.
	/// </summary>
	[TableMapping(null,"FacilityLocationNetworkID")]
	public class FacilityLocationNetworkSummary:BaseData
	{
		[NonSerialized]
		private FacilityLocationNetworkSummaryCollection parentFacilityLocationNetworkSummaryCollection;
		[ColumnMapping("AddressID",StereoType=DataStereoType.FK)]
		private int addressID;
		[ColumnMapping("Line1")]
		private string line1;
		[ColumnMapping("Line2")]
		private string line2;
		[ColumnMapping("City")]
		private string city;
		[ColumnMapping("State")]
		private string state;
		[ColumnMapping("Zip",StereoType=DataStereoType.USZipCode)]
		private string zip;
		[ColumnMapping("County")]
		private string county;
		[ColumnMapping("Country")]
		private string country;
		[ColumnMapping("FacilityLocationNetworkID",StereoType=DataStereoType.FK)]
		private int facilityLocationNetworkID;
		[ColumnMapping("LocationID",StereoType=DataStereoType.FK)]
		private int locationID;
		[ColumnMapping("AlternateID")]
		private string alternateID;
	
		public FacilityLocationNetworkSummary()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LocationID
		{
			get { return this.locationID; }
			set { this.locationID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateID
		{
			get { return this.alternateID; }
			set { this.alternateID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int FacilityLocationNetworkID
		{
			get { return this.facilityLocationNetworkID; }
			set { this.facilityLocationNetworkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AddressID
		{
			get { return this.addressID; }
			set { this.addressID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Line1
		{
			get { return this.line1; }
			set { this.line1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Line2
		{
			get { return this.line2; }
			set { this.line2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string City
		{
			get { return this.city; }
			set { this.city = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2)]
		public string State
		{
			get { return this.state; }
			set { this.state = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.USZipCode, MaxLength=10)]
		public string Zip
		{
			get { return this.zip; }
			set { this.zip = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string County
		{
			get { return this.county; }
			set { this.county = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string Country
		{
			get { return this.country; }
			set { this.country = value; }
		}
		public  string Address
		{
			get
			{
				return
					this.line1 + "\r\n" +
					this.line2 + "\r\n" + 
					this.City + ", " + this.County + ", " + this.State + ", " + this.Zip + "\r\n" +
					this.Country  ;
			}
		}
		/// <summary>
		/// Parent FacilityLocationNetworkSummaryCollection that contains this element
		/// </summary>
		public FacilityLocationNetworkSummaryCollection ParentFacilityLocationNetworkSummaryCollection
		{
			get
			{
				return this.parentFacilityLocationNetworkSummaryCollection;
			}
			set
			{
				this.parentFacilityLocationNetworkSummaryCollection = value; // parent is set when added to a collection
			}
		}

		

	}

	/// <summary>
	/// Strongly typed collection of FacilityLocationNetworkSummary objects
	/// </summary>
	[ElementType(typeof(FacilityLocationNetworkSummary))]
	public class FacilityLocationNetworkSummaryCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		public int LoadFacilityLocationNetworkSummary(int maxRecords,int facilityID,int networkID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllFacilityLocationNetworkSummary", maxRecords, this, false,new object[]{facilityID,networkID});
		}

	}
}
