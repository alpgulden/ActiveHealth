using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [NetworkTypes]
	/// </summary>
	[SPAutoGen("usp_SearchNetworkTypes","SelectAllByGivenArgs.sptpl","code, description, active")]
	[SPAutoGen("usp_GetAllNetworkTypes","SelectAll.sptpl","")]
	[SPAutoGen("usp_GetNetworkTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertNetworkType")]
	[SPUpdate("usp_UpdateNetworkType")]
	[SPDelete("usp_DeleteNetworkType")]
	[SPLoad("usp_LoadNetworkType")]
	[TableMapping("NetworkType","networkTypeID")]
	public class NetworkType : BaseLookupWithCode
	{
		[NonSerialized]
		private NetworkTypeCollection parentNetworkTypeCollection;
		[ColumnMapping("NetworkTypeID",(int)0)]
		private int networkTypeID;
		[ColumnMapping("Notepad")]
		private string notepad;
		[ColumnMapping("CreatedBy",(int)0)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",(int)0)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;

	
		public NetworkType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)-1)]
		public int NetworkTypeID
		{
			get { return this.networkTypeID; }
			set { this.networkTypeID = value; }
		}




		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int networkTypeID)
		{
			return base.Load(networkTypeID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int networkTypeID)
		{
			base.Delete(networkTypeID);		
		}

		/// <summary>
		/// Parent NetworkTypeCollection that contains this element
		/// </summary>
		public NetworkTypeCollection ParentNetworkTypeCollection
		{
			get
			{
				return this.parentNetworkTypeCollection;
			}
			set
			{
				this.parentNetworkTypeCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Notepad
		{
			get { return this.notepad; }
			set { this.notepad = value; }
		}


	}

	/// <summary>
	/// Strongly typed collection of NetworkType objects
	/// </summary>
	[ElementType(typeof(NetworkType))]
	public class NetworkTypeCollection : BaseTypeCollection
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(NetworkType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentNetworkTypeCollection = this;
			else
				elem.ParentNetworkTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (NetworkType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public NetworkType this[int index]
		{
			get
			{
				return (NetworkType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((NetworkType)oldValue, false);
			SetParentOnElem((NetworkType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(NetworkType elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((NetworkType)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Returns true if the collection contains the given object
		/// </summary>
		public bool Contains(NetworkType elem)
		{
			return List.Contains(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(NetworkType elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((NetworkType)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadNetworkTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetNetworkTypesByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared NetworkTypeCollection which is cached in NSGlobal
		/// </summary>
		public static NetworkTypeCollection ActiveNetworkTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				NetworkTypeCollection col = (NetworkTypeCollection)NSGlobal.EnsureCachedObject("ActiveNetworkTypes", typeof(NetworkTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadNetworkTypesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		///  Loads all NetworkTypes into collection.
		/// </summary>
		public override void LoadAll()
		{
			this.Clear();
			this.SqlData.SPExecReadCol("usp_GetAllNetworkTypes",-1,this,false,null);
		}

		/// <summary>
		/// Searches for Network Types matching the given criteria.
		/// </summary>
		public override void SearchCodeTypes(string code, string description, bool active)
		{
			SqlData.SPExecReadCol("usp_SearchNetworkTypes", -1, this, false, code, description, active);
		}


	}
}
