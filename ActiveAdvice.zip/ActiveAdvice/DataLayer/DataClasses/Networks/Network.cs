using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Networks]
	/// </summary>
	[SPAutoGen("usp_GetAllNetworksByPlanID","SelectAllNetworksByPlan.sptpl","")]
	[SPExists("usp_ExistsNetwork")]
	[SPAutoGen("usp_GetAllNetworks","SelectAll.sptpl","")]
	//[SPAutoGen("usp_SearchNetworks","SearchNetworks.sptpl","")]
	[SPInsert("usp_InsertNetwork")]
	[SPUpdate("usp_UpdateNetwork")]
	[SPDelete("usp_DeleteNetwork")]
	[SPLoad("usp_LoadNetwork")]
	[TableMapping("Network","networkID")]
	public class Network : BaseDataWithUserDefined
	{
		[NonSerialized]
		private NetworkCollection parentNetworkCollection;
		[ColumnMapping("NetworkID",StereoType=DataStereoType.FK)]
		private int networkID;
		[ColumnMapping("AlternateID")]
		private string alternateID;
		[ColumnMapping("Name")]
		private string name;
		[ColumnMapping("TypeID",StereoType=DataStereoType.FK)]
		private int typeID;
		[ColumnMapping("Email")]
		private string email;
		[ColumnMapping("WebURL")]
		private string webURL;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("Note")]	
		private string note;
		[ColumnMapping("AddressID",StereoType=DataStereoType.FK)]
		private int addressID;
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		private NetworkFocusCollection focuses;
		private GroupPracticeLocationNetworkLinkCollection groupPracticenetworkLinks;
		private GroupPracticeCollection groupPractices;
		private ProviderLocationNetworkLinkCollection providernetworkLinks;
		private ProviderCollection providers;
		private FacilityLocationNetworkLinkCollection facilitynetworkLinks;
		private FacilityCollection facilities;
		private NetworkPlanLinkCollection plannetworkLinks;
		private PlanCollection plans;
		private NetworkContactCollection networkContacts;
		private Address address;
			
		public Network()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		

		public Network(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)-1)]
		[FieldDescription("@NETWORKID@")]
		public int NetworkID
		{
			get { return this.networkID; }
			set { this.networkID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		[FieldDescription("@ALTERNATEID@")]
		public string AlternateID
		{
			get { return this.alternateID; }
			set { this.alternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=50)]
		[FieldDescription("@NETWORKNAME@")]
		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

		[FieldValuesMember("LookupOf_TypeID", "NetworkTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup,IsRequired=true)]
		[FieldDescription("@NETWORKTYPE@")]
		public int TypeID
		{
			get { return this.typeID; }
			set { this.typeID = value; }
		}

		public string NetworkType
		{
			get
			{
				NetworkType netType = new NetworkType();
				netType.Load(this.TypeID);
				return netType.Description;				   
			}
		}

		public ProviderCollection Providers
		{
			set { this.providers  = value; } 
			get { return this.providers; }
		}

		public GroupPracticeCollection GroupPractices
		{
			set { this.groupPractices   = value; } 
			get { return this.groupPractices; }
		}
		
		public FacilityCollection Facilities
		{
			set { this.facilities  = value; } 
			get { return this.facilities ; }
		}

		public PlanCollection Plans
		{
			set { this.plans = value; } 
			get { return this.plans ; }
		}

		public string NetworkAddress
		{
			get 
			{
				Address addr = new Address();
				addr.Load(this.AddressID);
				return addr.ToString();
			}
		}


		[ValidatorMember("vldEmail")]
		[ControlType(Macro=EnumControlTypeMacros.Email, MaxLength=255)]
		[FieldDescription("@EMAIL@")]
		public string Email
		{
			get { return this.email; }
			set { this.email = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=100)]
		[FieldDescription("@WEBURL@")]
		public string WebURL
		{
			get { return this.webURL; }
			set { this.webURL = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		[FieldDescription("@EFFDATE@")]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}


		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@CREATETIME@")]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@CREATEDBY@")]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@MODIFYBY@")]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		[FieldDescription("@NOTE@")]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		/// <summary>
		/// Inserts the object into table
		/// </summary>
		public void Insert()
		{
			InternalInsert();
			OnCompleteSave();		
		}
		
		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			
			if (NetworkID == 0)
				return;
			
			writer.AddFieldsOnNewLine(this, "NetworkID",  "Name");
		}

		/// <summary>
		/// Updates the object into the table
		/// </summary>
		public void Update()
		{
			InternalUpdate();
			OnCompleteSave();		
		}
		
		protected override void InternalSave()
		{
			try
			{
				
				this.Address.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
				if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
				{
					base.InternalSave();	
					// in that case, delete the base first
					Address.MarkDel();	// then allow the deletion of the conatined object
				}
				Address.IsNew = this.IsNew;	// make sure the contained object is new if the containing object is new
				this.Address.Save();
				this.addressID = Address.AddressID; // set the fk if the contained object was newly created

				
				//this.SqlData.EnsureTransaction();
				base.InternalSave();
				//this.LoadLocations(false);
				
//				if (this.ProviderNetworkLinks  != null)
//				{
//					this.providernetworkLinks.SqlData.Transaction = this.SqlData.Transaction;
//					this.ProviderNetworkLinks.Save();
//				}
					
				
				if (this.focuses != null)
					this.SaveFocuses();

				if (this.providernetworkLinks != null)
					this.SaveProviderNetworkLinks();

				if (this.plannetworkLinks != null)
					this.SavePlanNetworkLinks();

				if (this.groupPracticenetworkLinks != null)
					this.SaveGroupPracticeNetworkLinks();

				if (facilitynetworkLinks != null)
					this.SaveFacilityNetworkLinks();

			}
			catch (Exception ex)
			{
				//this.sqlData.RollbackTransaction();
				throw;
			}
		}
			
		

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				//				if (this.focuses != null)
				//					this.SaveFocuses();
				//				if (this.providernetworkLinks != null)
				//					this.SaveProviderNetworkLinks();
				//				if (this.plannetworkLinks != null)
				//					this.SavePlanNetworkLinks();
				//				if (this.groupPracticenetworkLinks != null)
				//					this.SaveGroupPracticeNetworkLinks();
				//				if (this.facilitynetworkLinks != null)
				//					this.SaveFacilityNetworkLinks();
				//
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int networkID)
		{
			return base.Load(networkID);
		}

		/// <summary>
		/// Deletes the object specified by a PK value from table
		/// </summary>
		public void Delete(int networkID)
		{
			base.Delete(networkID);		
		}

		/// <summary>
		/// Child Focuses mapped to related rows of table NetworkFocuses where [NetworkID] = [NetworkID]
		/// </summary>
		[SPLoadChild("usp_LoadNetworkFocuses", "networkID")]
		public NetworkFocusCollection Focuses
		{
			get { return this.focuses; }
			set
			{
				this.focuses = value;
				value.ParentNetwork = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Focuses collection
		/// </summary>
		public void LoadFocuses(bool forceReload)
		{
			this.focuses = (NetworkFocusCollection)NetworkFocusCollection.LoadChildCollection("Focuses", this, typeof(NetworkFocusCollection), focuses, forceReload, null);
		}

		/// <summary>
		/// Saves the Focuses collection
		/// </summary>
		public void SaveFocuses()
		{
			NetworkFocusCollection.SaveChildCollection(this.focuses, true);
		}

		/// <summary>
		/// Synchronizes the Focuses collection
		/// </summary>
		public void SynchronizeFocuses()
		{
			NetworkFocusCollection.SynchronizeChildCollection(this.focuses, true);
		}

		/// <summary>
		/// Child GroupPracticeNetworkLinks mapped to related rows of table GroupPracticeLocationNetworks where [NetworkID] = [NetworkID]
		/// </summary>
		[SPLoadChild("usp_LoadNetworkGroupPracticeLocationNetworks", "networkID")]
		public GroupPracticeLocationNetworkLinkCollection GroupPracticeNetworkLinks
		{
			get { return this.groupPracticenetworkLinks; }
			set
			{
				this.groupPracticenetworkLinks = value;
				value.ParentNetwork = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the GroupPracticeNetworkLinks collection
		/// </summary>
		public void LoadGroupPracticeNetworkLinks(bool forceReload)
		{
			this.groupPracticenetworkLinks = (GroupPracticeLocationNetworkLinkCollection)GroupPracticeLocationNetworkLinkCollection.LoadChildCollection("GroupPracticeNetworkLinks", this, typeof(GroupPracticeLocationNetworkLinkCollection), groupPracticenetworkLinks, forceReload, null);
		}

		/// <summary>
		/// Saves the GroupPracticeNetworkLinks collection
		/// </summary>
		public void SaveGroupPracticeNetworkLinks()
		{
			GroupPracticeLocationNetworkLinkCollection.SaveChildCollection(this.groupPracticenetworkLinks, true);
		}

		/// <summary>
		/// Synchronizes the GroupPracticeNetworkLinks collection
		/// </summary>
		public void SynchronizeGroupPracticeNetworkLinks()
		{
			GroupPracticeLocationNetworkLinkCollection.SynchronizeChildCollection(this.groupPracticenetworkLinks, true);
		}

		/// <summary>
		/// Child ProviderNetworkLinks mapped to related rows of table ProviderLocationNetworks where [NetworkID] = [NetworkID]
		/// </summary>
		[SPLoadChild("usp_LoadNetworkProviderLocationNetworks", "networkID")]
		public ProviderLocationNetworkLinkCollection ProviderNetworkLinks
		{
			get { return this.providernetworkLinks; }
			set
			{
				this.providernetworkLinks = value;
				value.ParentNetwork = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ProviderNetworkLinks collection
		/// </summary>
		public void LoadProviderNetworkLinks(bool forceReload)
		{
			this.providernetworkLinks = (ProviderLocationNetworkLinkCollection)ProviderLocationNetworkLinkCollection.LoadChildCollection("ProviderNetworkLinks", this, typeof(ProviderLocationNetworkLinkCollection), providernetworkLinks, forceReload, null);
		}
		
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public void LoadProviders()
		{
			ProviderCollection gpCol = new ProviderCollection();
			gpCol.SqlData.SPExecReadCol("usp_LoadProviderNetworkLink", -1, gpCol,  true,new object[] { this.networkID } );

			// for all MarkDel GPLink check the group practice ID if matches remove from collection
			for (int j=0; j < gpCol.Count; j++)
			{
				bool removeCurrentGP = true;
				for (int i=0; i < this.ProviderNetworkLinks.Count ; i++)
				{
					if (ProviderNetworkLinks[i].ProviderID == gpCol[j].ProviderID )
					{
						if (ProviderNetworkLinks[i].IsMarkedForDeletion && removeCurrentGP)
							removeCurrentGP = true;
						else
							removeCurrentGP = false;
					}
				}
				if (removeCurrentGP)
					gpCol.MarkDirty(j);
			}

			foreach (Provider gp in gpCol)
			{
				if (gp.IsDirty)
					gpCol.Remove (gp);
			}
			

			this.Providers = gpCol;
		}
		
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public void LoadGroupPractices()
		{
			GroupPracticeCollection gpCol = new GroupPracticeCollection();
			gpCol.SqlData.SPExecReadCol("usp_LoadGPNetworkLink", -1, gpCol,  true,new object[] { this.networkID } );

			// for all MarkDel GPLink check the group practice ID if matches remove from collection
			for (int j=0; j < gpCol.Count; j++)
			{
				bool removeCurrentGP = true;
				for (int i=0; i < this.GroupPracticeNetworkLinks.Count ; i++)
				{
					if (GroupPracticeNetworkLinks[i].GroupPracticeID == gpCol[j].GroupPracticeID )
					{
						if (GroupPracticeNetworkLinks[i].IsMarkedForDeletion && removeCurrentGP)
							removeCurrentGP = true;
						else
							removeCurrentGP = false;
					}
				}
				if (removeCurrentGP)
					gpCol.MarkDirty(j);
			}

			foreach (GroupPractice gp in gpCol)
			{
				if (gp.IsDirty)
					gpCol.Remove (gp);
			}
			

			this.GroupPractices = gpCol;
		}
		
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public void LoadFacilities()
		{
			FacilityCollection gpCol = new FacilityCollection();

			gpCol.SqlData.SPExecReadCol("usp_LoadFacNetworkLink", -1, gpCol,  true,new object[] { this.networkID } );

			// for all MarkDel GPLink check the group practice ID if matches remove from collection
			for (int j=0; j < gpCol.Count; j++)
			{
				bool removeCurrentGP = true;
				for (int i=0; i < facilitynetworkLinks.Count ; i++)
				{
					if (FacilityNetworkLinks[i].FacilityID == gpCol[j].FacilityID )
					{
						if (FacilityNetworkLinks[i].IsMarkedForDeletion && removeCurrentGP)
							removeCurrentGP = true;
						else
							removeCurrentGP = false;
					}
				}
				if (removeCurrentGP)
					gpCol.MarkDirty(j);
			}

			foreach (Facility gp in gpCol)
			{
				if (gp.IsDirty)
					gpCol.Remove(gp);
			}
			

			this.Facilities  = gpCol;
		}


		/// <summary>
		/// Saves the ProviderNetworkLinks collection
		/// </summary>
		public void SaveProviderNetworkLinks()
		{
			ProviderLocationNetworkLinkCollection.SaveChildCollection(this.providernetworkLinks, true);
		}

		/// <summary>
		/// Synchronizes the ProviderNetworkLinks collection
		/// </summary>
		public void SynchronizeProviderNetworkLinks()
		{
			ProviderLocationNetworkLinkCollection.SynchronizeChildCollection(this.providernetworkLinks, true);
		}

		/// <summary>
		/// Child FacilityNetworkLinks mapped to related rows of table FacilityLocationNetworks where [NetworkID] = [NetworkID]
		/// </summary>
		[SPLoadChild("usp_LoadNetworkFacilityLocationNetworks", "networkID")]
		public FacilityLocationNetworkLinkCollection FacilityNetworkLinks
		{
			get { return facilitynetworkLinks; }
			set
			{
				facilitynetworkLinks = value;
				value.ParentNetwork = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the FacilityNetworkLinks collection
		/// </summary>
		public void LoadFacilityNetworkLinks(bool forceReload)
		{
			this.facilitynetworkLinks = (FacilityLocationNetworkLinkCollection)FacilityLocationNetworkLinkCollection.LoadChildCollection("FacilityNetworkLinks", this, typeof(FacilityLocationNetworkLinkCollection), facilitynetworkLinks, forceReload, null);
		}

		/// <summary>
		/// Saves the FacilityNetworkLinks collection
		/// </summary>
		public void SaveFacilityNetworkLinks()
		{
			FacilityLocationNetworkLinkCollection.SaveChildCollection(this.facilitynetworkLinks, true);
		}

		/// <summary>
		/// Synchronizes the FacilityNetworkLinks collection
		/// </summary>
		public void SynchronizeFacilityNetworkLinks()
		{
			FacilityLocationNetworkLinkCollection.SynchronizeChildCollection(this.facilitynetworkLinks, true);
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state

		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AddressID
		{
			get { return this.addressID; }
			set { this.addressID = value; }
		}
		
		/// <summary>
		/// Contained Address object
		/// </summary>
		[Contained]
		public Address Address
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.address = (Address)Address.EnsureContainedDataObject(this, typeof(Address), address, false, addressID);
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.address;
			}
			set
			{
				this.address = value;
				if (value != null) value.ParentNetwork = this; // set this as a parent of the child data class
			}
		}


		public NetworkTypeCollection LookupOf_TypeID
		{
			get
			{
				return NetworkTypeCollection.ActiveNetworkTypes; // Acquire a shared instance from the static member of collection
			}
		}




		/// <summary>
		/// Child PlanNetworkLinks mapped to related rows of table NetworkPlanNetworkLinks where [NetworkID] = [NetworkID]
		/// </summary>
		[SPLoadChild("usp_LoadNetworkPlans", "networkID")]
		public NetworkPlanLinkCollection PlanNetworkLinks
		{
			get { return this.plannetworkLinks; }
			set
			{
				this.plannetworkLinks = value;
				value.ParentNetwork = this; // set this as a parent of the child collection
			}
		}
		
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public void LoadPlans()
		{
			PlanCollection gpCol = new PlanCollection();

			gpCol.SqlData.SPExecReadCol("usp_LoadNetworkPlanLink", -1, gpCol,  true,new object[] { this.networkID } );

			// for all MarkDel GPLink check the group practice ID if matches remove from collection
			for (int j=0; j < gpCol.Count; j++)
			{
				bool removeCurrentGP = true;
				for (int i=0; i < this.PlanNetworkLinks.Count ; i++)
				{
					if (PlanNetworkLinks[i].PlanId == gpCol[j].PlanId )
					{
						if (PlanNetworkLinks[i].IsMarkedForDeletion && removeCurrentGP)
							removeCurrentGP = true;
						else
							removeCurrentGP = false;
					}
				}
				if (removeCurrentGP)
					gpCol.MarkDirty(j);
			}

			foreach (Plan gp in gpCol)
			{
				if (gp.IsDirty)
					gpCol.Remove(gp);
			}
			

			this.Plans  = gpCol;
		}

		/// <summary>
		/// Loads the PlanNetworkLinks collection
		/// </summary>
		public void LoadPlanNetworkLinks(bool forceReload)
		{
			this.plannetworkLinks = (NetworkPlanLinkCollection)NetworkPlanLinkCollection.LoadChildCollection("PlanNetworkLinks", this, typeof(NetworkPlanLinkCollection), plannetworkLinks, forceReload, null);
		}

		/// <summary>
		/// Saves the PlanNetworkLinks collection
		/// </summary>
		public void SavePlanNetworkLinks()
		{
			NetworkPlanLinkCollection.SaveChildCollection(this.plannetworkLinks, true);
		}

		/// <summary>
		/// Synchronizes the PlanNetworkLinks collection
		/// </summary>
		public void SynchronizePlanNetworkLinks()
		{
			NetworkPlanLinkCollection.SynchronizeChildCollection(this.plannetworkLinks, true);
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		/// <summary>
		/// Child NetworkContacts mapped to related rows of table NetworkContact where [NetworkID] = [NetworkID]
		/// </summary>
		[SPLoadChild("usp_LoadNetworkContacts", "networkID")]
		public NetworkContactCollection NetworkContacts
		{
			get { return this.networkContacts; }
			set
			{
				this.networkContacts = value;
				if (value != null)
					value.ParentNetwork = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the NetworkContacts collection
		/// </summary>
		public void LoadNetworkContacts(bool forceReload)
		{
			this.networkContacts = (NetworkContactCollection)NetworkContactCollection.LoadChildCollection("NetworkContacts", this, typeof(NetworkContactCollection), networkContacts, forceReload, null);
		}

		/// <summary>
		/// Saves the NetworkContacts collection
		/// </summary>
		public void SaveNetworkContacts()
		{
			NetworkContactCollection.SaveChildCollection(this.networkContacts, true);
		}

		/// <summary>
		/// Synchronizes the NetworkContacts collection
		/// </summary>
		public void SynchronizeNetworkContacts()
		{
			NetworkContactCollection.SynchronizeChildCollection(this.networkContacts, true);
		}

		#region IContactOwner Members

		public BaseDataCollectionClass GetContacts()
		{
			if (NetworkContacts == null) LoadNetworkContacts(false);
			return NetworkContacts;
		}

		public void LoadContacts(bool forceLoad)
		{
			this.LoadNetworkContacts(forceLoad);
		}

		public void SaveContacts()
		{
			this.SaveNetworkContacts();
		}

		public ContactOwnerType ContactOwnerType
		{
			get
			{
				return ContactOwnerType.Network;
			}
		}

		#endregion

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		/// <summary>
		/// Parent NetworkCollection that contains this element
		/// </summary>
		public NetworkCollection ParentNetworkCollection
		{
			get
			{
				return this.parentNetworkCollection;
			}
			set
			{
				this.parentNetworkCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		/// <summary>
		/// Returns the network name for the given network ID.
		/// </summary>
		/// <param name="providerID"></param>
		/// <returns></returns>
		public static string GetNetworkNameByID(int networkID)
		{
			if (networkID == 0)
				return null;
			Network network = new Network();
			if (network.Load(networkID))
				return network.Name;
			else
				return null;
		}
		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

	}

	/// <summary>
	/// Strongly typed collection of Network objects
	/// </summary>
	[ElementType(typeof(Network))]
	public class NetworkCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_NetworkID;
		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchNetworks(Network network,Address networkAddress)
		{
			object [] prms = { network ,networkAddress };
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchNetworks", -1,this, prms, true);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllNetworks(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllNetworks", maxRecords, this, false);
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Network elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentNetworkCollection = this;
			else
				elem.ParentNetworkCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Network elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Network this[int index]
		{
			get
			{
				return (Network)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Network)oldValue, false);
			SetParentOnElem((Network)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Hashtable based index on networkID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_NetworkID
		{
			get
			{
				if (this.indexBy_NetworkID == null)
					this.indexBy_NetworkID = new CollectionIndexer(this, new string[] { "networkID" }, true);
				return this.indexBy_NetworkID;
			}
			
		}

		/// <summary>
		/// Looks up by networkID and returns Name value.  Uses the IndexBy_NetworkID indexer.
		/// </summary>
		public string Lookup_NameByNetworkID(int networkID)
		{
			return this.IndexBy_NetworkID.LookupStringMember("Name", networkID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllNetworks(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllNetworks", maxRecords, this, false);
		}

		/// <summary>
		/// Accessor to a shared NetworkCollection which is cached in NSGlobal
		/// </summary>
		public static NetworkCollection Networks
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				NetworkCollection col = (NetworkCollection)NSGlobal.EnsureCachedObject("Networks", typeof(NetworkCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllNetworks(-1);
				}
				return col;
			}
			
		}

	}
}
