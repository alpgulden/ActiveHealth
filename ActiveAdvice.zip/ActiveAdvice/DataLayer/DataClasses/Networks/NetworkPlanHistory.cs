using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [NetworkPlanHistory]
	/// </summary>
	[SPInsert("usp_InsertNetworkPlanHistory")]
	[SPUpdate("usp_UpdateNetworkPlanHistory")]
	[SPDelete("usp_DeleteNetworkPlanHistory")]
	[SPLoad("usp_LoadNetworkPlanHistory")]
	[TableMapping("NetworkPlanHistory","networkPlanHistoryID")]
	public class NetworkPlanHistory : BaseData
	{
		[NonSerialized]
		private NetworkPlanHistoryCollection parentNetworkPlanHistoryCollection;
		[ColumnMapping("NetworkPlanHistoryID",(int)0)]
		private int networkPlanHistoryID;
		[ColumnMapping("NetworkPlanID",(int)0)]
		private int networkPlanID;
		[ColumnMapping("StartDate")]
		private DateTime startDate;
		[ColumnMapping("EndDate")]
		private DateTime endDate;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("Active")]
		private bool active;
	
		public NetworkPlanHistory()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int NetworkPlanHistoryID
		{
			get { return this.networkPlanHistoryID; }
			set { this.networkPlanHistoryID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int NetworkPlanID
		{
			get { return this.networkPlanID; }
			set { this.networkPlanID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime StartDate
		{
			get { return this.startDate; }
			set { this.startDate = value; }
		}

		[ValidatorMember("Vld_EndDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EndDate
		{
			get { return this.endDate; }
			set { this.endDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		/// <summary>
		/// Parent NetworkPlanHistoryCollection that contains this element
		/// </summary>
		public NetworkPlanHistoryCollection ParentNetworkPlanHistoryCollection
		{
			get
			{
				return this.parentNetworkPlanHistoryCollection;
			}
			set
			{
				this.parentNetworkPlanHistoryCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Initializes the data object's record status flags and members with the given parameters.
		/// </summary>
		public void New()
		{
			this.NewRecord(); // initialize record state
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int networkPlanHistoryID)
		{
			return base.Load(networkPlanHistoryID);
		}
		[GenericScript("Vld_EndDate", "@EndDate@ != null && @EndDate@ >= @StartDate@;")]
		protected string Vld_EndDate
		{
			get
			{
				return "@ERRTERMDATE@"; // return warning prompt message or the warning in advance to be used by client validators
			}
			set
			{
				/*DateTime terminationDate = (DateTime)this.Get("terminationDate");
				DateTime effectiveDate = (DateTime)this.Get("effectiveDate");
				if (terminationDate != DateTime.MinValue && !(terminationDate >= effectiveDate))
					throw new ValidationException("TerminationDate", Vld_TerminationDate);  // throw validation exception if failed (don't set the member) 
					*/

				// Can't validate on the server, because the depended 2 members are not filled yet.
			}
		}

	}
	
	/// <summary>
	/// Strongly typed collection of NetworkPlanHistory objects
	/// </summary>
	[ElementType(typeof(NetworkPlanHistory))]
	public class NetworkPlanHistoryCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_NetworkPlanHistoryID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(NetworkPlanHistory elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentNetworkPlanHistoryCollection = this;
			else
				elem.ParentNetworkPlanHistoryCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (NetworkPlanHistory elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public NetworkPlanHistory this[int index]
		{
			get
			{
				return (NetworkPlanHistory)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((NetworkPlanHistory)oldValue, false);
			SetParentOnElem((NetworkPlanHistory)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Inserts the object into the collection at the given index
		/// </summary>
		public void Insert(int index, NetworkPlanHistory elem)
		{
			InsertRecord(index, elem);		
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((NetworkPlanHistory)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(NetworkPlanHistory elem)
		{
			return AddRecord(elem);
		}

		/// <summary>
		/// Removes the object from the collection
		/// </summary>
		public void Remove(NetworkPlanHistory elem)
		{
			RemoveRecord(elem);		
		}

		protected override void OnRemoveComplete(int index, object value)
		{
			SetParentOnElem((NetworkPlanHistory)value, false);
			base.OnRemoveComplete (index, value);		
		}

		/// <summary>
		/// Hashtable based index on networkPlanHistoryID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_NetworkPlanHistoryID
		{
			get
			{
				if (this.indexBy_NetworkPlanHistoryID == null)
					this.indexBy_NetworkPlanHistoryID = new CollectionIndexer(this, new string[] { "networkPlanHistoryID" }, true);
				return this.indexBy_NetworkPlanHistoryID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on networkPlanHistoryID fields returns the object.  Uses the IndexBy_NetworkPlanHistoryID indexer.
		/// </summary>
		public NetworkPlanHistory FindBy(int networkPlanHistoryID)
		{
			return (NetworkPlanHistory)this.IndexBy_NetworkPlanHistoryID.GetObject(networkPlanHistoryID);
		}

		/// <summary>
		/// Loads records from the table to which the element type is mapped
		/// </summary>
		public int Load(int maxRecords, string filter, string sort)
		{
			this.Clear();
			return this.SqlData.SPExecReadCol(this.LoadProcName, maxRecords, this, false, filter, sort /* change these parameters to match those of stored procedure's */ );
		}

		/* Don't use this.
		/// <summary>
		/// Executes an SQL statement and fills the collection with the mapped columns of the result
		/// </summary>
		public int ExecuteSQL( object param)
		{
			SQLParser sql = new SQLParser("select * from [NetworkPlanHistory] " +
			"");  //"where param=@param");
			SQLDataDirect sd = SQLDataDirect.CreateSqlDataForQuery(sql);
			//sd.SQLCommand.Parameters["@param"].Value = param;
			this.Clear();
			SQLDataFiller.AppendToCollection(sd, this, true, false);
			return this.Count;
		}
		*/

		/// <summary>
		/// Update the Status for GroupPractice Location Network table for the given groupPracticeLocationNetworkID based on the effective and Termination dates.
		/// </summary>
		public int UpdateStatusForPlanNetworkHistory(int maxRecords, NetworkPlanHistory networkPlanHistory,int networkPlanID)
		{
			this.Clear();
			return SqlData.SPExecNonQuery("usp_UpdateStatusForPlanNetworkHistory",networkPlanHistory,false,
				new string[] { "networkPlanID" },
				new object[] { networkPlanID } );
		}


		/// <summary>
		/// Parent FacilityLocationNetworkLink that contains this collection
		/// </summary>
		public NetworkPlanLink ParentNetworkPlanLink
		{
			get { return this.ParentDataObject as NetworkPlanLink ; }
			set { this.ParentDataObject = value; /* parent is set when contained by a FacilityLocationNetworkLink */ }
		}


		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}
	}
}
