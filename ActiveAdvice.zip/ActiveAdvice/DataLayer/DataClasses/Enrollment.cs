using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Enrollment]
	/// </summary>
	[SPAutoGen("usp_LoadAllEnrollmentsByOrgaanizationId","SelectRelatedFromLinkedTable.sptpl","OrganizationEnrollment, enrollmentID, organizationID")]
	[SPAutoGen("usp_GetAllEnrollments","SelectAll.sptpl","")]
	[SPInsert("usp_InsertEnrollment")]
	[SPUpdate("usp_UpdateEnrollment")]
	[SPDelete("usp_DeleteEnrollment")]
	[SPLoad("usp_LoadEnrollment")]
	[TableMapping("Enrollment","enrollmentID")]
	public class Enrollment : BaseData
	{
		[NonSerialized]
		private EnrollmentCollection parentEnrollmentCollection;
		[ColumnMapping("EnrollmentID",StereoType=DataStereoType.FK)]
		private int enrollmentID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("EffectiveDate")]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreationTime")]
		private DateTime creationTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("TerminatedBy")]
		private int terminatedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		private OrganizationCollection organizations;
	
		public Enrollment()
		{
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EnrollmentID
		{
			get { return this.enrollmentID; }
			set { this.enrollmentID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreationTime
		{
			get { return this.creationTime; }
			set { this.creationTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int enrollmentID)
		{
			return base.Load(enrollmentID);
		}

		/// <summary>
		/// Parent EnrollmentCollection that contains this element
		/// </summary>
		public EnrollmentCollection ParentEnrollmentCollection
		{
			get
			{
				return this.parentEnrollmentCollection;
			}
			set
			{
				this.parentEnrollmentCollection = value; // parent is set when added to a collection
			}
		}

		

		

		
		/// <summary>
		/// Child Organizations mapped to related rows of table Organization where [EnrollmentID] = [OrganizationID]
		/// </summary>
		[SPLoadChild("usp_LoadAllOrganizationsByEnrollmentId", "enrollmentID")]
		public OrganizationCollection Organizations
		{
			get { return this.organizations; }
			set
			{
				this.organizations = value;
				if (value != null)
					value.ParentEnrollment = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Organizations collection
		/// </summary>
		public void LoadOrganizations(bool forceReload)
		{
			this.organizations = (OrganizationCollection)OrganizationCollection.LoadChildCollection("Organizations", this, typeof(OrganizationCollection), organizations, forceReload, null);
		}
		
		/// <summary>
		/// Saves the Organizations collection
		/// </summary>
		public void SaveOrganizations()
		{
			OrganizationCollection.SaveChildCollection(this.organizations, true);
		}

		/// <summary>
		/// Synchronizes the Organizations collection
		/// </summary>
		public void SynchronizeOrganizations()
		{
			OrganizationCollection.SynchronizeChildCollection(this.organizations, true);
		}

		/// <summary>
		/// Parent PackingListItemTrigger that contains this object
		/// </summary>
		public PackingListItemTrigger ParentPackingListItemTrigger
		{
			get { return this.ParentDataObject as PackingListItemTrigger; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PackingListItemTrigger */ }
		}

	}

	/// <summary>
	/// Strongly typed collection of Enrollment objects
	/// </summary>
	[ElementType(typeof(Enrollment))]
	public class EnrollmentCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_EnrollmentID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Enrollment elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEnrollmentCollection = this;
			else
				elem.ParentEnrollmentCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Enrollment elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Enrollment this[int index]
		{
			get
			{
				return (Enrollment)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Enrollment)oldValue, false);
			SetParentOnElem((Enrollment)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Organization that contains this collection
		/// </summary>
		public Organization ParentOrganization
		{
			get { return this.ParentDataObject as Organization; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Organization */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllEnrollmentsByValidDateRange(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllEnrollments", maxRecords, this, false);
		}

		/// <summary>
		/// Accessor to a shared EnrollmentCollection which is cached in NSGlobal
		/// </summary>
		public static EnrollmentCollection AllEnrollmentsByValidDateRange
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				EnrollmentCollection col = (EnrollmentCollection)NSGlobal.EnsureCachedObject("AllEnrollmentsByValidDateRange", typeof(EnrollmentCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllEnrollmentsByValidDateRange(-1);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on enrollmentID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_EnrollmentID
		{
			get
			{
				if (this.indexBy_EnrollmentID == null)
					this.indexBy_EnrollmentID = new CollectionIndexer(this, new string[] { "enrollmentID" }, true);
				return this.indexBy_EnrollmentID;
			}
			
		}

		/// <summary>
		/// Looks up by enrollmentID and returns Description value.  Uses the IndexBy_EnrollmentID indexer.
		/// </summary>
		public string Lookup_DescriptionByEnrollmentID(int enrollmentID)
		{
			return this.IndexBy_EnrollmentID.LookupStringMember("Description", enrollmentID);
		}

		
	}
}
