using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Eligibility]
	/// </summary>
	[SPAutoGen("usp_SelectAllByMembershipID","SelectAllByGivenArgs.sptpl","membershipId")]
	[SPLoad("usp_LoadEligibility")]
	[TableMapping("Eligibility","eligibilityId")]
	public class Eligibility : BaseData
	{
		[NonSerialized]
		private EligibilityCollection parentEligibilityCollection;
		[ColumnMapping("EligibilityId",(int)0)]
		private int eligibilityId;
		[ColumnMapping("AsOfDate")]
		private DateTime asOfDate;
		[ColumnMapping("FirstName")]
		private string firstName;
		[ColumnMapping("LastName")]
		private string lastName;
		[ColumnMapping("MembershipId")]
		private string membershipId;
		[ColumnMapping("MemberAddress1")]
		private string memberAddress1;
		[ColumnMapping("MemberAddress2")]
		private string memberAddress2;
		[ColumnMapping("MemberAddress3")]
		private string memberAddress3;
		[ColumnMapping("MemberCity")]
		private string memberCity;
		[ColumnMapping("MemberState")]
		private string memberState;
		[ColumnMapping("MemberCountry")]
		private string memberCountry;
		[ColumnMapping("MemberPostalCode")]
		private string memberPostalCode;
		[ColumnMapping("MemberDOB")]
		private DateTime memberDOB;
		[ColumnMapping("MemberGender")]
		private string memberGender;
		[ColumnMapping("MemberSSN")]
		private string memberSSN;
		[ColumnMapping("MemberSORGId")]
		private string memberSORGId;
		[ColumnMapping("MemberEffectiveDate")]
		private DateTime memberEffectiveDate;
		[ColumnMapping("IsSubscriber")]
		private bool isSubscriber;
		[ColumnMapping("MedicaidId")]
		private string medicaidId;
		[ColumnMapping("MedicareId")]
		private string medicareId;
		[ColumnMapping("MemberMORGId")]
		private string memberMORGId;
		[ColumnMapping("MemberORGId")]
		private string memberORGId;
		[ColumnMapping("HomePhoneNumber")]
		private string homePhoneNumber;
		[ColumnMapping("WorkPhoneNumber")]
		private string workPhoneNumber;
		[ColumnMapping("WorkPhoneExtension")]
		private string workPhoneExtension;
		[ColumnMapping("Fax")]
		private string fax;
		[ColumnMapping("FaxExtension")]
		private string faxExtension;
		[ColumnMapping("Email")]
		private string email;
		[ColumnMapping("Race")]
		private string race;
		[ColumnMapping("EligibilityTerminationDate")]
		private DateTime eligibilityTerminationDate;
		[ColumnMapping("PlanTerminationDate")]
		private DateTime planTerminationDate;
		[ColumnMapping("MemberCounty")]
		private string memberCounty;
		[ColumnMapping("AlternateInsuranceID")]
		private string alternateInsuranceID;
		[ColumnMapping("MORGID",StereoType=DataStereoType.FK)]
		private int mORGID;
		[ColumnMapping("ORGID",StereoType=DataStereoType.FK)]
		private int oRGID;
		[ColumnMapping("SORGID",StereoType=DataStereoType.FK)]
		private int sORGID;
		[ColumnMapping("MiddleInitial")]
		private string middleInitial;
		[ColumnMapping("NameSuffix")]
		private string nameSuffix;
		[ColumnMapping("RelationshipID",StereoType=DataStereoType.FK)]
		private int relationshipID;
		[ColumnMapping("HomePhoneExtension")]
		private string homePhoneExtension;
		[ColumnMapping("AlternateSubscriberID")]
		private string alternateSubscriberID;
		private EligibilityPlanCollection eligibilityPlans;
	
		public Eligibility()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int EligibilityId
		{
			get { return this.eligibilityId; }
			set { this.eligibilityId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime AsOfDate
		{
			get { return this.asOfDate; }
			set { this.asOfDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string FirstName
		{
			get { return this.firstName; }
			set { this.firstName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string LastName
		{
			get { return this.lastName; }
			set { this.lastName = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=32)]
		public string MembershipId
		{
			get { return this.membershipId; }
			set { this.membershipId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string MemberAddress1
		{
			get { return this.memberAddress1; }
			set { this.memberAddress1 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string MemberAddress2
		{
			get { return this.memberAddress2; }
			set { this.memberAddress2 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string MemberAddress3
		{
			get { return this.memberAddress3; }
			set { this.memberAddress3 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string MemberCity
		{
			get { return this.memberCity; }
			set { this.memberCity = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string MemberState
		{
			get { return this.memberState; }
			set { this.memberState = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string MemberCountry
		{
			get { return this.memberCountry; }
			set { this.memberCountry = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=10)]
		public string MemberPostalCode
		{
			get { return this.memberPostalCode; }
			set { this.memberPostalCode = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime MemberDOB
		{
			get { return this.memberDOB; }
			set { this.memberDOB = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string MemberGender
		{
			get { return this.memberGender; }
			set { this.memberGender = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=64)]
		public string MemberSSN
		{
			get { return this.memberSSN; }
			set { this.memberSSN = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string MemberSORGId
		{
			get { return this.memberSORGId; }
			set { this.memberSORGId = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime MemberEffectiveDate
		{
			get { return this.memberEffectiveDate; }
			set { this.memberEffectiveDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool IsSubscriber
		{
			get { return this.isSubscriber; }
			set { this.isSubscriber = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string MedicaidId
		{
			get { return this.medicaidId; }
			set { this.medicaidId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string MedicareId
		{
			get { return this.medicareId; }
			set { this.medicareId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string MemberMORGId
		{
			get { return this.memberMORGId; }
			set { this.memberMORGId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string MemberORGId
		{
			get { return this.memberORGId; }
			set { this.memberORGId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string HomePhoneNumber
		{
			get { return this.homePhoneNumber; }
			set { this.homePhoneNumber = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string WorkPhoneNumber
		{
			get { return this.workPhoneNumber; }
			set { this.workPhoneNumber = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string WorkPhoneExtension
		{
			get { return this.workPhoneExtension; }
			set { this.workPhoneExtension = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string Fax
		{
			get { return this.fax; }
			set { this.fax = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string FaxExtension
		{
			get { return this.faxExtension; }
			set { this.faxExtension = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=60)]
		public string Email
		{
			get { return this.email; }
			set { this.email = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string Race
		{
			get { return this.race; }
			set { this.race = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EligibilityTerminationDate
		{
			get { return this.eligibilityTerminationDate; }
			set { this.eligibilityTerminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime PlanTerminationDate
		{
			get { return this.planTerminationDate; }
			set { this.planTerminationDate = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string MemberCounty
		{
			get { return this.memberCounty; }
			set { this.memberCounty = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		public string AlternateInsuranceID
		{
			get { return this.alternateInsuranceID; }
			set { this.alternateInsuranceID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MORGID
		{
			get { return this.mORGID; }
			set { this.mORGID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ORGID
		{
			get { return this.oRGID; }
			set { this.oRGID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SORGID
		{
			get { return this.sORGID; }
			set { this.sORGID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string MiddleInitial
		{
			get { return this.middleInitial; }
			set { this.middleInitial = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=20)]
		public string NameSuffix
		{
			get { return this.nameSuffix; }
			set { this.nameSuffix = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int RelationshipID
		{
			get { return this.relationshipID; }
			set { this.relationshipID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=6)]
		public string HomePhoneExtension
		{
			get { return this.homePhoneExtension; }
			set { this.homePhoneExtension = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=30)]
		public string AlternateSubscriberID
		{
			get { return this.alternateSubscriberID; }
			set { this.alternateSubscriberID = value; }
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int eligibilityId)
		{
			return base.Load(eligibilityId);
		}

		/// <summary>
		/// Parent EligibilityCollection that contains this element
		/// </summary>
		public EligibilityCollection ParentEligibilityCollection
		{
			get
			{
				return this.parentEligibilityCollection;
			}
			set
			{
				this.parentEligibilityCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Child EligibilityPlans mapped to related rows of table EligibilityPlan where [EligibilityId] = [EligibilityId]
		/// </summary>
		[SPLoadChild("usp_LoadEligibilityPlans", "eligibilityId")]
		public EligibilityPlanCollection EligibilityPlans
		{
			get { return this.eligibilityPlans; }
			set
			{
				this.eligibilityPlans = value;
				if (value != null)
					value.ParentEligibility = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the EligibilityPlans collection
		/// </summary>
		public void LoadEligibilityPlans(bool forceReload)
		{
			this.eligibilityPlans = (EligibilityPlanCollection)EligibilityPlanCollection.LoadChildCollection("EligibilityPlans", this, typeof(EligibilityPlanCollection), eligibilityPlans, forceReload, null);
		}

		/// <summary>
		/// Saves the EligibilityPlans collection
		/// </summary>
		public void SaveEligibilityPlans()
		{
			EligibilityPlanCollection.SaveChildCollection(this.eligibilityPlans, true);
		}

		/// <summary>
		/// Synchronizes the EligibilityPlans collection
		/// </summary>
		public void SynchronizeEligibilityPlans()
		{
			EligibilityPlanCollection.SynchronizeChildCollection(this.eligibilityPlans, true);
		}

		public EligibilityPCPCollection GetAllEligibilityPCPs(int planID)
		{
			EligibilityPCPCollection eligPCPs = new EligibilityPCPCollection();
			eligPCPs.LoadEligibilityPCPsByEligibilityIDPlanID(-1, this.eligibilityId, planID);
			if (eligPCPs.Count > 0)
				return eligPCPs;
			else
				return null;
		}

	}

	/// <summary>
	/// Strongly typed collection of Eligibility objects
	/// </summary>
	[ElementType(typeof(Eligibility))]
	public class EligibilityCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Eligibility elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentEligibilityCollection = this;
			else
				elem.ParentEligibilityCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Eligibility elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Eligibility this[int index]
		{
			get
			{
				return (Eligibility)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Eligibility)oldValue, false);
			SetParentOnElem((Eligibility)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SelectAllByMembershipID(int maxRecords, string membershipId)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SelectAllByMembershipID", maxRecords, this, false, new object[] { membershipId });
		}

	}
}
