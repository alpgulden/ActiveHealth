using System;
using System.Diagnostics;
using System.Collections;
using NetsoftUSA.DataLayer;
using ActiveAdvice.Messages;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// The Morg/Org/Sorg relationship represents the hierarchy within an organization that 
	/// contracts for health services. The Morg is the �Master Organization� and represents 
	/// the top-most level of the organization providing health insurance. Typically 
	/// the Morg is the corporate main office (i.e. �Big Machines Inc�) or a governmental 
	/// body (i.e. �State of Virginia�). The Org is the next level down in the hierarchy , 
	/// the middle �Organization� entity. The Sorg, the Sub-Organization, is the direct 
	/// �owner� of the Insurance Plan. In some clients the Org & Sorg may be the same entity, 
	/// but for consistency the Sorg is treated as the entity to which Plans are associated.
	/// 
	/// In our data-model this hieararchy is flexible.  There's a single Organizations table.
	/// Each Organization has a level and a parent.  The level represents how deep an organization
	/// is located in the organization tree.  For the Morg/Org/Sorg hieararchy, Morg = 1, Org = 2,
	/// and Sorg = 3.  The levels, their ids, codes and descriptions are defined in the 
	/// OrganizationLevels table.  Organization Level = 1 is considered to be the master
	/// organization, Level = N (the last level) is considered to be the sub-organization.  The
	/// sub-orgnization can't have its own child organizations.  Everything between Morg and
	/// Sorg is a regular organization with a defined Level.
	/// </summary>
	[SPAutoGen("usp_LoadAllOrganizationsByEnrollmentId","SelectRelatedFromLinkedTable.sptpl","OrganizationEnrollment, organizationID, enrollmentID")]
	[SPAutoGen("usp_SearchOrgs","SearchByArgs.sptpl","parentOrganizationID, name, organizationTypeID, organizationLevelID")]
	[SPAutoGen("usp_SearchOrgsBySynonym","SelectOrgsBySynonym.sptpl","parentOrganizationID, name, organizationTypeID, organizationLevelID")]
	[SPAutoGen("usp_GetOrganizationsByParentAndLevel","SelectAllByGivenArgs.sptpl","parentOrganizationID, organizationLevelID")]
	[SPInsert("usp_InsertOrganization")]
	[SPUpdate("usp_UpdateOrganization")]
	[SPDelete("usp_DeleteOrganization")]
	[SPLoad("usp_LoadOrganization")]
	[TableMapping("Organization","organizationID")]
	public class Organization : BaseDataWithUserDefined, IContactOwner
	{
		private OrgSynonymCollection orgSynonyms;

		[NonSerialized]
		private OrganizationCollection parentOrganizationCollection;
		[Copiable(false)]
		[ColumnMapping("OrganizationID",StereoType=DataStereoType.FK)]
		protected int organizationID;
		[Copiable(false)]
		[ColumnMapping("ParentOrganizationID",StereoType=DataStereoType.FK)]
		protected int parentOrganizationID;
		[Copiable(false)]
		[ColumnMapping("OrganizationLevelID")]
		protected int organizationLevelID;
		[ColumnMapping("Name")]
		protected string name;
		[ColumnMapping("AlternateID")]
		protected string alternateID;
		[ColumnMapping("ICMID")]
		protected string iCMID;
		[ColumnMapping("EffectiveDate")]
		protected DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		protected DateTime terminationDate;
		[ColumnMapping("ContractEffDate")]
		protected DateTime contractEffDate;
		[ColumnMapping("RenewalDate")]
		protected DateTime renewalDate;
		[ColumnMapping("OrganizationTypeID",StereoType=DataStereoType.FK)]
		protected int organizationTypeID;
		[Copiable(false)]
		[ColumnMapping("AddressID",StereoType=DataStereoType.FK)]
		protected int addressID;
		[ColumnMapping("Note")]
		protected string note;
		[Copiable(false)]
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[Copiable(false)]
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[Copiable(false)]
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[Copiable(false)]
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("TerminateTime")]
		private DateTime terminateTime;
		[Copiable(false)]
		[ColumnMapping("TerminatedBy",StereoType=DataStereoType.FK)]
		private int terminatedBy;
		[Copiable(false)]
		[ColumnMapping("OrganizationPath")]
		private string organizationPath;
		[ColumnMapping("DefaultPlanSORGID",StereoType=DataStereoType.FK)]
		private int defaultPlanSORGID;
		[ColumnMapping("PrimarySynonymID",StereoType=DataStereoType.FK)]
		private int primarySynonymID;

		private Organization parentOrganization;		// the parent Organization

		private Address address;
		private OrganizationFocusCollection organizationFocuses;
		
		private OrganizationLevel organizationLevel;		// looked up and cached
		private OrganizationLevel organizationSubLevel;		// looked up and cached
		private DateTime termDateWhenLoaded;
		private PlanSORGCollection planSORGs;
		private OrganizationContactCollection organizationContacts;		// the terminate date when the object was loaded

		private Organization[] parentOrganizations;
		private EnrollmentCollection enrollments;

		public Organization()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public Organization(Organization parentOrganization)
			: this(parentOrganization, false)
		{
		}

		/// <summary>
		/// Create an organization under given parent.
		/// If null parent is specified, master org is created.
		/// </summary>
		/// <param name="parentOrganization"></param>
		public Organization(Organization parentOrganization, bool searcher)
		{
			if (searcher)
				SetMembersNull(true, true);
			else
				this.NewRecord(); // initialize record state

			if (parentOrganization != null)
			{
				this.parentOrganization = parentOrganization;
				this.parentOrganizationID = parentOrganization.OrganizationID;
				
				// Check if this is the leaf node or an invalid level
				if (parentOrganization.IsSubOrganization)
					throw new Exception(
						String.Format("A sub-organization of level {0} can't have child organizations!", parentOrganizationID));

				this.organizationLevelID = parentOrganization.OrganizationLevelID + 1;
			}
			else
			{
				// no parent organization, this is the topmost level
				this.organizationLevelID = 1;		// make this the topmost level
			}
		}

		public Organization(string name, Organization parentOrganization)
			: this(parentOrganization)
		{
			this.name = name;
		}

		public static Organization CreateSearcherForLevel(int level)
		{
			Organization org = new Organization(null, true);
			org.organizationLevelID = level;
			org.parentOrganizationID = 0;
			return org;
		}

		public static Organization CreateSearcherForParent(Organization parent)
		{
			return new Organization(parent, true);
		}

		/*public void NewSearcher()
		{
			int levelID = this.organizationLevelID;
			SetMembersNull(true, true);
			this.organizationLevelID = levelID;
		}*/

		public void CopyTo(Organization targetOrganization)
		{
			this.CopyMappedMembersTo(targetOrganization, false, false, false);
		}

		public Organization ParentOrganization
		{
			get 
			{ 
				if (this.parentOrganization == null)
					this.parentOrganization = GetParentOrganization();
				return this.parentOrganization;
			}
		}

		public Organization GetParentOrganization()
		{
			if (this.parentOrganizationID == 0)
				return null;
			else
			{
				Organization org = new Organization();
				if (org.Load(this.parentOrganizationID))
					return org;
				else
					return null;
			}
		}

		private void FillParentOrganizations(ArrayList orgs)
		{
			Organization parentOrg = this.GetParentOrganization();
			if (parentOrg != null)
			{
				orgs.Insert(0, parentOrg);
				parentOrg.FillParentOrganizations(orgs);
			}
		}

		public Organization[] GetParentOrganizations()
		{
			if (parentOrganizations == null)
			{
				ArrayList orgs = new ArrayList();
				FillParentOrganizations(orgs);
				orgs.Add(this);
				parentOrganizations = (Organization[])orgs.ToArray(typeof(Organization));
			}
			return parentOrganizations;
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int organizationID)
		{
			return base.Load(organizationID);
		}

		/// <summary>
		/// Load an organization for the given synonym and return it
		/// </summary>
		/// <param name="synonym"></param>
		/// <returns></returns>
		public static Organization GetBySynonym(string synonym)
		{
			// Load the organizations mathcing the given synonym
			// We expect only a single one, otherwise we throw an exception
			OrganizationCollection orgs = new OrganizationCollection();
			orgs.LoadBySynonym(synonym, true, false);
			if (orgs.Count > 1)		// there are multiple organizations for this synonym
				throw new ActiveAdviceException(AAExceptionAction.None, OrgMessages.MessageIDs.SYNONYMUSEDBYMULTI, synonym);
			if (orgs.Count == 0)	// no organizations with a valid synonym
				return null;

			// found a single organization for this synonym and its synonym was valid
			return orgs[0];
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			this.SqlData.EnsureTransaction();
			try
			{ 
				base.Save();
				this.SqlData.CommitTransaction();
			}
			catch(Exception ex)
			{
				this.SqlData.RollbackTransaction();
				Debug.WriteLine(ex);
				throw;
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			this.effectiveDate = DateTime.Today;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
			this.addressID = 0;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int OrganizationID
		{
			get { return this.organizationID; }
			set { this.organizationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ParentOrganizationID
		{
			get { return this.parentOrganizationID; }
			set { this.parentOrganizationID = value; }
		}

		/// <summary>
		/// Which level of hiearchy the organization belongs.
		/// </summary>
		public int OrganizationLevelID
		{
			get { return this.organizationLevelID; }
		}

		/// <summary>
		/// Which level of hiearchy the organization's immediate child belongs
		/// </summary>
		public int OrganizationSubLevelID
		{
			get { return this.organizationLevelID + 1; }
		}

		public int[] ParentOrganizationIDs
		{
			get 
			{
				if (this.organizationPath == null)
					return null;
				string[] orgIDs = organizationPath.Split('.');
				int[] parentORGIDs = new int[orgIDs.Length];
				for (int i = 0; i < orgIDs.Length; i++)
					parentORGIDs[i] = int.Parse( orgIDs[i] );
				return parentORGIDs;
			}
		}

		public string OrganizationFullPath
		{
			get
			{
				if (this.organizationPath != null)
					return this.organizationPath + "." + this.OrganizationID.ToString();
				else
					return this.OrganizationID.ToString();
			}
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=50)]
		[FieldDescription("@ORGNAME@")]
		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=30)]
		[FieldDescription("@ALTERNATEID@")]
		public string AlternateID
		{
			get { return this.alternateID; }
			set { this.alternateID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=15)]
		public string ICMID
		{
			get { return this.iCMID; }
			set { this.iCMID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ValidatorMember("Vld_TerminationDate")]
		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@TERMDATE@")]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ContractEffDate
		{
			get { return this.contractEffDate; }
			set { this.contractEffDate = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		[FieldDescription("@RENEWALDATE@")]
		public System.DateTime RenewalDate
		{
			get { return this.renewalDate; }
			set { this.renewalDate = value; }
		}

		[FieldValuesMember("LookupOf_Type", "OrganizationTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@ORGTYPE@")]
		public int OrganizationTypeID
		{
			get { return this.organizationTypeID; }
			set { this.organizationTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AddressID
		{
			get { return this.addressID; }
			set { this.addressID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		[FieldDescription("@NOTE@")]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		/// <summary>
		/// Contained Address object
		/// </summary>
		[Contained]
		public Address Address
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.address = (Address)Address.EnsureContainedDataObject(this, typeof(Address), address, false, addressID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.address;
			}
			set
			{
				this.address = value;
				if (value != null) value.ParentOrganization = this; // set this as a parent of the child data class
			}
		}

		/// <summary>
		/// Override this function to load child and other objects that must be loaded with this object.
		/// </summary>
		protected override bool InternalLoad(params object[] keys)
		{
			// Do pre-load operations here.
			bool result = base.InternalLoad(keys);
			// Do post-load operations here.

			return result;
		}

		public OrganizationTypeCollection LookupOf_Type
		{
			get
			{
				return OrganizationTypeCollection.ActiveOrganizationTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// Save the contained objects that must be saved first.
			this.Address.SqlData.Transaction = this.SqlData.Transaction;  // pass existing transaction to the contained object
			if (this.IsMarkedForDeletion)	// may be necessary to check if this object must be deleted first
			{
				base.InternalSave();	// in that case, delete the base first
				Address.MarkDel();	// then allow the deletion of the conatined object
			}

			Address.IsNew = this.IsNew;		// make sure the address is new if the containing object is new
			Address.Save();
			this.addressID = Address.AddressID; // set the fk if the contained object was newly created
			if (this.termDateWhenLoaded != this.terminationDate) // && this.terminationDate != DateTime.MinValue)
			{
				// user has changed term date, set the terminating user
				this.SetTerminatingUser();
			}

			// if the primary synonym is not new just set its value on the parent org
			//OrgSynonym syn = this.orgSynonyms.FindBy(this.primarySynonymID);
			//if (syn != null && !syn.IsNew)
			//	this.primarySynonymID = this.orgSynonyms.IndexOf(this.primarySynonymID);
			base.InternalSave();

			if (this.IsSubOrganization)
			{
				this.LoadOrgSynonyms(false);

				if (this.OrgSynonyms.Count == 0)		// sub-organization must create a synonym with the same name as its name
				{
					// save the organization name as a synonym
					OrgSynonym orgSynonym = new OrgSynonym(this.OrganizationID);
					orgSynonym.Name = this.name;
					this.OrgSynonyms.Add(orgSynonym);
				}

				this.SaveOrgSynonyms();

				// if this is newly inserted into db or there's a single synonym.  Set the default one
				if (this.IsNewlyInsertedInDB || this.OrgSynonyms.Count == 1)
				{
					if (this.OrgSynonyms.Count > 0)		// set the primary organization id
						this.primarySynonymID = this.OrgSynonyms[0].OrganizationSynonymID;
				}

			}

			

			// Save the child collections here.
		}

		/// <summary>
		/// Parent OrganizationCollection that contains this element
		/// </summary>
		public OrganizationCollection ParentOrganizationCollection
		{
			get
			{
				return this.parentOrganizationCollection;
			}
			set
			{
				this.parentOrganizationCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child OrganizationFocuses mapped to related rows of table OrganizationFocuses where [OrganizationID] = [OrganizationID]
		/// </summary>
		[SPLoadChild("usp_LoadOrganizationFocuses", "organizationID")]
		public OrganizationFocusCollection OrganizationFocuses
		{
			get { return this.organizationFocuses; }
			set
			{
				this.organizationFocuses = value;
				if (value != null)
					value.ParentOrganization = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the OrganizationFocuses collection
		/// </summary>
		public void LoadOrganizationFocuses(bool forceReload)
		{
			this.organizationFocuses = (OrganizationFocusCollection)OrganizationFocusCollection.LoadChildCollection("OrganizationFocuses", this, typeof(OrganizationFocusCollection), organizationFocuses, forceReload, null);
		}

		/// <summary>
		/// Saves the OrganizationFocuses collection
		/// </summary>
		public void SaveOrganizationFocuses()
		{
			OrganizationFocusCollection.SaveChildCollection(this.organizationFocuses, true);
		}

		/// <summary>
		/// Synchronizes the OrganizationFocuses collection
		/// </summary>
		public void SynchronizeOrganizationFocuses()
		{
			OrganizationFocusCollection.SynchronizeChildCollection(this.organizationFocuses, true);
		}

		/// <summary>
		/// Returns a string representation of the class instance
		/// </summary>
		public override string ToString()
		{
			string s = this.GetType().Name + "\r\n";
			s += "{\r\n";
			s += "	organizationID= '" + ReflectionHelper.GetMemberValueAsString(this, "organizationID") + "'\r\n";
			s += "	parentOrganizationID= '" + ReflectionHelper.GetMemberValueAsString(this, "parentOrganizationID") + "'\r\n";
			s += "	organizationLevelID= '" + ReflectionHelper.GetMemberValueAsString(this, "organizationLevelID") + "'\r\n";
			s += "	name= '" + ReflectionHelper.GetMemberValueAsString(this, "name") + "'\r\n";
			s += "	alternateID= '" + ReflectionHelper.GetMemberValueAsString(this, "alternateID") + "'\r\n";
			s += "	effectiveDate= '" + ReflectionHelper.GetMemberValueAsString(this, "effectiveDate") + "'\r\n";
			s += "	terminationDate= '" + ReflectionHelper.GetMemberValueAsString(this, "terminationDate") + "'\r\n";
			s += "	addressID= '" + ReflectionHelper.GetMemberValueAsString(this, "addressID") + "'\r\n";
			s += "}\r\n";
			return s;
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminateTime
		{
			get { return this.terminateTime; }
			set { this.terminateTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int TerminatedBy
		{
			get { return this.terminatedBy; }
			set { this.terminatedBy = value; }
		}

		/// <summary>
		/// Override this to implement custom filling of members from the given source reader.  This is called whenever the object is filled from a data reader.
		/// </summary>
		protected override void FillFromReader(System.Data.SqlClient.SqlDataReader sourceRdr, bool ignoreAssignmentError)
		{
			// Fill members for the given source reader record.
			base.FillFromReader(sourceRdr, ignoreAssignmentError);

			// save the terminate date, if it's changed that means the user has terminated it
			termDateWhenLoaded = this.terminationDate;
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=30)]
		public string OrganizationPath
		{
			get { return this.organizationPath; }
			set { this.organizationPath = value; }
		}

		#region Sub Organization (the leaf node) functions

		/// <summary>
		/// Child OrgSynonyms mapped to related rows of table OrganizationSynonyms where [OrganizationID] = [OrganizationID]
		/// </summary>
		[SPLoadChild("usp_LoadOrganizationSynonyms", "organizationID")]
		public OrgSynonymCollection OrgSynonyms
		{
			get { return this.orgSynonyms; }
			set
			{
				this.orgSynonyms = value;
				if (value != null)
					value.ParentSubOrganization = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the OrgSynonyms collection
		/// </summary>
		public void LoadOrgSynonyms(bool forceReload)
		{
			if (!this.IsSubOrganization)
				throw new Exception("Only the sub-organization can have synonyms");

			this.orgSynonyms = (OrgSynonymCollection)OrgSynonymCollection.LoadChildCollection("OrgSynonyms", this, typeof(OrgSynonymCollection), orgSynonyms, forceReload, null);
			//OrgSynonym syn = this.orgSynonyms.FindBy(this.primarySynonymID);
			//if (syn != null)
			//	syn.IsPrimary = true;	// mark the primary syn.
		}

		/// <summary>
		/// Saves the OrgSynonyms collection
		/// </summary>
		public void SaveOrgSynonyms()
		{
			OrgSynonymCollection.SaveChildCollection(this.orgSynonyms, true);
			if (orgSynonyms != null)
			{
				// find the primary syn and set it to parent
				//for (int i = 0; i < this.orgSynonyms.Count; i++)
				//{
					//OrgSynonym syn = this.orgSynonyms[i];
					//if (syn.IsPrimary)
					//{
					//	this.parentOrganization.PrimarySynonymID = syn.OrganizationSynonymID;
					//	break;
					//}
				//}
			}
		}

		/// <summary>
		/// Synchronizes the OrgSynonyms collection
		/// </summary>
		public void SynchronizeOrgSynonyms()
		{
			OrgSynonymCollection.SynchronizeChildCollection(this.orgSynonyms, true);
		}

		#endregion



		/// <summary>
		/// Returns the shared OrganizationLevel object that corresponds to this organization's level id.
		/// </summary>
		public OrganizationLevel OrganizationLevel
		{
			get 
			{
				if (organizationLevel == null)
					organizationLevel = OrganizationLevelCollection.OrganizationLevels.FindBy(this.organizationLevelID); 
				return organizationLevel;
			}
		}

		/// <summary>
		/// Returns the shared OrganizationLevel object that corresponds to this organization's child
		/// </summary>
		public OrganizationLevel OrganizationSubLevel
		{
			get 
			{
				if (this.IsSubOrganization)
					return null;	// no sub-level
				if (organizationSubLevel == null)
					organizationSubLevel = OrganizationLevelCollection.OrganizationLevels.FindBy(this.organizationLevelID + 1); 

				return organizationSubLevel;
			}
		}

		[ControlType(ControlType=EnumControlTypes.TextBox)]
		public string OrganizationLevelDescription
		{
			get 
			{
				if (OrganizationLevel == null)
					return null;
				else
					return OrganizationLevel.Description;
			}
		}

		[ControlType(ControlType=EnumControlTypes.TextBox)]
		public string OrganizationLevelCode
		{
			get 
			{ 
				if (OrganizationLevel == null)
					return null;
				else
					return OrganizationLevel.Code;
			}
			//set { this.organizationLevelID = OrganizationLevelCollection.OrganizationLevels.Lookup_OrganizationLevelIDByCode(value); }
		}

		[ControlType(ControlType=EnumControlTypes.TextBox)]
		public string OrganizationLevelCodePlural
		{
			get 
			{ 
				if (OrganizationLevel == null)
					return null;
				else
					return OrganizationLevel.CodePlural;
			}
		}

		[ControlType(ControlType=EnumControlTypes.TextBox)]
		public string OrganizationLevelDescriptionPlural
		{
			get 
			{ 
				if (OrganizationLevel == null)
					return null;
				else
					return OrganizationLevel.DescriptionPlural;
			}
		}

		[ControlType(ControlType=EnumControlTypes.TextBox)]
		public string OrganizationSubLevelCode
		{
			get 
			{ 
				if (OrganizationSubLevel == null)
					return null;
				else
					return OrganizationSubLevel.Code;
			}
		}

		[ControlType(ControlType=EnumControlTypes.TextBox)]
		public string OrganizationSubLevelCodePlural
		{
			get 
			{ 
				if (OrganizationSubLevel == null)
					return null;
				else
					return OrganizationSubLevel.CodePlural;
			}
		}

		/// <summary>
		/// Do pre and post-insert operations of the object here.
		/// </summary>
		protected override object InternalInsert()
		{
			if (this.organizationLevelID < 1 || this.organizationLevelID > OrganizationLevel.MaxLevel)
				throw new Exception(
					String.Format("Invalid Organization Level!  Must be between ({0} and {1})", 1, OrganizationLevel.MaxLevel)
					);
			if (this.parentOrganization == null && this.organizationLevelID > 1)
				throw new Exception("An orgnization which is not the topmost level can only be saved in the context of parent");

			// Set the path of the organization for once
			if (this.organizationLevelID <= 1)
				this.organizationPath = null;		// the path is null
			else
			{
				string parentPath = this.parentOrganization.OrganizationPath;
				if (parentPath == null || parentPath == "")
					this.organizationPath = Convert.ToString(this.parentOrganization.OrganizationID);
				else
					this.organizationPath = parentPath + "." + Convert.ToString(this.parentOrganization.OrganizationID);
			}

			// Do pre-insert operations here (set members before insert, insert/update extra records etc).
			object pk = base.InternalInsert(); // always call this to ensure record flags gets updated properly.
			// Do post-insert operations here (set members after insert, insert/update extra records etc).

			return pk; // Always return primary key in case it gets generated automatically
		}

		/// <summary>
		/// If this is the max level, it's a sub organization
		/// </summary>
		public bool IsSubOrganization
		{
			get { return this.organizationLevelID == OrganizationLevel.MaxLevel; }
		}

		/// <summary>
		/// If this is the first level, this is a master organization
		/// </summary>
		public bool IsMasterOrganization
		{
			get { return this.organizationLevelID == 1; }
		}

		/// <summary>
		/// Create a child organization with the same data as this in the memory.
		/// </summary>
		/// <returns></returns>
		public Organization CopyAsChild()
		{
			if (this.IsSubOrganization)
				throw new Exception("A sub-organization can't have its child organizations");
			Organization org = new Organization(this);
			this.CopyMappedMembersTo(org, false, false, false);
			this.Address.CopyMappedMembersTo(org.Address, false, false, false);

			this.LoadOrganizationFocuses(false);
			org.LoadOrganizationFocuses(false);
			
			this.OrganizationFocuses.CopyElementsTo(org.OrganizationFocuses, false, true);		// deep copy, don't mark new

			return org;
		}

		/// <summary>
		/// Create a child organization of this organization in the memory.
		/// </summary>
		/// <returns></returns>
		public Organization CreateChild()
		{
			if (this.IsSubOrganization)
				throw new Exception("A sub-organization can't have its child organizations");
			return new Organization(this); 
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DefaultPlanSORGID
		{
			get { return this.defaultPlanSORGID; }
			set { this.defaultPlanSORGID = value; }
		}

		[FieldValuesMember("LookupOf_PrimarySynonymID", "OrganizationSynonymID", "Name")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup)]
		public int PrimarySynonymID
		{
			get { return this.primarySynonymID; }
			set { this.primarySynonymID = value; }
		}

		/// <summary>
		/// Child PlanSORGs mapped to related rows of table PlanSORGs where [OrganizationID] = [SORGID]
		/// </summary>
		[SPLoadChild("usp_LoadOrganizationPlanSORGs", "sORGID")]
		public PlanSORGCollection PlanSORGs
		{
			get { return this.planSORGs; }
			set
			{
				this.planSORGs = value;
				if (value != null)
					value.ParentOrganization = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PlanSORGs collection
		/// </summary>
		public void LoadPlanSORGs(bool forceReload)
		{
			this.planSORGs = (PlanSORGCollection)PlanSORGCollection.LoadChildCollection("PlanSORGs", this, typeof(PlanSORGCollection), planSORGs, forceReload, null);
		}

		/// <summary>
		/// Saves the PlanSORGs collection
		/// </summary>
		public void SavePlanSORGs()
		{
			PlanSORGCollection.SaveChildCollection(this.planSORGs, true);
		}

		/// <summary>
		/// Synchronizes the PlanSORGs collection
		/// </summary>
		public void SynchronizePlanSORGs()
		{
			PlanSORGCollection.SynchronizeChildCollection(this.planSORGs, true);
		}

		/// <summary>
		/// Child OrganizationContacts mapped to related rows of table OrganizationContact where [OrganizationID] = [OrganizationID]
		/// </summary>
		[SPLoadChild("usp_LoadOrganizationContacts", "organizationID")]
		public OrganizationContactCollection OrganizationContacts
		{
			get { return this.organizationContacts; }
			set
			{
				this.organizationContacts = value;
				if (value != null)
					value.ParentOrganization = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the OrganizationContacts collection
		/// </summary>
		public void LoadOrganizationContacts(bool forceReload)
		{
			this.organizationContacts = (OrganizationContactCollection)OrganizationContactCollection.LoadChildCollection("OrganizationContacts", this, typeof(OrganizationContactCollection), organizationContacts, forceReload, null);
		}

		/// <summary>
		/// Saves the OrganizationContacts collection
		/// </summary>
		public void SaveOrganizationContacts()
		{
			OrganizationContactCollection.SaveChildCollection(this.organizationContacts, true);
		}

		/// <summary>
		/// Synchronizes the OrganizationContacts collection
		/// </summary>
		public void SynchronizeOrganizationContacts()
		{
			OrganizationContactCollection.SynchronizeChildCollection(this.organizationContacts, true);
		}

		#region IContactOwner Members

		public BaseDataCollectionClass GetContacts()
		{
			if (OrganizationContacts == null) LoadOrganizationContacts(false);
			return OrganizationContacts;
		}

		public void LoadContacts(bool forceLoad)
		{
			this.LoadOrganizationContacts(forceLoad);
		}

		public void SaveContacts()
		{
			this.SaveOrganizationContacts();
		}

		public ContactOwnerType ContactOwnerType
		{
			get
			{
				return ContactOwnerType.Organization;
			}
		}

		#endregion

		

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);

			Organization[] orgs = GetParentOrganizations();
			if (orgs == null)
				return;
			for (int i= 0; i < orgs.Length; i++)
			{	
				Organization org = orgs[i];
				writer.AddLabelandValueOnNewLine(org.OrganizationLevelDescription, org.Name); // AddFieldsOnNewLine(org, "Name");
			}
		}

		/// <summary>
		/// Child Enrollments mapped to related rows of table Enrollment where [OrganizationID] = [EnrollmentID]
		/// </summary>
		[SPLoadChild("usp_LoadAllEnrollmentsByOrgaanizationId", "organizationID")]
		public EnrollmentCollection Enrollments
		{
			get { return this.enrollments; }
			set
			{
				this.enrollments = value;
				if (value != null)
					value.ParentOrganization = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Enrollments collection
		/// </summary>
		public void LoadEnrollments(bool forceReload)
		{
			this.enrollments = (EnrollmentCollection)EnrollmentCollection.LoadChildCollection("Enrollments", this, typeof(EnrollmentCollection), enrollments, forceReload, null);
		}

		/// <summary>
		/// Saves the Enrollments collection
		/// </summary>
		public void SaveEnrollments()
		{
			EnrollmentCollection.SaveChildCollection(this.enrollments, true);
		}

		/// <summary>
		/// Synchronizes the Enrollments collection
		/// </summary>
		public void SynchronizeEnrollments()
		{
			EnrollmentCollection.SynchronizeChildCollection(this.enrollments, true);
		}

		/// <summary>
		/// Return the organization synonyms that can be set as primary.
		/// Only the synonyms that are already created in the db can be set as primary.
		/// This lookup collection property detects those that are not new and makes 
		/// a new collection.
		/// </summary>
		public OrgSynonymCollection LookupOf_PrimarySynonymID
		{
			get
			{
				this.LoadOrgSynonyms(false);
				OrgSynonymCollection existingSynonyms = new OrgSynonymCollection();
				foreach (OrgSynonym syn in this.OrgSynonyms)
					if (!syn.IsNew)
						existingSynonyms.Add((OrgSynonym)syn.Clone(false));
				return existingSynonyms;
			}
		}
		}

	/// <summary>
	/// Strongly typed collection of Organization objects
	/// </summary>
	[ElementType(typeof(Organization))]
	public class OrganizationCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Organization elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOrganizationCollection = this;
			else
				elem.ParentOrganizationCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Organization elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Organization this[int index]
		{
			get
			{
				return (Organization)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Organization)oldValue, false);
			SetParentOnElem((Organization)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// This loads the collection with top organizations in the hierarchy.
		/// </summary>
		/// <param name="maxRecords"></param>
		/// <returns></returns>
		public int LoadOrgsOf(int maxRecords, Organization parentOrganization)
		{
			return LoadOrgsOf(maxRecords, parentOrganization, parentOrganization.OrganizationLevelID + 1);
		}

		public int LoadOrgsOf(int maxRecords, Organization parentOrganization, int levelID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOrganizationsByParentAndLevel", maxRecords, this, false, parentOrganization.OrganizationID, levelID);		// 1 is the top node
		}

		/// <summary>
		/// Load the collection with organizations that has a valid synonym that matches
		/// the given one.
		/// </summary>
		/// <param name="synonym"></param>
		/// <returns></returns>
		public int LoadBySynonym(string synonym, bool exactMatch, bool effectiveOnly)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchOrgsBySynonym", -1, this, 
				null, false,
				new string[] { "synonym", "exactMatch", "effectiveOnly" },
				new object[] { synonym == null?DBNull.Value:(object)synonym, exactMatch, effectiveOnly });
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchOrganizations(int maxRecords, Organization searcher)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchOrgs", maxRecords, this, searcher, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchOrganizationsBySynonym(int maxRecords, Organization searcher, string synonym, bool exactMatch, bool effectiveOnly, int level)
		{
			this.Clear();

			if (level == 0)
				return SqlData.SPExecReadCol("usp_SearchOrgsBySynonym", -1, this, 
					searcher, false,
					new string[] { "synonym", "exactMatch", "effectiveOnly" },
					new object[] { synonym == null?DBNull.Value:(object)synonym, exactMatch, effectiveOnly } );
			else
				return SqlData.SPExecReadCol("usp_SearchOrgsBySynonym", -1, this, 
					searcher, false,
					new string[] { "synonym", "exactMatch", "effectiveOnly", "parentOrganizationID", "organizationLevelID" },
					new object[] { synonym == null?DBNull.Value:(object)synonym, exactMatch, effectiveOnly, DBNull.Value, level } );
		}

		/// <summary>
		/// Parent Enrollment that contains this collection
		/// </summary>
		public Enrollment ParentEnrollment
		{
			get { return this.ParentDataObject as Enrollment; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Enrollment */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetOrganizationsByLevel(int maxRecords, int organizationLevelID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetOrganizationsByLevel", maxRecords, this, false, organizationLevelID);
		}

		/*/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public SORGCollection GetSORGs(int maxRecords)
		{
			SORGCollection sorgs = new SORGCollection();
			sorgs.LoadSORGs(maxRecords, this.organizationID);
			return sorgs;
		}*/

		/*public MORG GetParentMORG()
		{
			MORG morg = new MORG();
			if (!morg.Load(this.parentOrganizationID))
				return null;	// parent not found
			if (morg.Level != EnumOrganizationLevel.MORG)
			{
				string s = String.Format( "The parent organization of ORG {0} must be a MORG ", this.organizationID);
				Debug.Fail(s);
				throw new Exception(s);
			}
			return morg;
		}*/

	

	}

}
