using System;
using System.Collections;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [OrgSynonyms]
	/// </summary>
	[SPInsert("usp_InsertOrgSynonym")]
	[SPUpdate("usp_UpdateOrgSynonym")]
	[SPDelete("usp_DeleteOrgSynonym")]
	[SPLoad("usp_LoadOrgSynonym")]
	[TableMapping("OrganizationSynonym","organizationSynonymID")]
	public class OrgSynonym : BaseData
	{
		[NonSerialized]
		private OrgSynonymCollection parentOrgSynonymCollection;
		[ColumnMapping("OrganizationSynonymID",StereoType=DataStereoType.FK)]
		private int organizationSynonymID = 0;
		[ColumnMapping("Name",ValuesForNull.NullObject)]
		private string name;
		[ColumnMapping("OrganizationID")]
		private int organizationID;
		[ColumnMapping("EffectiveDate",ValuesForNull.NullDateTime)]
		private DateTime effectiveDate;
		[ColumnMapping("TerminationDate")]
		private DateTime terminationDate;
		
		
		//[ColumnMapping("IsPrimary")]	// not mapped to a table column
		//private bool isPrimary;
	
		public OrgSynonym()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public OrgSynonym(string name)
		{
			this.NewRecord(); // initialize record state
			this.name = name;
		}

		public OrgSynonym(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		public OrgSynonym(int organizationID)
		{
			this.NewRecord();
			this.organizationID = organizationID;
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=50)]
		[FieldDescription("@SYNONYM@")]
		public string Name
		{
			get { return this.name; }
			set { this.name = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int OrganizationID
		{
			get { return this.organizationID; }
			set { this.organizationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime EffectiveDate
		{
			get { return this.effectiveDate; }
			set { this.effectiveDate = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool IsPrimary
		{
			get 
			{
				try
				{
					return this.parentOrgSynonymCollection.ParentSubOrganization.PrimarySynonymID == this.organizationSynonymID;
				}
				catch		// instead of multi-step null checks, we just ignore
				{
					return false;
				}
			}
			set 
			{ 
				if (value && !this.IsNew)
					this.parentOrgSynonymCollection.ParentSubOrganization.PrimarySynonymID = this.organizationSynonymID;
			}
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)0)]
		[FieldDescription("@ID@")]
		public int OrganizationSynonymID
		{
			get { return this.organizationSynonymID; }
			set { this.organizationSynonymID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			base.Save();		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int organizationSynonymID)
		{
			return base.Load(organizationSynonymID);
		}

		/// <summary>
		/// Parent OrgSynonymCollection that contains this element
		/// </summary>
		public OrgSynonymCollection ParentOrgSynonymCollection
		{
			get
			{
				return this.parentOrgSynonymCollection;
			}
			set
			{
				this.parentOrgSynonymCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			this.effectiveDate = DateTime.Today;
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime TerminationDate
		{
			get { return this.terminationDate; }
			set { this.terminationDate = value; }
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddFields(this, "Name");
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of OrgSynonym objects
	/// </summary>
	[ElementType(typeof(OrgSynonym))]
	public class OrgSynonymCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_OrganizationSynonymID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(OrgSynonym elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentOrgSynonymCollection = this;
			else
				elem.ParentOrgSynonymCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (OrgSynonym elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public OrgSynonym this[int index]
		{
			get
			{
				return (OrgSynonym)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((OrgSynonym)oldValue, false);
			SetParentOnElem((OrgSynonym)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent SORG that contains this collection
		/// </summary>
		public Organization ParentSubOrganization
		{
			get { return this.ParentDataObject as Organization; }
			set { this.ParentDataObject = value; /* parent is set when contained by a SORG */ }
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(OrgSynonym elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((OrgSynonym)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Hashtable based index on organizationSynonymID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_OrganizationSynonymID
		{
			get
			{
				if (this.indexBy_OrganizationSynonymID == null)
					this.indexBy_OrganizationSynonymID = new CollectionIndexer(this, new string[] { "organizationSynonymID" }, true);
				return this.indexBy_OrganizationSynonymID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on organizationSynonymID fields returns the object.  Uses the IndexBy_OrganizationSynonymID indexer.
		/// </summary>
		public OrgSynonym FindBy(int organizationSynonymID)
		{
			return (OrgSynonym)this.IndexBy_OrganizationSynonymID.GetObject(organizationSynonymID);
		}

		/// <summary>
		/// Hashtable based search on organizationSynonymID fields returns the collection index.  Uses the IndexBy_OrganizationSynonymID indexer.
		/// </summary>
		public int IndexOf(int organizationSynonymID)
		{
			return this.IndexBy_OrganizationSynonymID.IndexOf(organizationSynonymID);
		}


		
	}


}
