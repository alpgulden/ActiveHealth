using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [DRGCode]
	/// </summary>
	[TableMapping("DRGCode")]
	public class DRGCode : BaseData
	{
		[ColumnMapping("DRGcode")]
		private string dRGcode;
		[ColumnMapping("MDC")]
		private string mDC;
		[ColumnMapping("DRGtitle")]
		private string dRGtitle;
		[ColumnMapping("DRGweight",StereoType=DataStereoType.FK)]
		private int dRGweight;
		[ColumnMapping("DRGMeanLOS",StereoType=DataStereoType.FK)]
		private int dRGMeanLOS;
		[ColumnMapping("DRGgroup")]
		private string dRGgroup;
		[ColumnMapping("DRGcategory")]
		private string dRGcategory;
		[ColumnMapping("DRGserviceclass")]
		private string dRGserviceclass;
		[ColumnMapping("DRGlowtrim",StereoType=DataStereoType.FK)]
		private int dRGlowtrim;
		[ColumnMapping("DRGhightrim",StereoType=DataStereoType.FK)]
		private int dRGhightrim;
		[ColumnMapping("DRGnewmeanLOS",StereoType=DataStereoType.FK)]
		private int dRGnewmeanLOS;
		[ColumnMapping("DRGtop20")]
		private string dRGtop20;
		[ColumnMapping("DRGType")]
		private string dRGType;
		[ColumnMapping("DRGversion")]
		private string dRGversion;
	
		public DRGCode()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=4)]
		public string DRGcode
		{
			get { return this.dRGcode; }
			set { this.dRGcode = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string MDC
		{
			get { return this.mDC; }
			set { this.mDC = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string DRGtitle
		{
			get { return this.dRGtitle; }
			set { this.dRGtitle = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DRGweight
		{
			get { return this.dRGweight; }
			set { this.dRGweight = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DRGMeanLOS
		{
			get { return this.dRGMeanLOS; }
			set { this.dRGMeanLOS = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string DRGgroup
		{
			get { return this.dRGgroup; }
			set { this.dRGgroup = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string DRGcategory
		{
			get { return this.dRGcategory; }
			set { this.dRGcategory = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string DRGserviceclass
		{
			get { return this.dRGserviceclass; }
			set { this.dRGserviceclass = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DRGlowtrim
		{
			get { return this.dRGlowtrim; }
			set { this.dRGlowtrim = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DRGhightrim
		{
			get { return this.dRGhightrim; }
			set { this.dRGhightrim = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int DRGnewmeanLOS
		{
			get { return this.dRGnewmeanLOS; }
			set { this.dRGnewmeanLOS = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string DRGtop20
		{
			get { return this.dRGtop20; }
			set { this.dRGtop20 = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4)]
		public string DRGType
		{
			get { return this.dRGType; }
			set { this.dRGType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=1)]
		public string DRGversion
		{
			get { return this.dRGversion; }
			set { this.dRGversion = value; }
		}
	}
}
