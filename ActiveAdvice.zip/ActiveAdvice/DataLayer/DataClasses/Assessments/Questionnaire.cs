using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	public class SelectableQuestionnaire : Questionnaire
	{
		private bool selected;

		public bool Selected
		{
			get {return selected;}
			set {selected = value;}
		}
	} 

	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[SPAutoGen("usp_GetAllQuestionnairesByActive","SelectAllByGivenArgsOrderBy.sptpl","sortOrder, ASC, active", InjectOrderBy="ORDER BY [Questionnaire].[SortOrder]")]
	[SPAutoGen("usp_SearchQuestionnaires","SearchByArgs.sptpl","activeWithAll:active, description, contentOwnerID, questionnaireTypeID, cMSTypeID", InjectOrderBy="ORDER BY  [Questionnaire].[SortOrder] ASC")]
	[SPInsert("usp_InsertQuestionnaire")]
	[SPUpdate("usp_UpdateQuestionnaire")]
	[SPLoad("usp_LoadQuestionnaire")]
	[TableMapping("Questionnaire","questionnaireID")]
	public class Questionnaire : BaseAssessment
	{
		[NonSerialized]
		protected QuestionnaireCollection parentQuestionnaireCollection;
		[ColumnMapping("QuestionnaireID",StereoType=DataStereoType.FK)]
		protected int questionnaireID;
		[ColumnMapping("ContentOwnerID",StereoType=DataStereoType.FK)]
		protected int contentOwnerID;
		[ColumnMapping("Description")]
		protected string description;
		[ColumnMapping("QuestionnaireTypeID",StereoType=DataStereoType.FK)]
		protected int questionnaireTypeID;
		[ColumnMapping("CMSTypeID",StereoType=DataStereoType.FK)]
		protected int cMSTypeID;
		[ColumnMapping("Active")]
		protected bool active = true;
		[ColumnMapping("SortOrder")]
		protected int sortOrder = 0;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		protected int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		protected QuestionnaireTriggerCollection triggers;
		protected QuestionnairePresentationGroupCollection presentationGroups;
	
		public Questionnaire(): base()
		{
		}

		public Questionnaire(int questionnaireID)
		{
			this.NewRecord(); // initialize record state
			this.questionnaireID = questionnaireID;
		}

		public Questionnaire(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int questionnaireID)
		{
			return base.Load(questionnaireID);
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		//[FieldDescription("@QUESTIONNAIREID@")]
		[FieldDescription("@ID@")]
		public int QuestionnaireID
		{
			get { return this.questionnaireID; }
			set { this.questionnaireID = value; }
		}

		[FieldValuesMember("LookupOf_ContentOwnerID", "ContentOwnerID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CONTENTOWNER@")]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255, IsRequired=true)]
		[FieldDescription("@DESCRIPTION@")]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[FieldValuesMember("LookupOf_QuestionnaireTypeID", "QuestionnaireTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@QUESTIONNAIRETYPE@")]
		public int QuestionnaireTypeID
		{
			get { return this.questionnaireTypeID; }
			set { this.questionnaireTypeID = value; }
		}

		[FieldValuesMember("LookupOf_CMSTypeID", "CMSTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CMSTYPE@")]
		public int CMSTypeID
		{
			get { return this.cMSTypeID; }
			set { this.cMSTypeID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		[FieldDescription("@ACTIVE@")]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent QuestionnaireCollection that contains this element
		/// </summary>
		public QuestionnaireCollection ParentQuestionnaireCollection
		{
			get
			{
				return this.parentQuestionnaireCollection;
			}
			set
			{
				this.parentQuestionnaireCollection = value; // parent is set when added to a collection
			}
		}

		public ContentOwnerCollection LookupOf_ContentOwnerID
		{
			get
			{
				return ContentOwnerCollection.ActiveContentOwners; // Acquire a shared instance from the static member of collection
			}
		}

		public QuestionnaireTypeCollection LookupOf_QuestionnaireTypeID
		{
			get
			{
				QuestionnaireTypeCollection col = new QuestionnaireTypeCollection();
				QuestionnaireType qt = new QuestionnaireType();
					qt.QuestionnaireTypeID = -1;
					qt.Description = "All";
					col.AddRecord(qt);
				col.CopyElementsFrom(QuestionnaireTypeCollection.ActiveQuestionnaireTypes, true, false);
				return col;
			}
			
		}

		public CMSTypeCollection LookupOf_CMSTypeID
		{
			get
			{
				return CMSTypeCollection.ActiveCMSTypes; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Child Triggers mapped to related rows of table QuestionnaireTrigger where [QuestionnaireID] = [QuestionnaireID]
		/// </summary>
		[SPLoadChild("usp_LoadQuestionnaireTriggers", "questionnaireID")]
		public QuestionnaireTriggerCollection Triggers
		{
			get { return this.triggers; }
			set
			{
				this.triggers = value;
				if (value != null)
					value.ParentQuestionnaire = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the QuestionnaireTriggers collection
		/// </summary>
		public void LoadTriggers(bool forceReload)
		{
			this.triggers = (QuestionnaireTriggerCollection)QuestionnaireTriggerCollection.LoadChildCollection("Triggers", this, typeof(QuestionnaireTriggerCollection), triggers, forceReload, null);
		}

		/// <summary>
		/// Saves the QuestionnaireTriggers collection
		/// </summary>
		public void SaveTriggers()
		{
			QuestionnaireTriggerCollection.SaveChildCollection(this.triggers, true);
		}

		/// <summary>
		/// Synchronizes the QuestionnaireTriggers collection
		/// </summary>
		public void SynchronizeTriggers()
		{
			QuestionnaireTriggerCollection.SynchronizeChildCollection(this.triggers, true);
		}

		/// <summary>
		/// Child QuestionnairePresentationGroups mapped to related rows of table QuestionnairePresentationGroup where [QuestionnaireID] = [QuestionnaireID]
		/// </summary>
		[SPLoadChild("usp_LoadQuestionnairePresentationGroups", "questionnaireID")]
		public QuestionnairePresentationGroupCollection PresentationGroups
		{
			get { return this.presentationGroups; }
			set
			{
				this.presentationGroups = value;
				if (value != null)
					value.ParentQuestionnaire = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the QuestionnairePresentationGroups collection
		/// </summary>
		public void LoadPresentationGroups(bool forceReload)
		{
			this.presentationGroups = (QuestionnairePresentationGroupCollection)QuestionnairePresentationGroupCollection.LoadChildCollection("PresentationGroups", this, typeof(QuestionnairePresentationGroupCollection), presentationGroups, forceReload, null);
		}

		/// <summary>
		/// Saves the QuestionnairePresentationGroups collection
		/// </summary>
		public void SavePresentationGroups()
		{
			QuestionnairePresentationGroupCollection.SaveChildCollection(this.presentationGroups, true);
		}

		/// <summary>
		/// Synchronizes the QuestionnairePresentationGroups collection
		/// </summary>
		public void SynchronizePresentationGroups()
		{
			QuestionnairePresentationGroupCollection.SynchronizeChildCollection(this.presentationGroups, true);
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		/// <summary>
		/// Parent AssessmentQuestionnaireOrder that contains this object
		/// </summary>
		public AssessmentQuestionnaireOrder ParentAssessmentQuestionnaireOrder
		{
			get { return this.ParentDataObject as AssessmentQuestionnaireOrder; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AssessmentQuestionnaireOrder */ }
		}

	}

	/// <summary>
	/// Strongly typed collection of Questionnaire objects
	/// </summary>
	[ElementType(typeof(Questionnaire))]
	public class QuestionnaireCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_QuestionnaireID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Questionnaire elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentQuestionnaireCollection = this;
			else
				elem.ParentQuestionnaireCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Questionnaire elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Questionnaire this[int index]
		{
			get
			{
				return (Questionnaire)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Questionnaire)oldValue, false);
			SetParentOnElem((Questionnaire)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchQuestionnaires(int maxRecords, Questionnaire searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchQuestionnaires", maxRecords, this, searcher, false, new string[] {"activeWithAll"}, new object[] {activeWithAll});
		}
		
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchQuestionnairesByOrganization(int maxRecords, QuestionnaireOrganizationSearcher searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			this.Clear();
			this.ElementType = typeof(SelectableQuestionnaire);
			return SqlData.SPExecReadCol("usp_GetAllQuestionnairesBySorgOrgMorg", maxRecords, this, searcher, false);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadForSelection(int maxRecords, Questionnaire searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			this.Clear();
			this.ElementType = typeof(SelectableQuestionnaire);
			return SqlData.SPExecReadCol("usp_SearchQuestionnaires", maxRecords, this, searcher, false, new string[] {"activeWithAll"}, new object[] {activeWithAll});
		}


		public static QuestionnaireCollection GetQuestionnairesForSelection(Questionnaire searcher)
		{
			QuestionnaireCollection col = new QuestionnaireCollection();
			// initialize the content of the collection
			col.LoadForSelection(-1, searcher);
			return col;
		}

		public static QuestionnaireCollection GetQuestionnairesByOrganization(QuestionnaireOrganizationSearcher searcher)
		{
			QuestionnaireCollection col = new QuestionnaireCollection();
			col.SearchQuestionnairesByOrganization(-1, searcher);
			return col;
		}

		public void SetSelectedQuestionnairesFromCollection(QuestionnaireOrganizationCollection selectedQuestionnaires)
		{
			QuestionnaireOrganization existingQuestionnaireOrganization = null;
			foreach (Questionnaire questionnaire in this)
			{
				existingQuestionnaireOrganization = selectedQuestionnaires.FindBy(questionnaire.QuestionnaireID);
				if (existingQuestionnaireOrganization != null && !existingQuestionnaireOrganization.IsMarkedForDeletion)
					((SelectableQuestionnaire)questionnaire).Selected = true;
			}
		}

		public void SetSelectedQuestionnairesFromCollection(AssessmentQuestionnaireOrderCollection selectedQuestionnaires)
		{
			AssessmentQuestionnaireOrder existingAssessmentQuestionnaireOrder = null;
			foreach (Questionnaire questionnaire in this)
			{
				existingAssessmentQuestionnaireOrder = selectedQuestionnaires.FindBy(questionnaire.QuestionnaireID);
				if (existingAssessmentQuestionnaireOrder != null && !existingAssessmentQuestionnaireOrder.IsMarkedForDeletion)
					((SelectableQuestionnaire)questionnaire).Selected = true;
			}
		}

		/// <summary>
		/// Hashtable based index on questionnaireID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_QuestionnaireID
		{
			get
			{
				if (this.indexBy_QuestionnaireID == null)
					this.indexBy_QuestionnaireID = new CollectionIndexer(this, new string[] { "questionnaireID" }, true);
				return this.indexBy_QuestionnaireID;
			}
		}

		/// <summary>
		/// Hashtable based search on questionnaireID fields returns the object.  Uses the IndexBy_QuestionnaireID indexer.
		/// </summary>
		public Questionnaire FindBy(int questionnaireID)
		{
			return (Questionnaire)this.IndexBy_QuestionnaireID.GetObject(questionnaireID);
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllQuestionnairesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllQuestionnairesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared QuestionnaireCollection which is cached in NSGlobal
		/// </summary>
		public static QuestionnaireCollection ActiveQuestionnaires
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				QuestionnaireCollection col = (QuestionnaireCollection)NSGlobal.EnsureCachedObject("ActiveQuestionnaires", typeof(QuestionnaireCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllQuestionnairesByActive(-1, true);
				}
				return col;
			}
			
		}

		
	}
}
