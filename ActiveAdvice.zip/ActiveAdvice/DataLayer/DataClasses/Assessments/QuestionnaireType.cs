using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[SPAutoGen("usp_SearchQuestionnaireTypesByActive","SelectAllByGivenArgs.sptpl","active")] 
	[SPInsert("usp_InsertQuestionnaireType")]
	[SPUpdate("usp_UpdateQuestionnaireType")]
	[SPLoad("usp_LoadQuestionnaireType")]
	[TableMapping("QuestionnaireType","questionnaireTypeID")]
	public class QuestionnaireType : BaseLookupWithCode
	{
		[NonSerialized]
		private QuestionnaireTypeCollection parentQuestionnaireTypeCollection;
		[ColumnMapping("QuestionnaireTypeID",StereoType=DataStereoType.FK)]
		private int questionnaireTypeID;
		[ColumnMapping("NotePad")]
		private string notePad;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public QuestionnaireType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QuestionnaireTypeID
		{
			get { return this.questionnaireTypeID; }
			set { this.questionnaireTypeID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}

		/// <summary>
		/// Parent QuestionnaireTypeCollection that contains this element
		/// </summary>
		public QuestionnaireTypeCollection ParentQuestionnaireTypeCollection
		{
			get
			{
				return this.parentQuestionnaireTypeCollection;
			}
			set
			{
				this.parentQuestionnaireTypeCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of QuestionnaireType objects
	/// </summary>
	[ElementType(typeof(QuestionnaireType))]
	public class QuestionnaireTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(QuestionnaireType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentQuestionnaireTypeCollection = this;
			else
				elem.ParentQuestionnaireTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (QuestionnaireType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public QuestionnaireType this[int index]
		{
			get
			{
				return (QuestionnaireType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((QuestionnaireType)oldValue, false);
			SetParentOnElem((QuestionnaireType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetQuestionnaireTypes(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchQuestionnaireTypesByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared QuestionnaireTypeCollection which is cached in NSGlobal
		/// </summary>
		public static QuestionnaireTypeCollection ActiveQuestionnaireTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				QuestionnaireTypeCollection col = (QuestionnaireTypeCollection)NSGlobal.EnsureCachedObject("ActiveQuestionnaireTypes", typeof(QuestionnaireTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetQuestionnaireTypes(-1, true);
				}
				return col;
			}
			
		}
	}
}
