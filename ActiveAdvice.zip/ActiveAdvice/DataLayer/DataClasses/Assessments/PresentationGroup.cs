using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	public class SelectablePresentationGroup : PresentationGroup
	{
		private bool selected;

		public bool Selected
		{
			get {return selected;}
			set {selected = value;}
		}
	}

	/// <summary>
	/// Data class that wraps the entity access functionality to table [PresentationGroup]
	/// </summary>
	[SPAutoGen("usp_GetPresentationGroupsByContentOwnerID","SelectAllByGivenArgs.sptpl","contentOwnerID")]
	[SPAutoGen("usp_SearchPresentationGroups","SearchByArgs.sptpl","activeWithAll:active, description, contentOwnerID")]
	[SPInsert("usp_InsertPresentationGroup")]
	[SPUpdate("usp_UpdatePresentationGroup")]
	[SPLoad("usp_LoadPresentationGroup")]
	[TableMapping("PresentationGroup","presentationGroupID")]
	public class PresentationGroup : BaseAssessment
	{
		[NonSerialized]
		protected PresentationGroupCollection parentPresentationGroupCollection;
		[ColumnMapping("PresentationGroupID",StereoType=DataStereoType.FK)]
		protected int presentationGroupID;
		[ColumnMapping("Description")]
		protected string description;
		[ColumnMapping("ContentOwnerID",StereoType=DataStereoType.FK)]
		protected int contentOwnerID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		protected DateTime createTime;
		[ColumnMapping("ModifyTime")]
		protected DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		protected int modifiedBy;
		[ColumnMapping("Active")]
		protected bool active = true;
		private PresentationGroupQuestionCollection questions;
	
		public PresentationGroup(): base()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PresentationGroup(int presentationGroupID)
		{
			this.NewRecord(); // initialize record state
			this.presentationGroupID = presentationGroupID;
		}

		public PresentationGroup(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int presentationGroupID)
		{
			return base.Load(presentationGroupID);
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@PRESENTATIONGROUPID@")]
		public int PresentationGroupID
		{
			get { return this.presentationGroupID; }
			set { this.presentationGroupID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=4000)]
		[FieldDescription("@DESCRIPTION@")]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[FieldValuesMember("LookupOf_ContentOwnerID", "ContentOwnerID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CONTENTOWNER@")]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}


		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		[FieldDescription("@ACTIVE@")]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		public ContentOwnerCollection LookupOf_ContentOwnerID
		{
			get
			{
				return ContentOwnerCollection.ActiveContentOwners; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Parent PresentationGroupCollection that contains this element
		/// </summary>
		public PresentationGroupCollection ParentPresentationGroupCollection
		{
			get
			{
				return this.parentPresentationGroupCollection;
			}
			set
			{
				this.parentPresentationGroupCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Child PresentationGroupQuestions mapped to related rows of table PresentationGroupQuestion where [PresentationGroupID] = [PresentationGroupID]
		/// </summary>
		[SPLoadChild("usp_LoadPresentationGroupQuestions", "presentationGroupID")]
		public PresentationGroupQuestionCollection Questions
		{
			get { return this.questions; }
			set
			{
				this.questions = value;
				if (value != null)
					value.ParentPresentationGroup = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PresentationGroupQuestions collection
		/// </summary>
		public void LoadPresentationGroupQuestions(bool forceReload)
		{
			this.questions = (PresentationGroupQuestionCollection)PresentationGroupQuestionCollection.LoadChildCollection("Questions", this, typeof(PresentationGroupQuestionCollection), questions, forceReload, null);
		}

		/// <summary>
		/// Saves the PresentationGroupQuestions collection
		/// </summary>
		public void SavePresentationGroupQuestions()
		{
			PresentationGroupQuestionCollection.SaveChildCollection(this.questions, true);
		}

		/// <summary>
		/// Synchronizes the PresentationGroupQuestions collection
		/// </summary>
		public void SynchronizePresentationGroupQuestions()
		{
			PresentationGroupQuestionCollection.SynchronizeChildCollection(this.questions, true);
		}

		/// <summary>
		/// Parent QuestionnairePresentationGroupOrder that contains this object
		/// </summary>
		public QuestionnairePresentationGroupOrder ParentQuestionnairePresentationGroupOrder
		{
			get { return this.ParentDataObject as QuestionnairePresentationGroupOrder; }
			set { this.ParentDataObject = value; /* parent is set when contained by a QuestionnairePresentationGroupOrder */ }
		}

	}

	/// <summary>
	/// Strongly typed collection of PresentationGroup objects
	/// </summary>
	[ElementType(typeof(PresentationGroup))]
	public class PresentationGroupCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_PresentationGroupID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PresentationGroup elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPresentationGroupCollection = this;
			else
				elem.ParentPresentationGroupCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PresentationGroup elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PresentationGroup this[int index]
		{
			get
			{
				return (PresentationGroup)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PresentationGroup)oldValue, false);
			SetParentOnElem((PresentationGroup)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}


		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int SearchPresentationGroups(int maxRecords, PresentationGroup searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchPresentationGroups", maxRecords, this, searcher, false, new string[] {"activeWithAll"}, new object[] {activeWithAll});
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadByContentOwnerForSelection(int maxRecords, int contentOwnerID)
		{
			this.Clear();
			this.ElementType = typeof(SelectablePresentationGroup);
			return SqlData.SPExecReadCol("usp_GetPresentationGroupsByContentOwnerID", maxRecords, this, false, contentOwnerID);
		}


		public static PresentationGroupCollection GetPresentationGroupsByContentOwnerForSelection(int contentOwnerID)
		{
			// Get a cached instance of the collection
			PresentationGroupCollection col = new PresentationGroupCollection();
			// initialize the content of the collection
			col.LoadByContentOwnerForSelection(-1, contentOwnerID);
			return col;
		}

		public void SetSelectedPresentationGroupsFromCollection(QuestionnairePresentationGroupCollection selectedPresentationGroups)
		{
			QuestionnairePresentationGroup existingQuestionnairePresentationGroup = null;
			foreach (PresentationGroup presentationGroup in this)
			{
				existingQuestionnairePresentationGroup = selectedPresentationGroups.FindBy(presentationGroup.PresentationGroupID);
				if (existingQuestionnairePresentationGroup != null && !existingQuestionnairePresentationGroup.IsMarkedForDeletion)
					((SelectablePresentationGroup)presentationGroup).Selected = true;
			}
		}

		/// <summary>
		/// Hashtable based index on presentationGroupID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_PresentationGroupID
		{
			get
			{
				if (this.indexBy_PresentationGroupID == null)
					this.indexBy_PresentationGroupID = new CollectionIndexer(this, new string[] { "presentationGroupID" }, true);
				return this.indexBy_PresentationGroupID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on presentationGroupID fields returns the object.  Uses the IndexBy_PresentationGroupID indexer.
		/// </summary>
		public PresentationGroup FindBy(int presentationGroupID)
		{
			return (PresentationGroup)this.IndexBy_PresentationGroupID.GetObject(presentationGroupID);
		}

	}
}
