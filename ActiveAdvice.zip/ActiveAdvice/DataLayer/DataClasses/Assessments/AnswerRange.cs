using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[SPAutoGen("usp_SearchAnswerRanges","SearchByArgs.sptpl","answerRangeID, contentOwnerID, answerID")]
	[SPInsert("usp_InsertAnswerRange")]
	[SPUpdate("usp_UpdateAnswerRange")]
	[SPDelete("usp_DeleteAnswerRange")]
	[SPLoad("usp_LoadAnswerRange")]
	[TableMapping("AnswerRange","answerRangeID")]
	public class AnswerRange : BaseData
	{
		[NonSerialized]
		private AnswerRangeCollection parentAnswerRangeCollection;
		[ColumnMapping("AnswerRangeID",StereoType=DataStereoType.FK)]
		private int answerRangeID;
		[ColumnMapping("ContentOwnerID",StereoType=DataStereoType.FK)]
		private int contentOwnerID;
		[ColumnMapping("AnswerID",StereoType=DataStereoType.FK)]
		private int answerID;
		[ColumnMapping("LowValue")]
		private Decimal lowValue;
		[ColumnMapping("LowOp")]
		private string lowOp;
		[ColumnMapping("HighValue")]
		private Decimal highValue;
		[ColumnMapping("HighOp")]
		private string highOp;
		[ColumnMapping("Active")]
		private bool active = true;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;

		private AssessmentLevelOfDiseaseCollection assessmentLevelOfDiseases;
		// private AssessmentPOCDeficitCollection assessmentPOCDeficits;
		private AssessmentRiskCollection assessmentRisks;
		private AssessmentMeasurementCollection assessmentMeasurements;
	
		public AnswerRange() : base()
		{
		}

		public AnswerRange(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int AnswerRangeID
		{
			get { return this.answerRangeID; }
			set { this.answerRangeID = value; }
		}

		public void LoadFullTree(bool forceReload)
		{
			this.LoadAssessmentLevelOfDiseases(forceReload);
			this.LoadAssessmentMeasurements(forceReload);
			//this.LoadAssessmentPOCDeficits(forceReload);
			this.LoadAssessmentRisks(forceReload);
		}

		[FieldValuesMember("LookupOf_ContentOwnerID", "ContentOwnerID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CONTENTOWNER@")]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AnswerID
		{
			get { return this.answerID; }
			set { this.answerID = value; }
		}
	
		[FieldValuesMember("ValuesOf_LowOp")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public string LowOp
		{
			get { return this.lowOp; }
			set { this.lowOp = value; }
		}


		[FieldValuesMember("ValuesOf_HighOp")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup)]
		public string HighOp
		{
			get { return this.highOp; }
			set { this.highOp = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal LowValue
		{
			get { return this.lowValue; }
			set { this.lowValue = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Double)]
		public decimal HighValue
		{
			get { return this.highValue; }
			set { this.highValue = value; }
		}

		/// <summary>
		/// Parent AnswerRangeCollection that contains this element
		/// </summary>
		public AnswerRangeCollection ParentAnswerRangeCollection
		{
			get
			{
				return this.parentAnswerRangeCollection;
			}
			set
			{
				this.parentAnswerRangeCollection = value; // parent is set when added to a collection
			}
		}


		public ContentOwnerCollection LookupOf_ContentOwnerID
		{
			get
			{
				return ContentOwnerCollection.ActiveContentOwners; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			// If the record is new get the contentowner from parent answer object
			if (this.isNew && parentAnswerRangeCollection != null && parentAnswerRangeCollection.ParentAnswer != null)
			{
				Answer parentAnswer = parentAnswerRangeCollection.ParentAnswer;
				this.contentOwnerID = parentAnswer.ContentOwnerID;
			}

			// Save the contained objects that must be saved first.
			base.InternalSave();

			if (this.AssessmentLevelOfDisease.LevelOfDiseaseTypeID != 0)
				this.SaveAssessmentLevelOfDiseases();
			//this.SaveAssessmentPOCDeficits();
			if (this.AssessmentRisk.RiskTypeID != 0)
				this.SaveAssessmentRisks();
			if (this.AssessmentMeasurement.MeasurementTypeID != 0)
				this.SaveAssessmentMeasurements();
		}



		public AssessmentLevelOfDisease AssessmentLevelOfDisease
		{
			get 
			{
				LoadAssessmentLevelOfDiseases(false);
				if (this.assessmentLevelOfDiseases.Count > 0)
				{
					if (this.assessmentLevelOfDiseases.Count > 1)
						throw new Exception(String.Format("An answer range can be directly linked to only one LOD, AnswerRangeID = {0}", this.answerRangeID));
					return this.assessmentLevelOfDiseases[0];
				}
				else
				{
					// create a new one
					AssessmentLevelOfDisease lod = new AssessmentLevelOfDisease(true);
					this.AssessmentLevelOfDiseases.AddRecord(lod);
					return lod;
				}

				return null;
			}
		}

		/// <summary>
		/// Child AssessmentLevelOfDiseases mapped to related rows of table AssessmentLevelOfDisease where [AnswerID] = [AnswerID]
		/// </summary>
		[SPLoadChild("usp_LoadAnswerRangeAssessmentLevelOfDisease", "answerRangeID")]
		public AssessmentLevelOfDiseaseCollection AssessmentLevelOfDiseases
		{
			get { return this.assessmentLevelOfDiseases; }
			set
			{
				this.assessmentLevelOfDiseases = value;
				if (value != null)
					value.ParentAnswerRange = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the AssessmentLevelOfDiseases collection
		/// </summary>
		public void LoadAssessmentLevelOfDiseases(bool forceReload)
		{
			this.assessmentLevelOfDiseases = (AssessmentLevelOfDiseaseCollection)AssessmentLevelOfDiseaseCollection.LoadChildCollection("AssessmentLevelOfDiseases", this, typeof(AssessmentLevelOfDiseaseCollection), assessmentLevelOfDiseases, forceReload, null);
		}

		/// <summary>
		/// Saves the AssessmentLevelOfDiseases collection
		/// </summary>
		public void SaveAssessmentLevelOfDiseases()
		{
			AssessmentLevelOfDiseaseCollection.SaveChildCollection(this.assessmentLevelOfDiseases, true);
		}

		/// <summary>
		/// Synchronizes the AssessmentLevelOfDiseases collection
		/// </summary>
		public void SynchronizeAssessmentLevelOfDiseases()
		{
			AssessmentLevelOfDiseaseCollection.SynchronizeChildCollection(this.assessmentLevelOfDiseases, true);
		}


		/* Feature removed

		public AssessmentPOCDeficit AssessmentPOCDeficit
		{
			get 
			{
				LoadAssessmentPOCDeficits(false);
				if (this.assessmentPOCDeficits.Count > 0)
				{
					if (this.assessmentPOCDeficits.Count > 1)
						throw new Exception(String.Format("An answer range can be directly linked to only one Deficit, AnswerRangeID = {0}", this.answerRangeID));
					return this.assessmentPOCDeficits[0];
				}

				return null;
			}
		}

		/// <summary>
		/// Child AssessmentPOCDeficits mapped to related rows of table AssessmentPOCDeficit where [AnswerID] = [AnswerID]
		/// </summary>
		[SPLoadChild("usp_LoadAnswerRangeAssessmentPOCDeficit", "answerRangeID")]
		public AssessmentPOCDeficitCollection AssessmentPOCDeficits
		{
			get { return this.assessmentPOCDeficits; }
			set
			{
				this.assessmentPOCDeficits = value;
				if (value != null)
					value.ParentAnswerRange = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the AssessmentPOCDeficits collection
		/// </summary>
		public void LoadAssessmentPOCDeficits(bool forceReload)
		{
			this.assessmentPOCDeficits = (AssessmentPOCDeficitCollection)AssessmentPOCDeficitCollection.LoadChildCollection("AssessmentPOCDeficits", this, typeof(AssessmentPOCDeficitCollection), assessmentPOCDeficits, forceReload, null);
		}

		/// <summary>
		/// Saves the AssessmentPOCDeficits collection
		/// </summary>
		public void SaveAssessmentPOCDeficits()
		{
			AssessmentPOCDeficitCollection.SaveChildCollection(this.assessmentPOCDeficits, true);
		}

		/// <summary>
		/// Synchronizes the AssessmentPOCDeficits collection
		/// </summary>
		public void SynchronizeAssessmentPOCDeficits()
		{
			AssessmentPOCDeficitCollection.SynchronizeChildCollection(this.assessmentPOCDeficits, true);
		}
		
		*/


		public AssessmentRisk AssessmentRisk
		{
			get 
			{
				LoadAssessmentRisks(false);
				if (this.assessmentRisks.Count > 0)
				{
					if (this.assessmentRisks.Count > 1)
						throw new Exception(String.Format("An answer range can be directly linked to only one Risk, AnswerRangeID = {0}", this.answerRangeID));
					return this.assessmentRisks[0];
				}
				else
				{
					// create a new one
					AssessmentRisk risk = new AssessmentRisk(true);
					this.AssessmentRisks.AddRecord(risk);
					return risk;
				}

				return null;
			}
		}


		/// <summary>
		/// Child AssessmentRisks mapped to related rows of table AssessmentRisk where [AnswerID] = [AnswerID]
		/// </summary>
		[SPLoadChild("usp_LoadAnswerRangeAssessmentRisk", "answerRangeID")]
		public AssessmentRiskCollection AssessmentRisks
		{
			get { return this.assessmentRisks; }
			set
			{
				this.assessmentRisks = value;
				if (value != null)
					value.ParentAnswerRange = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the AssessmentRisks collection
		/// </summary>
		public void LoadAssessmentRisks(bool forceReload)
		{
			this.assessmentRisks = (AssessmentRiskCollection)AssessmentRiskCollection.LoadChildCollection("AssessmentRisks", this, typeof(AssessmentRiskCollection), assessmentRisks, forceReload, null);
		}

		/// <summary>
		/// Saves the AssessmentRisks collection
		/// </summary>
		public void SaveAssessmentRisks()
		{
			AssessmentRiskCollection.SaveChildCollection(this.assessmentRisks, true);
		}

		/// <summary>
		/// Synchronizes the AssessmentRisks collection
		/// </summary>
		public void SynchronizeAssessmentRisks()
		{
			AssessmentRiskCollection.SynchronizeChildCollection(this.assessmentRisks, true);
		}


		public AssessmentMeasurement AssessmentMeasurement
		{
			get 
			{
				LoadAssessmentMeasurements(false);
				if (this.assessmentMeasurements.Count > 0)
				{
					if (this.assessmentMeasurements.Count > 1)
						throw new Exception(String.Format("An answer range can be directly linked to only one Measurement, AnswerRangeID = {0}", this.answerRangeID));
					return this.assessmentMeasurements[0];
				}
				else
				{
					// create a new one
					AssessmentMeasurement mes = new AssessmentMeasurement(true);
					this.AssessmentMeasurements.AddRecord(mes);
					return mes;
				}

				return null;
			}
		}

		/// <summary>
		/// Child AssessmentMeasurements mapped to related rows of table AssessmentMeasurement where [AnswerRangeID] = [AnswerRangeID]
		/// </summary>
		[SPLoadChild("usp_LoadAnswerRangeAssessmentMeasurement", "answerRangeID")]
		public AssessmentMeasurementCollection AssessmentMeasurements
		{
			get { return this.assessmentMeasurements; }
			set
			{
				this.assessmentMeasurements = value;
				if (value != null)
					value.ParentAnswerRange = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the AssessmentMeasurements collection
		/// </summary>
		public void LoadAssessmentMeasurements(bool forceReload)
		{
			this.assessmentMeasurements = (AssessmentMeasurementCollection)AssessmentMeasurementCollection.LoadChildCollection("AssessmentMeasurements", this, typeof(AssessmentMeasurementCollection), assessmentMeasurements, forceReload, null);
		}

		/// <summary>
		/// Saves the AssessmentMeasurements collection
		/// </summary>
		public void SaveAssessmentMeasurements()
		{
			AssessmentMeasurementCollection.SaveChildCollection(this.assessmentMeasurements, true);
		}

		/// <summary>
		/// Synchronizes the AssessmentMeasurements collection
		/// </summary>
		public void SynchronizeAssessmentMeasurements()
		{
			AssessmentMeasurementCollection.SynchronizeChildCollection(this.assessmentMeasurements, true);
		}


	}

	/// <summary>
	/// Strongly typed collection of AnswerRange objects
	/// </summary>
	[ElementType(typeof(AnswerRange))]
	public class AnswerRangeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AnswerRange elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAnswerRangeCollection = this;
			else
				elem.ParentAnswerRangeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AnswerRange elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AnswerRange this[int index]
		{
			get
			{
				return (AnswerRange)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AnswerRange)oldValue, false);
			SetParentOnElem((AnswerRange)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAnswerRanges(int maxRecords, AnswerRange searcher)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchAnswerRanges", maxRecords, this, searcher, false);
		}

		/// <summary>
		/// Parent Answer that contains this collection
		/// </summary>
		public Answer ParentAnswer
		{
			get { return this.ParentDataObject as Answer; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Answer */ }
		}
	}
}
