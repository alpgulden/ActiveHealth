using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[SPAutoGen("usp_GetQuestionnaireTriggersByQuestionnaireID","SelectAllByGivenArgs.sptpl","questionnaireID")]
	[SPInsert("usp_InsertQuestionnaireTrigger")]
	[SPUpdate("usp_UpdateQuestionnaireTrigger")]
	[SPDelete("usp_DeleteQuestionnaireTrigger")]
	[SPLoad("usp_LoadQuestionnaireTrigger")]
	[TableMapping("QuestionnaireTrigger","questionnaireTriggerID")]
	public class QuestionnaireTrigger : BaseData
	{
		[NonSerialized]
		private QuestionnaireTriggerCollection parentQuestionnaireTriggerCollection;
		[ColumnMapping("QuestionnaireTriggerID",StereoType=DataStereoType.FK)]
		private int questionnaireTriggerID;
		[ColumnMapping("QuestionnaireID",StereoType=DataStereoType.FK)]
		private int questionnaireID;
		[ColumnMapping("DiagOrProc")]
		private string diagOrProc;
		[ColumnMapping("CodeType")]
		private string codeType;
		[ColumnMapping("CodeStart")]
		private string codeStart;
		[ColumnMapping("CodeEnd")]
		private string codeEnd;
		[ColumnMapping("Active")]
		private bool active = true;
		[ColumnMapping("ContentOwnerID",StereoType=DataStereoType.FK)]
		private int contentOwnerID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
	
		public QuestionnaireTrigger() : base()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public QuestionnaireTrigger(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		//[FieldDescription("@QUESTIONNAIRETRIGGERID@")]
		[FieldDescription("@ID@")]
		public int QuestionnaireTriggerID
		{
			get { return this.questionnaireTriggerID; }
			set { this.questionnaireTriggerID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		[FieldDescription("@QUESTIONNAIREID@")]
		public int QuestionnaireID
		{
			get { return this.questionnaireID; }
			set { this.questionnaireID = value; }
		}

		[FieldDescription("@DIAGORPROC@")]
		[FieldValuesMember("ValuesOf_DiagOrProc")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, IsRequired=true)]
		public string DiagOrProc
		{
			get { return this.diagOrProc; }
			set { this.diagOrProc = value; }
		}

		[FieldDescription("@CODETYPE@")]
		[FieldValuesMember("ValuesOf_CodeType")]
		[ControlType(Macro=EnumControlTypeMacros.StringLookup, IsRequired=true)]
		public string CodeType
		{
			get { return this.codeType; }
			set { this.codeType = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=8)]
		[FieldDescription("@STARTCODE@")]
		public string CodeStart
		{
			get { return this.codeStart; }
			set { this.codeStart = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=8)]
		[FieldDescription("@ENDCODE@")]
		public string CodeEnd
		{
			get { return this.codeEnd; }
			set { this.codeEnd = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		[FieldDescription("@ACTIVE@")]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[FieldValuesMember("LookupOf_ContentOwnerID", "ContentOwnerID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CONTENTOWNER@")]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		public ContentOwnerCollection LookupOf_ContentOwnerID
		{
			get
			{
				return ContentOwnerCollection.ActiveContentOwners; // Acquire a shared instance from the static member of collection
			}
		}

		/// <summary>
		/// Parent QuestionnaireTriggerCollection that contains this element
		/// </summary>
		public QuestionnaireTriggerCollection ParentQuestionnaireTriggerCollection
		{
			get
			{
				return this.parentQuestionnaireTriggerCollection;
			}
			set
			{
				this.parentQuestionnaireTriggerCollection = value; // parent is set when added to a collection
			}
		}


	}

	/// <summary>
	/// Strongly typed collection of QuestionnaireTrigger objects
	/// </summary>
	[ElementType(typeof(QuestionnaireTrigger))]
	public class QuestionnaireTriggerCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(QuestionnaireTrigger elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentQuestionnaireTriggerCollection = this;
			else
				elem.ParentQuestionnaireTriggerCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (QuestionnaireTrigger elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public QuestionnaireTrigger this[int index]
		{
			get
			{
				return (QuestionnaireTrigger)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((QuestionnaireTrigger)oldValue, false);
			SetParentOnElem((QuestionnaireTrigger)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent Questionnaire that contains this collection
		/// </summary>
		public Questionnaire ParentQuestionnaire
		{
			get { return this.ParentDataObject as Questionnaire; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Questionnaire */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetQuestionnaireTriggers(int maxRecords, int questionnaireID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetQuestionnaireTriggersByQuestionnaireID", maxRecords, this, false, questionnaireID);
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		protected override void SaveElement(object elem)
		{
			if (ParentQuestionnaire != null)
			{
				((QuestionnaireTrigger)elem).ContentOwnerID = ParentQuestionnaire.ContentOwnerID;
				((QuestionnaireTrigger)elem).QuestionnaireID = ParentQuestionnaire.QuestionnaireID;
			}
			base.SaveElement (elem);
		}

		/// <summary>
		/// Returns true if the collection contains the given object
		/// </summary>
		public bool Contains(QuestionnaireTrigger elem)
		{
			return List.Contains(elem);
		}

	}
}
