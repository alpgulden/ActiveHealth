using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[TableMapping("AnswerPresentationType","answerPresentationTypeID")]
	public class AnswerPresentationType : BaseData
	{
		public AnswerPresentationType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

	}
}
