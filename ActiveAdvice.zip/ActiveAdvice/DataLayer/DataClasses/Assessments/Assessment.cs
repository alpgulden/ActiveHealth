using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Assessment]
	/// </summary>
	[SPAutoGen("usp_LoadCMSAssessmentInOrder","SelectAllByGivenArgs.sptpl","cMSID", InjectPostOperation="ORDER BY CreateTime DESC")] 
	[SPInsert("usp_InsertAssessment")]
	[SPUpdate("usp_UpdateAssessment")]
	[SPDelete("usp_DeleteAssessment")]
	[SPLoad("usp_LoadAssessment")]
	[TableMapping("Assessment","assessmentGUID", true)]	
	public class Assessment : BaseData
	{
		[NonSerialized]
		private AssessmentCollection parentAssessmentCollection;
		[ColumnMapping("AssessmentGUID")]
		private string assessmentGUID;
		[ColumnMapping("CMSID")]
		private int cMSID;
		[ColumnMapping("ContentOwnerID",StereoType=DataStereoType.FK)]
		private int contentOwnerID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("Description")]
		private string description;
		private ResponseCollection responses;
		private AssessmentQuestionnaireOrderCollection assessmentQuestionnaireOrders;
	
		public Assessment() : base()
		{
		}

		public Assessment(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}
		
		protected override void NewRecord()
		{
			base.NewRecord ();
			if (assessmentGUID == null)
			{
				// We are creating a GUID at this point 
				// because we need to create child objects before saving the assessment object to the database
				this.assessmentGUID = System.Guid.NewGuid().ToString("N");
			}
		}


		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(string assessmentGUID)
		{
			return base.Load(assessmentGUID);
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=32)]
		public string AssessmentGUID
		{
			get { return this.assessmentGUID; }
			set { this.assessmentGUID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[FieldValuesMember("LookupOf_ContentOwnerID", "ContentOwnerID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}



		public ContentOwnerCollection LookupOf_ContentOwnerID
		{
			get
			{
				return ContentOwnerCollection.ActiveContentOwners; // Acquire a shared instance from the static member of collection
			}
			set
			{
				// you may remove the setter if not needed
			}
		}

		public override void FillSummaryText(SummaryWriter writer)
		{
			base.FillSummaryText (writer);
			if (!this.IsNew)
			{	
				writer.AddHeaderLabelandValue("Assessment", description);
				//writer.AddFieldOnNewLine(this, "createTime");
			}
		}

		/// <summary>
		/// Parent AssessmentCollection that contains this element
		/// </summary>
		public AssessmentCollection ParentAssessmentCollection
		{
			get
			{
				return this.parentAssessmentCollection;
			}
			set
			{
				this.parentAssessmentCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child Responses mapped to related rows of table Response where [AssessmentGUID] = [AssessmentGUID]
		/// </summary>
		[SPLoadChild("", "assessmentGUID")] // NOT USED - See LoadResponses
		public ResponseCollection Responses
		{
			get { return this.responses; }
			set
			{
				this.responses = value;
				if (value != null)
					value.ParentAssessment = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the Responses collection
		/// </summary>
		public void LoadResponses(bool forceReload)
		{
			this.responses = (ResponseCollection)ResponseCollection.LoadChildCollection("Responses", "usp_GetResponsesByAssessmentGUID", this, typeof(ResponseCollection), responses, forceReload, null, assessmentGUID);
		}

		/// <summary>
		/// Saves the Responses collection
		/// </summary>
		public void SaveResponses()
		{
			ResponseCollection.SaveChildCollection(this.responses, true);
		}

		/// <summary>
		/// Synchronizes the Responses collection
		/// </summary>
		public void SynchronizeResponses()
		{
			ResponseCollection.SynchronizeChildCollection(this.responses, true);
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
            this.LoadAssessmentQuestionnaireOrders(false);

			// Assessment description is a combination of the questionnaire names
			string description = "";
			foreach (AssessmentQuestionnaireOrder aQO in this.assessmentQuestionnaireOrders)
			{
				description += aQO.Description + " - ";
			}
			if (description != "") description = description.Substring(0, description.Length - 3);
			this.description = description;

			base.InternalSave();

			this.SaveAssessmentQuestionnaireOrders();
			this.SaveResponses();
		}




		/// <summary>
		/// Child AssessmentQuestionnaireOrders mapped to related rows of table AssessmentQuestionnaireOrder where [AssessmentGUID] = [AssessmentGUID]
		/// </summary>
		[SPLoadChild("", "assessmentGUID")] // Not used - See LoadAssessmentQuestionnaireOrders
		public AssessmentQuestionnaireOrderCollection AssessmentQuestionnaireOrders
		{
			get { return this.assessmentQuestionnaireOrders; }
			set
			{
				this.assessmentQuestionnaireOrders = value;
				if (value != null)
					value.ParentAssessment = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the AssessmentQuestionnaireOrders collection
		/// </summary>
		public void LoadAssessmentQuestionnaireOrders(bool forceReload)
		{
			this.assessmentQuestionnaireOrders = (AssessmentQuestionnaireOrderCollection)AssessmentQuestionnaireOrderCollection.LoadChildCollection("AssessmentQuestionnaireOrders", "usp_GetAssessmentQuestionnaireOrdersByAssessmentGUID", this, typeof(AssessmentQuestionnaireOrderCollection), assessmentQuestionnaireOrders, forceReload, new string[] {"assessmentGUID"}, this.assessmentGUID);
		}

		/// <summary>
		/// Saves the AssessmentQuestionnaireOrders collection
		/// </summary>
		public void SaveAssessmentQuestionnaireOrders()
		{
			AssessmentQuestionnaireOrderCollection.SaveChildCollection(this.assessmentQuestionnaireOrders, true);
		}

		/// <summary>
		/// Synchronizes the AssessmentQuestionnaireOrders collection
		/// </summary>
		public void SynchronizeAssessmentQuestionnaireOrders()
		{
			AssessmentQuestionnaireOrderCollection.SynchronizeChildCollection(this.assessmentQuestionnaireOrders, true);
		}

		/// <summary>
		/// Deletes this object from table
		/// </summary>
		public void Delete()
		{
			InternalDelete();
			OnCompleteSave();		
		}


		/// <summary>
		/// Do pre and post-delete operations of this object here.
		/// </summary>
		protected override void InternalDelete()
		{
			// Do pre-delete operations here (set members before delete, insert/update/delete extra records etc).
			if (AssessmentQuestionnaireOrders != null)
			{
				foreach(AssessmentQuestionnaireOrder aQO in AssessmentQuestionnaireOrders)
					aQO.Delete();
				AssessmentQuestionnaireOrders = null;
			}

			base.InternalDelete(); // always call this to ensure record flags gets updated properly.
			// Do post-delete operations here (set members after delete, insert/update/delete extra records etc).
		}


	}

	/// <summary>
	/// Strongly typed collection of Assessment objects
	/// </summary>
	[ElementType(typeof(Assessment))]
	public class AssessmentCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(Assessment elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAssessmentCollection = this;
			else
				elem.ParentAssessmentCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (Assessment elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public Assessment this[int index]
		{
			get
			{
				return (Assessment)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((Assessment)oldValue, false);
			SetParentOnElem((Assessment)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Parent CMS that contains this collection
		/// </summary>
		public CMS ParentCMS
		{
			get { return this.ParentDataObject as CMS; }
			set { this.ParentDataObject = value; /* parent is set when contained by a CMS */ }
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(Assessment elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((Assessment)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}
	}
}
