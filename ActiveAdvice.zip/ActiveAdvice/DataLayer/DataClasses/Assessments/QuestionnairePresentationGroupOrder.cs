using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [QuestionnairePresentationGroupOrder]
	/// </summary>
	[SPAutoGen("usp_GetQuestionnairePresentationGroupOrdersByAssessmentQuestionnaireOrderID","SelectAllByGivenArgsOrderBy.sptpl","sortOrder, assessmentQuestionnaireOrderID")] 
	[SPInsert("usp_InsertQuestionnairePresentationGroupOrder")]
	[SPUpdate("usp_UpdateQuestionnairePresentationGroupOrder")]
	[SPDelete("usp_DeleteQuestionnairePresentationGroupOrder")]
	[SPLoad("usp_LoadQuestionnairePresentationGroupOrder")]
	[TableMapping("QuestionnairePresentationGroupOrder","questionnairePresentationGroupOrderID")]
	public class QuestionnairePresentationGroupOrder : BaseData
	{
		[NonSerialized]
		private QuestionnairePresentationGroupOrderCollection parentQuestionnairePresentationGroupOrderCollection;
		[ColumnMapping("QuestionnairePresentationGroupOrderID",StereoType=DataStereoType.FK)]
		private int questionnairePresentationGroupOrderID;
		[ColumnMapping("AssessmentQuestionnaireOrderID",StereoType=DataStereoType.FK)]
		private int assessmentQuestionnaireOrderID;
		[ColumnMapping("QuestionnaireID",StereoType=DataStereoType.FK)]
		private int questionnaireID;
		[ColumnMapping("PresentationGroupID",StereoType=DataStereoType.FK)]
		private int presentationGroupID;
		[ColumnMapping("SortOrder")]
		private int sortOrder = 0;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		private PresentationGroupQuestionOrderCollection presentationGroupQuestionOrders;
		private PresentationGroup presentationGroup;
	
		public QuestionnairePresentationGroupOrder() :  base()
		{
		}

		public QuestionnairePresentationGroupOrder(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QuestionnairePresentationGroupOrderID
		{
			get { return this.questionnairePresentationGroupOrderID; }
			set { this.questionnairePresentationGroupOrderID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AssessmentQuestionnaireOrderID
		{
			get { return this.assessmentQuestionnaireOrderID; }
			set { this.assessmentQuestionnaireOrderID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QuestionnaireID
		{
			get { return this.questionnaireID; }
			set { this.questionnaireID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PresentationGroupID
		{
			get { return this.presentationGroupID; }
			set { this.presentationGroupID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		/// <summary>
		/// Parent QuestionnairePresentationGroupOrderCollection that contains this element
		/// </summary>
		public QuestionnairePresentationGroupOrderCollection ParentQuestionnairePresentationGroupOrderCollection
		{
			get
			{
				return this.parentQuestionnairePresentationGroupOrderCollection;
			}
			set
			{
				this.parentQuestionnairePresentationGroupOrderCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Child PresentationGroupQuestionOrders mapped to related rows of table PresentationGroupQuestionOrder where [QuestionnairePresentationGroupOrderID] = [QuestionnairePresentationGroupOrderID]
		/// </summary>
		[SPLoadChild("usp_LoadPresentationGroupQuestionOrders", "questionnairePresentationGroupOrderID")]
		public PresentationGroupQuestionOrderCollection PresentationGroupQuestionOrders
		{
			get 
			{ 
				this.LoadPresentationGroupQuestionOrders(false);
				return this.presentationGroupQuestionOrders; 
			}
			set
			{
				this.presentationGroupQuestionOrders = value;
				if (value != null)
					value.ParentQuestionnairePresentationGroupOrder = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the PresentationGroupQuestionOrders collection
		/// </summary>
		public void LoadPresentationGroupQuestionOrders(bool forceReload)
		{
			this.presentationGroupQuestionOrders = (PresentationGroupQuestionOrderCollection)PresentationGroupQuestionOrderCollection.LoadChildCollection("PresentationGroupQuestionOrders", this, typeof(PresentationGroupQuestionOrderCollection), presentationGroupQuestionOrders, forceReload, null);
		}

		/// <summary>
		/// Saves the PresentationGroupQuestionOrders collection
		/// </summary>
		public void SavePresentationGroupQuestionOrders()
		{
			PresentationGroupQuestionOrderCollection.SaveChildCollection(this.presentationGroupQuestionOrders, true);
		}

		/// <summary>
		/// Synchronizes the PresentationGroupQuestionOrders collection
		/// </summary>
		public void SynchronizePresentationGroupQuestionOrders()
		{
			PresentationGroupQuestionOrderCollection.SynchronizeChildCollection(this.presentationGroupQuestionOrders, true);
		}

		/// <summary>
		/// Contained PresentationGroup object
		/// </summary>
		[Contained]
		public PresentationGroup PresentationGroup
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.presentationGroup = (PresentationGroup)PresentationGroup.EnsureContainedDataObject(this, typeof(PresentationGroup), presentationGroup, false, presentationGroupID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.presentationGroup;
			}
			set
			{
				this.presentationGroup = value;
				if (value != null) value.ParentQuestionnairePresentationGroupOrder = this; // set this as a parent of the child data class
			}
		}

		/// <summary>
		/// Override this function to save contained child and other objects.
		/// </summary>
		protected override void InternalSave()
		{
			base.InternalSave();
			// Save the child collections here.

			if(PresentationGroupQuestionOrders != null)
			{
				PresentationGroupQuestionOrders.SqlData.Transaction = this.sqlData.Transaction;
				SavePresentationGroupQuestionOrders();
			}
		}

		/// <summary>
		/// Deletes this object from table
		/// </summary>
		public void Delete()
		{
			InternalDelete();
			OnCompleteSave();		
		}

		/// <summary>
		/// Do pre and post-delete operations of this object here.
		/// </summary>
		protected override void InternalDelete()
		{
			// Do pre-delete operations here (set members before delete, insert/update/delete extra records etc).
			if(PresentationGroupQuestionOrders != null)
			{
				foreach(PresentationGroupQuestionOrder pgqOrder in PresentationGroupQuestionOrders)
					pgqOrder.Delete();
				PresentationGroupQuestionOrders = null;
			}

			base.InternalDelete(); // always call this to ensure record flags gets updated properly.
			// Do post-delete operations here (set members after delete, insert/update/delete extra records etc).
		}

	}

	/// <summary>
	/// Strongly typed collection of QuestionnairePresentationGroupOrder objects
	/// </summary>
	[ElementType(typeof(QuestionnairePresentationGroupOrder))]
	public class QuestionnairePresentationGroupOrderCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(QuestionnairePresentationGroupOrder elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentQuestionnairePresentationGroupOrderCollection = this;
			else
				elem.ParentQuestionnairePresentationGroupOrderCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (QuestionnairePresentationGroupOrder elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public QuestionnairePresentationGroupOrder this[int index]
		{
			get
			{
				return (QuestionnairePresentationGroupOrder)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((QuestionnairePresentationGroupOrder)oldValue, false);
			SetParentOnElem((QuestionnairePresentationGroupOrder)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetQuestionnairePresentationGroupOrders(int maxRecords, int assessmentQuestionnaireID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetQuestionnairePresentationGroupOrdersByQuestionnairePresentationGroupOrderID", maxRecords, this, false, new object[] {assessmentQuestionnaireID});
		}

		/// <summary>
		/// Parent AssessmentQuestionnaireOrder that contains this collection
		/// </summary>
		public AssessmentQuestionnaireOrder ParentAssessmentQuestionnaireOrder
		{
			get { return this.ParentDataObject as AssessmentQuestionnaireOrder; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AssessmentQuestionnaireOrder */ }
		}

		/// <summary>
		/// Add object to this collection from QuestionnairePresentationGroupCollection
		/// Loaded by QuestionnaireID
		/// </summary>
		public void CreateFromQuestionnairePresentationGroup()
		{
			
			if (this == null)
				throw new Exception("QuestionnairePresentationGroupOrderCollection is NULL.");
			
			QuestionnairePresentationGroupCollection col = new QuestionnairePresentationGroupCollection();
			// Load by QuestionnaireID
			col.LoadAllQuestionnairePresentationGroupByQuestionnaireID(this.ParentAssessmentQuestionnaireOrder.QuestionnaireID);
			foreach(QuestionnairePresentationGroup qpg in col)
			{
				
				QuestionnairePresentationGroupOrder qpgOrder = new QuestionnairePresentationGroupOrder(true);
					qpgOrder.QuestionnaireID = qpg.QuestionnaireID;
					qpgOrder.PresentationGroupID = qpg.PresentationGroupID;
					qpgOrder.AssessmentQuestionnaireOrderID = this.ParentAssessmentQuestionnaireOrder.AssessmentQuestionnaireOrderID;
					qpgOrder.SortOrder = qpg.SortOrder;
				// Populate PresentationGroupQuestionOrders
				qpgOrder.LoadPresentationGroupQuestionOrders(false);
				if(qpgOrder.PresentationGroupQuestionOrders.Count == 0)
					qpgOrder.PresentationGroupQuestionOrders.CreateFromPresentationGroupQuestion();
				this.Add(qpgOrder);
			}
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(QuestionnairePresentationGroupOrder elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((QuestionnairePresentationGroupOrder)value, true);
			base.OnInsertComplete (index, value);		
		}
	}
}
