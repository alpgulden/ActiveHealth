using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	public enum QuestionControlTypeEnum
	{
		// Custom
		Custom = 1, 
		// Complex Questions
		AsthmaLOD = 2,
		BP = 3,
		BMI = 4,
		DeliveryAge = 5,
		GestationalAge = 6,
		GramsToPounds = 7,
		PoundsToGrams = 8,
		Medication = 9,
		// Simple Questions
		CheckList = 21,
		RadioList = 22,
		DropDownList = 23,
		CCDropDown = 24
	}


	/// <summary>
	/// Data class that wraps the entity access functionality to table [QuestionControlType]
	/// </summary>

	[SPAutoGen("usp_GetQuestionControlTypes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertQuestionControlType")]
	[SPUpdate("usp_UpdateQuestionControlType")]
	[SPLoad("usp_LoadQuestionControlType")]
	[TableMapping("QuestionControlType","questionControlTypeID")]
	public class QuestionControlType : BaseData
	{
		[NonSerialized]
		private QuestionControlTypeCollection parentQuestionControlTypeCollection;
		[ColumnMapping("QuestionControlTypeID",StereoType=DataStereoType.FK)]
		private int questionControlTypeID;
		[ColumnMapping("Description")]
		private string description;
	
		public QuestionControlType() :  base()
		{
		}

		public QuestionControlType(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QuestionControlTypeID
		{
			get { return this.questionControlTypeID; }
			set { this.questionControlTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=64)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		public static bool IsComplex(QuestionControlTypeEnum qControlType)
		{
			return (qControlType == QuestionControlTypeEnum.AsthmaLOD ||
				qControlType == QuestionControlTypeEnum.BMI ||
				qControlType == QuestionControlTypeEnum.BP ||
				qControlType == QuestionControlTypeEnum.DeliveryAge ||
				qControlType == QuestionControlTypeEnum.GestationalAge || 
				qControlType == QuestionControlTypeEnum.GramsToPounds ||
				qControlType == QuestionControlTypeEnum.PoundsToGrams ||
				qControlType == QuestionControlTypeEnum.Medication);
		}


		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent QuestionControlTypeCollection that contains this element
		/// </summary>
		public QuestionControlTypeCollection ParentQuestionControlTypeCollection
		{
			get
			{
				return this.parentQuestionControlTypeCollection;
			}
			set
			{
				this.parentQuestionControlTypeCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of QuestionControlType objects
	/// </summary>
	[ElementType(typeof(QuestionControlType))]
	public class QuestionControlTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetQuestionControlTypes(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetQuestionControlTypes", maxRecords, this, false);
		}

		/// <summary>
		/// Accessor to a shared QuestionControlTypeCollection which is cached in NSGlobal
		/// </summary>
		public static QuestionControlTypeCollection QuestionControlTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				QuestionControlTypeCollection col = (QuestionControlTypeCollection)NSGlobal.EnsureCachedObject("QuestionControlTypes", typeof(QuestionControlTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetQuestionControlTypes(-1);
				}
				return col;
			}
			
		}
	}
}
