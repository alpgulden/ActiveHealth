using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	public enum LogicTypeEnum
	{
		Internal = 1,
		Presentation = 2,
		Intervention = 3
	}


	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[SPAutoGen("usp_GetAllLogicTypes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertLogicType")]
	[SPUpdate("usp_UpdateLogicType")]
	[SPLoad("usp_LoadLogicType")]
	[TableMapping("LogicType","logicTypeID")]
	public class LogicType : BaseData
	{
		[NonSerialized]
		private LogicTypeCollection parentLogicTypeCollection;
		[ColumnMapping("LogicTypeID",StereoType=DataStereoType.FK)]
		private int logicTypeID;
		[ColumnMapping("Description")]
		private string description;
	
		public LogicType()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public LogicType(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LogicTypeID
		{
			get { return this.logicTypeID; }
			set { this.logicTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		/// <summary>
		/// Parent LogicTypeCollection that contains this element
		/// </summary>
		public LogicTypeCollection ParentLogicTypeCollection
		{
			get
			{
				return this.parentLogicTypeCollection;
			}
			set
			{
				this.parentLogicTypeCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of LogicType objects
	/// </summary>
	[ElementType(typeof(LogicType))]
	public class LogicTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LogicType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLogicTypeCollection = this;
			else
				elem.ParentLogicTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LogicType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LogicType this[int index]
		{
			get
			{
				return (LogicType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LogicType)oldValue, false);
			SetParentOnElem((LogicType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllLogicTypes(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllLogicTypes", maxRecords, this, false);
		}

		/// <summary>
		/// Accessor to a shared LogicTypeCollection which is cached in NSGlobal
		/// </summary>
		public static LogicTypeCollection AllLogicTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				LogicTypeCollection col = (LogicTypeCollection)NSGlobal.EnsureCachedObject("AllLogicTypes", typeof(LogicTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllLogicTypes(-1);
				}
				return col;
			}
			
		}
	}
}
