using System;
using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{

	// TODO: Make sure this is all
	public enum AnswerTypeEnum
	{
		Regular = 1,
		Medication = 2,
		//Allergy = 3
	}


	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[SPAutoGen("usp_GetAllAnswerTypes","SelectAll.sptpl","")]
	[SPInsert("usp_InsertAnswerType")]
	[SPUpdate("usp_UpdateAnswerType")]
	[SPLoad("usp_LoadAnswerType")]
	[TableMapping("AnswerType","answerTypeID")]
	public class AnswerType : BaseData
	{
		[NonSerialized]
		private AnswerTypeCollection parentAnswerTypeCollection;
		[ColumnMapping("AnswerTypeID",StereoType=DataStereoType.FK)]
		private int answerTypeID;
		[ColumnMapping("Description")]
		private string description;
	
		public AnswerType()
		{
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AnswerTypeID
		{
			get { return this.answerTypeID; }
			set { this.answerTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=100)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		/// <summary>
		/// Parent AnswerTypeCollection that contains this element
		/// </summary>
		public AnswerTypeCollection ParentAnswerTypeCollection
		{
			get
			{
				return this.parentAnswerTypeCollection;
			}
			set
			{
				this.parentAnswerTypeCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of AnswerType objects
	/// </summary>
	[ElementType(typeof(AnswerType))]
	public class AnswerTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AnswerType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAnswerTypeCollection = this;
			else
				elem.ParentAnswerTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AnswerType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AnswerType this[int index]
		{
			get
			{
				return (AnswerType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AnswerType)oldValue, false);
			SetParentOnElem((AnswerType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllAnswerTypes(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllAnswerTypes", maxRecords, this, false);
		}

		/// <summary>
		/// Accessor to a shared AnswerTypeCollection which is cached in NSGlobal
		/// </summary>
		public static AnswerTypeCollection AllAnswerTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				AnswerTypeCollection col = (AnswerTypeCollection)NSGlobal.EnsureCachedObject("AllAnswerTypes", typeof(AnswerTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.LoadAllAnswerTypes(-1);
				}
				return col;
			}
			
		}
	}
}
