using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using Microsoft.ApplicationBlocks.Data;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for ResponseList.
	/// </summary>
	public class ResponseList
	{
		public ResponseList()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		/// <summary>
		/// Retrieves and returns the response for a specific question and answer
		/// </summary>
		/// <param name="questionID">Question ID</param>
		/// <param name="answerID">Answer ID</param>
		/// <returns>Response text</returns>
		public string GetResponse(int questionID, int answerID)
		{
//			DataRow currentResponse = responsesDataTable.Rows.Find(new object[] {questionID, answerID});
//
//			if (currentResponse != null)
//			{
//				return currentResponse["Answer"].ToString();
//			}
//			else
//			{
//				return null;
//			}

			return null;
		}


		/// <summary>
		/// A helper method to query responses directly
		/// </summary>
		/// <param name="queryPhrase">Quesry phrase</param>
		/// <returns>Resulting datarows</returns>
		public DataRow[] QueryResponses(string queryPhrase)
		{
			//return responsesDataTable.Select(queryPhrase);

			return new DataRow[0]; 
		}



	}
}
