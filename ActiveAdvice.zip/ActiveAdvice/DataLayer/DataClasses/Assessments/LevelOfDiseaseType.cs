using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[SPAutoGen("usp_GetAllLevelOfDiseaseTypesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertLevelOfDiseaseType")]
	[SPUpdate("usp_UpdateLevelOfDiseaseType")]
	[SPLoad("usp_LoadLevelOfDiseaseType")]
	[TableMapping("LevelOfDiseaseType","levelOfDiseaseTypeID")]
	public class LevelOfDiseaseType : BaseLookup
	{
		[NonSerialized]
		private LevelOfDiseaseTypeCollection parentLevelOfDiseaseTypeCollection;
		[ColumnMapping("LevelOfDiseaseTypeID",StereoType=DataStereoType.FK)]
		private int levelOfDiseaseTypeID;
		[ColumnMapping("Code")]
		private string code;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
	
		public LevelOfDiseaseType() : base()
		{
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int LevelOfDiseaseTypeID
		{
			get { return this.levelOfDiseaseTypeID; }
			set { this.levelOfDiseaseTypeID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=500)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}



		/// <summary>
		/// Parent LevelOfDiseaseTypeCollection that contains this element
		/// </summary>
		public LevelOfDiseaseTypeCollection ParentLevelOfDiseaseTypeCollection
		{
			get
			{
				return this.parentLevelOfDiseaseTypeCollection;
			}
			set
			{
				this.parentLevelOfDiseaseTypeCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=8)]
		public string Code
		{
			get { return this.code; }
			set { this.code = value; }
		}


	}

	/// <summary>
	/// Strongly typed collection of LevelOfDiseaseType objects
	/// </summary>
	[ElementType(typeof(LevelOfDiseaseType))]
	public class LevelOfDiseaseTypeCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(LevelOfDiseaseType elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentLevelOfDiseaseTypeCollection = this;
			else
				elem.ParentLevelOfDiseaseTypeCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (LevelOfDiseaseType elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public LevelOfDiseaseType this[int index]
		{
			get
			{
				return (LevelOfDiseaseType)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((LevelOfDiseaseType)oldValue, false);
			SetParentOnElem((LevelOfDiseaseType)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetAllLevelOfDiseaseTypesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllLevelOfDiseaseTypesByActive", maxRecords, this, false, new object[] {active});
		}

		/// <summary>
		/// Accessor to a shared LevelOfDiseaseTypeCollection which is cached in NSGlobal
		/// </summary>
		public static LevelOfDiseaseTypeCollection ActiveLevelOfDiseaseTypes
		{
			get
			{
				bool initialize = false;
				// Get a cached instance of the collection
				LevelOfDiseaseTypeCollection col = (LevelOfDiseaseTypeCollection)NSGlobal.EnsureCachedObject("ActiveLevelOfDiseaseTypes", typeof(LevelOfDiseaseTypeCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetAllLevelOfDiseaseTypesByActive(-1, true);
				}
				return col;
			}
			
		}
	}
}

