using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	
	/// <summary>
	/// Used as Searcher object
	/// </summary>
	public class QuestionnaireOrganizationSearcher
	{
		[ColumnMapping("none",StereoType=DataStereoType.FK)]
		private int mORGID;
		[ColumnMapping("none",StereoType=DataStereoType.FK)]
		private int oRGID;
		[ColumnMapping("none",StereoType=DataStereoType.FK)]
		private int sORGID;
		[ColumnMapping("none",StereoType=DataStereoType.FK)]
		private int contentOwnerID;
		[ColumnMapping("none",StereoType=DataStereoType.FK)]
		private int cMSTypeID;
		[ColumnMapping("none",StereoType=DataStereoType.FK)]
		private int activeWithAll = -1;
		[ColumnMapping("none",StereoType=DataStereoType.FK)]
		private int questionnaireTypeID;

		private int organizationId;
		private string organizationPath;

		public QuestionnaireOrganizationSearcher()
		{
		}
		
		public QuestionnaireOrganizationSearcher(CMS cMS, int contentOwnerID, int cMSTypeID, int questionnaireTypeID)
		{
			if(cMS == null)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "CMS is required to create this object");;
			bool result = false;
			PatientSubscriberLog log = new PatientSubscriberLog();
			result = log.Load(cMS.PatientSubscriberLogID); 
			if (cMS.PatientSubscriberLogID == 0 && result == false)
				throw new ActiveAdviceException(AAExceptionAction.DisableUI, "Not able to Load PatientSubscriberLog based on cMS.PatientSubscriberLogID");;
			this.OrganizationId = log.SORGId;
			this.contentOwnerID = contentOwnerID;
			this.CMSTypeID = cMSTypeID;
			this.activeWithAll = 1;
			this.questionnaireTypeID = questionnaireTypeID;
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int MORGId
		{
			get { return this.mORGID; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ORGId
		{
			get { return this.oRGID; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SORGId
		{
			get { return this.sORGID; }
		}

		[FieldValuesMember("LookupOf_ContentOwnerID", "ContentOwnerID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CONTENTOWNER@")]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}

		public int ActiveWithAll
		{
			get { return this.activeWithAll; }
			set { this.activeWithAll = value; }
		}

		[FieldValuesMember("LookupOf_CMSTypeID", "CMSTypeID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CMSTYPE@")]
		public int CMSTypeID
		{
			get { return this.cMSTypeID; }
			set { this.cMSTypeID = value; }
		}
		
		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int QuestionnaireTypeID
		{
			get { return this.questionnaireTypeID; }
			set { this.questionnaireTypeID = value; }
		}

		public ContentOwnerCollection LookupOf_ContentOwnerID
		{
			get
			{
				return ContentOwnerCollection.ActiveContentOwners; // Acquire a shared instance from the static member of collection
			}
		}

		public CMSTypeCollection LookupOf_CMSTypeID
		{
			get
			{
				return CMSTypeCollection.ActiveCMSTypes; // Acquire a shared instance from the static member of collection
			}
		}

		
		[ControlType(EnumControlTypes.TextBox)]
		public string OrganizationPath
		{
			get { return this.organizationPath; }
			set { this.organizationPath = value; }
		}
		
		[FieldDescription("@ORGANIZATION@")]
		[ControlType(Macro=EnumControlTypeMacros.Int, ValueForNull=(int)int.MinValue)]
		public int OrganizationId
		{
			get { return this.organizationId; }
			set 
			{ 
				this.organizationId = value; 
				//determine level of given Organization and set ID's accordingly
				Organization o = new Organization();
				if ( this.organizationId == 0)
				{
					this.mORGID = 0;
					this.oRGID = 0;
					this.sORGID = 0;
					return;
				}
				if (o.Load(this.organizationId))
				{
					switch (o.OrganizationLevel.Code)
					{
						case "MORG":
							this.mORGID = this.organizationId;
							this.oRGID = 0;
							this.sORGID = 0;
							break;
						case "ORG":
							this.mORGID = o.ParentOrganization.OrganizationID;
							this.oRGID = this.organizationId;
							this.sORGID = 0;
							break;
						case "SORG":
							this.mORGID = o.ParentOrganization.ParentOrganization.OrganizationID;
							this.oRGID = o.ParentOrganization.OrganizationID;
							this.sORGID = this.organizationId;
							break;
						default:
							return;
					}
				}
			}
		}
	}
	
	
	
	/// <summary>
	/// Data class that wraps the entity access functionality to table [QuestionnaireOrganizationPlan]
	/// </summary>
	[SPInsert("usp_InsertQuestionnaireOrganizationPlan")]
	[SPUpdate("usp_UpdateQuestionnaireOrganizationPlan")]
	[SPDelete("usp_DeleteQuestionnaireOrganizationPlan")]
	[SPLoad("usp_LoadQuestionnaireOrganizationPlan")]
	[TableMapping("QuestionnaireOrganization","questionnaireOrganizationID")]
	public class QuestionnaireOrganization : BaseData
	{
		[NonSerialized]
		private QuestionnaireOrganizationCollection parentQuestionnaireOrganizationCollection;
		[ColumnMapping("QuestionnaireOrganizationID",StereoType=DataStereoType.FK)]
		private int questionnaireOrganizationID;
		[ColumnMapping("QuestionnaireID",StereoType=DataStereoType.FK)]
		private int questionnaireID;
		[ColumnMapping("MORGID",StereoType=DataStereoType.FK)]
		private int mORGID;
		[ColumnMapping("ORGID",StereoType=DataStereoType.FK)]
		private int oRGID;
		[ColumnMapping("SORGID",StereoType=DataStereoType.FK)]
		private int sORGID;
		[ColumnMapping("ContentOwnerID",StereoType=DataStereoType.FK)]
		private int contentOwnerID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;

		[ColumnMapping("Description", JoinColumn="Description", JoinRelation="QuestionnaireOrganization.QuestionnaireID = [Questionnaire].QuestionnaireID", SQLGen=SQLGenerationFlags.NoInsertUpdate)]
		private string description;

	
		public QuestionnaireOrganization()
		{
		}

		public QuestionnaireOrganization(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		//[FieldDescription("@QUESTIONNAIREID@")]
		[FieldDescription("@ID@")]
		public int QuestionnaireID
		{
			get { return this.questionnaireID; }
			set { this.questionnaireID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int MORGID
		{
			get { return this.mORGID; }
			set { this.mORGID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ORGID
		{
			get { return this.oRGID; }
			set { this.oRGID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		[FieldDescription("@SUBORGANIZATION@")]
		public int SORGID
		{
			get { return this.sORGID; }
			set { this.sORGID = value; }
		}

		[FieldValuesMember("LookupOf_ContentOwnerID", "ContentOwnerID", "Description")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		[FieldDescription("@CONTENTOWNER@")]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.TextBox)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent QuestionnaireOrganizationCollection that contains this element
		/// </summary>
		public QuestionnaireOrganizationCollection ParentQuestionnaireOrganizationCollection
		{
			get
			{
				return this.parentQuestionnaireOrganizationCollection;
			}
			set
			{
				this.parentQuestionnaireOrganizationCollection = value; // parent is set when added to a collection
			}
		}

		public ContentOwnerCollection LookupOf_ContentOwnerID
		{
			get
			{
				return ContentOwnerCollection.ActiveContentOwners; // Acquire a shared instance from the static member of collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of QuestionnaireOrganizationPlan objects
	/// </summary>
	[ElementType(typeof(QuestionnaireOrganization))]
	public class QuestionnaireOrganizationCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_QuestionnaireID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(QuestionnaireOrganization elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentQuestionnaireOrganizationCollection = this;
			else
				elem.ParentQuestionnaireOrganizationCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (QuestionnaireOrganization elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public QuestionnaireOrganization this[int index]
		{
			get
			{
				return (QuestionnaireOrganization)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((QuestionnaireOrganization)oldValue, false);
			SetParentOnElem((QuestionnaireOrganization)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetQuestionnaireOrganizations(int maxRecords, QuestionnaireOrganization searcher)
		{
			this.Clear();
			return SqlData.SPExecReadCol("replace", maxRecords, this, searcher, false);
		}

		/// <summary>
		/// Hashtable based index on questionnaireID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_QuestionnaireID
		{
			get
			{
				if (this.indexBy_QuestionnaireID == null)
					this.indexBy_QuestionnaireID = new CollectionIndexer(this, new string[] { "questionnaireID" }, true);
				return this.indexBy_QuestionnaireID;
			}
		}

		public void SynchronizeQuestionnairesFromSelectableCollection(QuestionnaireCollection questionnaires, int mORGID, int oRGID, int sORGID, int contentOwnerID)
		{
			QuestionnaireOrganization  existingQuestionnaireOrganization = null;
			this.IndexBy_QuestionnaireID.Rebuild();

			foreach (Questionnaire questionnaire in questionnaires)
			{
				existingQuestionnaireOrganization = this.FindBy(questionnaire.QuestionnaireID);

				if (((SelectableQuestionnaire)questionnaire).Selected)
				{
					if(existingQuestionnaireOrganization == null)
					{	// Selected Questionnaire is not linked to this - Adding
						QuestionnaireOrganization qoToAdd = new QuestionnaireOrganization(true);
							qoToAdd.QuestionnaireID = questionnaire.QuestionnaireID;
							qoToAdd.MORGID = mORGID;
							qoToAdd.ORGID = oRGID;
							qoToAdd.SORGID = sORGID;
							qoToAdd.Description = questionnaire.Description;
							if(contentOwnerID == 0)
								qoToAdd.ContentOwnerID = questionnaire.ContentOwnerID;
							else
								qoToAdd.ContentOwnerID = contentOwnerID;
						this.Add(qoToAdd);
					}
					else if(existingQuestionnaireOrganization.IsMarkedForDeletion)
						existingQuestionnaireOrganization.IsMarkedForDeletion = false;
				}
				if(!((SelectableQuestionnaire)questionnaire).Selected)
				{
					if(existingQuestionnaireOrganization != null)
						// Selected Questionnare is linked to this - Removing
						existingQuestionnaireOrganization.MarkDel();
				}
				existingQuestionnaireOrganization = null;
			}// end of foreach
		}

		/// <summary>
		/// Hashtable based search on questionnaireID fields returns the object.  Uses the IndexBy_QuestionnaireID indexer.
		/// </summary>
		public QuestionnaireOrganization FindBy(int questionnaireID)
		{
			return (QuestionnaireOrganization)this.IndexBy_QuestionnaireID.GetObject(questionnaireID);
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(QuestionnaireOrganization elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((QuestionnaireOrganization)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchQuestionnaireOrganization(int maxRecords, QuestionnaireOrganizationSearcher searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchQuestionnaireOrganization", maxRecords, this, searcher, false);
		}

		public static QuestionnaireOrganizationCollection SearchQuestionnaireOrganization(QuestionnaireOrganizationSearcher searcher)
		{
			QuestionnaireOrganizationCollection col = new QuestionnaireOrganizationCollection();
			col.SearchQuestionnaireOrganization(-1, searcher);
			return col;
		}
	}
}
