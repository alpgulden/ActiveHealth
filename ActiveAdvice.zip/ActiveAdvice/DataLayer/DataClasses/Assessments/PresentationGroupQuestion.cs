using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [PresentationGroupQuestion]
	/// </summary>
	[SPAutoGen("usp_GetAllPresentationGroupQuestionsByPresentationGroupID","SelectAllByGivenArgs.sptpl","presentationGroupID")]
	[SPDelete("usp_DeletePresentationGroupQuestion")]
	[SPInsert("usp_InsertPresentationGroupQuestion")]
	[SPUpdate("usp_UpdatePresentationGroupQuestion")]
	[SPLoad("usp_LoadPresentationGroupQuestion")]
	[TableMapping("PresentationGroupQuestion","questionID,presentationGroupID",true)]
	public class PresentationGroupQuestion : BaseData
	{
		[NonSerialized]
		private PresentationGroupQuestionCollection parentPresentationGroupQuestionCollection;
		[ColumnMapping("QuestionID",StereoType=DataStereoType.FK)]
		private int questionID;
		[ColumnMapping("PresentationGroupID",StereoType=DataStereoType.FK)]
		private int presentationGroupID;
		[ColumnMapping("SortOrder")]
		private int sortOrder;
		[ColumnMapping("ContentOwnerID",StereoType=DataStereoType.FK)]
		private int contentOwnerID;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;

		[ColumnMapping("QuestionText", JoinColumn="QuestionText", JoinRelation="PresentationGroupQuestion.QuestionID = [Question].QuestionID", SQLGen=SQLGenerationFlags.NoSelect | SQLGenerationFlags.NoUpdate | SQLGenerationFlags.NoUpdate)]
		private string questionText;

	
		public PresentationGroupQuestion() : base()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public PresentationGroupQuestion(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int QuestionID
		{
			get { return this.questionID; }
			set { this.questionID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int PresentationGroupID
		{
			get { return this.presentationGroupID; }
			set { this.presentationGroupID = value; }
		}

		[FieldDescription("@QUESTIONTEXT@")]
		public string QuestionText
		{
			get {return questionText;}
			set { this.questionText = value; }
		}


		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ContentOwnerID
		{
			get { return this.contentOwnerID; }
			set { this.contentOwnerID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Deletes this object from table
		/// </summary>
		public void Delete()
		{
			InternalDelete();
			OnCompleteSave();		
		}

		/// <summary>
		/// Parent PresentationGroupQuestionCollection that contains this element
		/// </summary>
		public PresentationGroupQuestionCollection ParentPresentationGroupQuestionCollection
		{
			get
			{
				return this.parentPresentationGroupQuestionCollection;
			}
			set
			{
				this.parentPresentationGroupQuestionCollection = value; // parent is set when added to a collection
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of PresentationGroupQuestion objects
	/// </summary>
	[ElementType(typeof(PresentationGroupQuestion))]
	public class PresentationGroupQuestionCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_QuestionID;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(PresentationGroupQuestion elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentPresentationGroupQuestionCollection = this;
			else
				elem.ParentPresentationGroupQuestionCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (PresentationGroupQuestion elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public PresentationGroupQuestion this[int index]
		{
			get
			{
				return (PresentationGroupQuestion)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((PresentationGroupQuestion)oldValue, false);
			SetParentOnElem((PresentationGroupQuestion)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		public void SynchronizeQuestionsFromSelectableCollection(int presentationGroupID, QuestionCollection questions)
		{
			PresentationGroupQuestion  existingPresentationGroupQuestion = null;

			foreach (Question question in questions)
			{
				if (((SelectableQuestion)question).Selected)
				{
					existingPresentationGroupQuestion = this.FindBy(question.QuestionID);
					if (existingPresentationGroupQuestion == null)
					{
						PresentationGroupQuestion presentationGroupQuestion = null;
						presentationGroupQuestion = new PresentationGroupQuestion(true);
						presentationGroupQuestion.PresentationGroupID = presentationGroupID;
						presentationGroupQuestion.QuestionID = question.QuestionID;
						presentationGroupQuestion.QuestionText = question.QuestionText;
						presentationGroupQuestion.ContentOwnerID = question.ContentOwnerID;
						this.AddRecord(presentationGroupQuestion);
					}
					else if (existingPresentationGroupQuestion.IsMarkedForDeletion)
					{
						existingPresentationGroupQuestion.IsMarkedForDeletion = false;
					}
				}
			}

			foreach (PresentationGroupQuestion presentationGroupQuestion in this)
			{
				Question question = null;
				question = questions.FindBy(presentationGroupQuestion.QuestionID);
				if (!((SelectableQuestion)question).Selected)
				{
					presentationGroupQuestion.MarkDel();
				}
			}
		}

		public override int AddRecord(BaseDataClass data)
		{
			int ret = base.AddRecord (data);
			// Rebuild indexers
			// TODO: Remove this when the library automatically supports this feature
			IndexBy_QuestionID.Rebuild();
			return ret;
		}

		/// <summary>
		/// Hashtable based index on questionID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_QuestionID
		{
			get
			{
				if (this.indexBy_QuestionID == null)
					this.indexBy_QuestionID = new CollectionIndexer(this, new string[] { "questionID" }, true);
				return this.indexBy_QuestionID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on questionID fields returns the object.  Uses the IndexBy_QuestionID indexer.
		/// </summary>
		public PresentationGroupQuestion FindBy(int questionID)
		{
			return (PresentationGroupQuestion)this.IndexBy_QuestionID.GetObject(questionID);
		}

		/// <summary>
		/// Calls save methods of all the collection elements
		/// </summary>
		public void Save()
		{
			this.SaveElements();		
		}

		/// <summary>
		/// Sorts the collection by the sortOrder members.
		/// </summary>
		public void SortBySortOrder(bool ascending)
		{
			CollectionUtil.SortBy(this, ascending, false, new string[] { "sortOrder" });		
		}

		/// <summary>
		/// Parent PresentationGroup that contains this collection
		/// </summary>
		public PresentationGroup ParentPresentationGroup
		{
			get { return this.ParentDataObject as PresentationGroup; }
			set { this.ParentDataObject = value; /* parent is set when contained by a PresentationGroup */ }
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllPresentationGroupQuestionsByPresentationGroupID(int presentationGroupID)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetAllPresentationGroupQuestionsByPresentationGroupID", -1, this, false, new object[] { presentationGroupID });
		}
	}
}
