using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [AssessmentParagraphBody]
	/// </summary>
	[SPInsert("usp_InsertAssessmentParagraphBody")]
	[SPUpdate("usp_UpdateAssessmentParagraphBody")]
	[SPDelete("usp_DeleteAssessmentParagraphBody")]
	[SPLoad("usp_LoadAssessmentParagraphBody")]
	[TableMapping("AssessmentParagraphBody","assessmentParagraphBodyID")]
	public class AssessmentParagraphBody : BaseData
	{
		[ColumnMapping("AssessmentParagraphBodyID",(int)0)]
		private int assessmentParagraphBodyID;
		[ColumnMapping("AssessmentParagraphBody")]
		private string assessmentParagraphBody;
	
		public AssessmentParagraphBody()
		{
		}

		public AssessmentParagraphBody(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int AssessmentParagraphBodyID
		{
			get { return this.assessmentParagraphBodyID; }
			set { this.assessmentParagraphBodyID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2147483647)]
		public string AssessmentParagraphBodyText
		{
			get { return this.assessmentParagraphBody; }
			set { this.assessmentParagraphBody = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent AssessmentParagraph that contains this object
		/// </summary>
		public AssessmentParagraph ParentAssessmentParagraph
		{
			get { return this.ParentDataObject as AssessmentParagraph; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AssessmentParagraph */ }
		}
	}
}
