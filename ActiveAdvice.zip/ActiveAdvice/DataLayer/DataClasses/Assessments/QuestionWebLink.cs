using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Question]
	/// </summary>
	[TableMapping("QuestionWebLink","questionWebLinkID")]
	public class QuestionWebLink : BaseDataClass
	{
		public QuestionWebLink()
		{
			//
			// TODO: Add constructor logic here
			//
		}

	}
}
