using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	public enum AssessmentParagraphPosition
	{
		First = 1,
		Normal = 2,
		Last = 3
	}

	/// <summary>
	/// Data class that wraps the entity access functionality to table [AssessmentParagraph]
	/// </summary>
	[SPAutoGen("usp_SearchAssessmentParagraph","SearchByArgs.sptpl","activeWithAll:active, logicID")]
	[SPInsert("usp_InsertAssessmentParagraph")]
	[SPUpdate("usp_UpdateAssessmentParagraph")]
	[SPDelete("usp_DeleteAssessmentParagraph")]
	[SPLoad("usp_LoadAssessmentParagraph")]
	[TableMapping("AssessmentParagraph","assessmentParagraphID")]
	public class AssessmentParagraph : BaseAssessment
	{
		[NonSerialized]
		private AssessmentParagraphCollection parentAssessmentParagraphCollection;
		[ColumnMapping("AssessmentParagraphID",(int)0)]
		private int assessmentParagraphID;
		[ColumnMapping("AssessmentCategoryID",StereoType=DataStereoType.FK)]
		private int assessmentCategoryID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("LogicID",StereoType=DataStereoType.FK)]
		private int logicID;
		[ColumnMapping("AssessmentParagraphBodyID",StereoType=DataStereoType.FK)]
		private int assessmentParagraphBodyID;
		[ColumnMapping("SortOrder",StereoType=DataStereoType.FK)]
		private int sortOrder;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		private AssessmentParagraphBody assessmentParagraphBody;
	
		public AssessmentParagraph()
		{
		}

		public AssessmentParagraph(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int AssessmentParagraphID
		{
			get { return this.assessmentParagraphID; }
			set { this.assessmentParagraphID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int AssessmentCategoryID
		{
			get { return this.assessmentCategoryID; }
			set { this.assessmentCategoryID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=255)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}


		[FieldValuesMember("ValuesOf_SortOrder")]
		[ControlType(Macro=EnumControlTypeMacros.IntLookup, IsRequired=true)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int LogicID
		{
			get { return this.logicID; }
			set { this.logicID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int AssessmentParagraphBodyID
		{
			get { return this.assessmentParagraphBodyID; }
			set { this.assessmentParagraphBodyID = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Parent AssessmentParagraphCollection that contains this element
		/// </summary>
		public AssessmentParagraphCollection ParentAssessmentParagraphCollection
		{
			get
			{
				return this.parentAssessmentParagraphCollection;
			}
			set
			{
				this.parentAssessmentParagraphCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Contained AssessmentParagraphBody object
		/// </summary>
		[Contained]
		public AssessmentParagraphBody AssessmentParagraphBody
		{
			get
			{
				// Ensure contained data object is loaded or created as new.
				this.assessmentParagraphBody = (AssessmentParagraphBody)AssessmentParagraphBody.EnsureContainedDataObject(this, typeof(AssessmentParagraphBody), assessmentParagraphBody, false, assessmentParagraphBodyID );
				// To load or invalidate this object when the parent is loaded, override InternalLoad method.
				// To save this object when the parent is saved, override InternalSave method.
				return this.assessmentParagraphBody;
			}
			set
			{
				this.assessmentParagraphBody = value;
				if (value != null) value.ParentAssessmentParagraph = this; // set this as a parent of the child data class
			}
		}

		public object[,] ValuesOf_SortOrder
		{
			get
			{
				Type positions = typeof(AssessmentParagraphPosition);
				
				return new object[,] 
					{
						{(int)1, AssessmentParagraphPosition.First.ToString()},
						{(int)2, AssessmentParagraphPosition.Normal.ToString()},
						{(int)3, AssessmentParagraphPosition.Last.ToString()},
					}; // return possible field values
			}
		}

	}

	/// <summary>
	/// Strongly typed collection of AssessmentParagraph objects
	/// </summary>
	[ElementType(typeof(AssessmentParagraph))]
	public class AssessmentParagraphCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(AssessmentParagraph elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentAssessmentParagraphCollection = this;
			else
				elem.ParentAssessmentParagraphCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (AssessmentParagraph elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public AssessmentParagraph this[int index]
		{
			get
			{
				return (AssessmentParagraph)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((AssessmentParagraph)oldValue, false);
			SetParentOnElem((AssessmentParagraph)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Adds the object to the collection
		/// </summary>
		public int Add(AssessmentParagraph elem)
		{
			return AddRecord(elem);
		}

		protected override void OnInsertComplete(int index, object value)
		{
			SetParentOnElem((AssessmentParagraph)value, true);
			base.OnInsertComplete (index, value);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		private int SearchAssessmentParagraph(int maxRecords, AssessmentParagraph searcher)
		{
			object activeWithAll = (searcher.ActiveWithAll == -1? (object)null: (object)searcher.ActiveWithAll);
			this.Clear();
			return SqlData.SPExecReadCol("usp_SearchAssessmentParagraph", maxRecords, this, searcher, false, new string[] {"activeWithAll"}, new object[] {activeWithAll});
		}

		public static AssessmentParagraphCollection GetFromSearch(AssessmentParagraph searcher)
		{
			AssessmentParagraphCollection col = new AssessmentParagraphCollection();
			col.SearchAssessmentParagraph(-1, searcher);
			return col;
		}

		/// <summary>
		/// Parent AssessmentCategory that contains this collection
		/// </summary>
		public AssessmentCategory ParentAssessmentCategory
		{
			get { return this.ParentDataObject as AssessmentCategory; }
			set { this.ParentDataObject = value; /* parent is set when contained by a AssessmentCategory */ }
		}
	}
}
