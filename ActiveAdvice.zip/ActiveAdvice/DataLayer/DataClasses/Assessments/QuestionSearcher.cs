using System;
using NetsoftUSA.DataLayer;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for QuestionSearcher.
	/// </summary>
	/// 
	public class QuestionSearcher : Question
	{


	}
}
