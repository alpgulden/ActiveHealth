using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [AssessmentCategory]
	/// </summary>
	[SPInsert("usp_InsertAssessmentCategory")]
	[SPUpdate("usp_UpdateAssessmentCategory")]
	[SPDelete("usp_DeleteAssessmentCategory")]
	[SPLoad("usp_LoadAssessmentCategory")]
	[TableMapping("AssessmentCategory","assessmentCategoryID")]
	public class AssessmentCategory : BaseData
	{
		[ColumnMapping("AssessmentCategoryID",(int)0)]
		private int assessmentCategoryID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("HeaderText")]
		private string headerText;
		[ColumnMapping("CMSTypeID",StereoType=DataStereoType.FK)]
		private int cMSTypeID;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("CreatedBy",StereoType=DataStereoType.FK)]
		private int createdBy;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy",StereoType=DataStereoType.FK)]
		private int modifiedBy;
		private AssessmentParagraphCollection assessmentParagraphs;
	
		public AssessmentCategory()
		{
		}

		public AssessmentCategory(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int AssessmentCategoryID
		{
			get { return this.assessmentCategoryID; }
			set { this.assessmentCategoryID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=255)]
		public string HeaderText
		{
			get { return this.headerText; }
			set { this.headerText = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CMSTypeID
		{
			get { return this.cMSTypeID; }
			set { this.cMSTypeID = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate, IsRequired=true)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Child AssessmentParagraphs mapped to related rows of table AssessmentParagraph where [AssessmentCategoryID] = [AssessmentCategoryID]
		/// </summary>
		[SPLoadChild("usp_LoadAssessmentCategoryAssessmentParagraph", "assessmentCategoryID")]
		public AssessmentParagraphCollection AssessmentParagraphs
		{
			get { return this.assessmentParagraphs; }
			set
			{
				this.assessmentParagraphs = value;
				if (value != null)
					value.ParentAssessmentCategory = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the AssessmentParagraphs collection
		/// </summary>
		public void LoadAssessmentParagraphs(bool forceReload)
		{
			this.assessmentParagraphs = (AssessmentParagraphCollection)AssessmentParagraphCollection.LoadChildCollection("AssessmentParagraphs", this, typeof(AssessmentParagraphCollection), assessmentParagraphs, forceReload, null);
		}

		/// <summary>
		/// Saves the AssessmentParagraphs collection
		/// </summary>
		public void SaveAssessmentParagraphs()
		{
			AssessmentParagraphCollection.SaveChildCollection(this.assessmentParagraphs, true);
		}

		/// <summary>
		/// Synchronizes the AssessmentParagraphs collection
		/// </summary>
		public void SynchronizeAssessmentParagraphs()
		{
			AssessmentParagraphCollection.SynchronizeChildCollection(this.assessmentParagraphs, true);
		}
	}
}
