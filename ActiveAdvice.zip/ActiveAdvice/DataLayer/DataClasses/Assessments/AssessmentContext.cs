using System;
using System.Collections;
using Tx4oleLib;

namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Summary description for AssessmentContext.
	/// </summary>
	public class AssessmentContext
	{
		private Assessment assessment;
		private CMS cMS;
		private QuestionCollection questions;
				
		private LogicEvaluator logicEvaluator; 

		private InterventionTemplateCollection iTemplates;

		private int overallRisk = -1;
		private int currentQuestionnaireIndex = -1;

		private AssessmentQuestionNoteCollection questionNotes;

		private bool isDirty = true;

		public bool IsDirty
		{
			get { return isDirty; }
			set { isDirty = value; }
		}

		public int CurrentQuestionnaireIndex
		{
			get { return currentQuestionnaireIndex; }
			set { currentQuestionnaireIndex = value; }
		}
		
		public Assessment Assessment
		{
			get { return this.assessment; }
		}

		public CMS CMS
		{
			get { return cMS; }
			set { this.cMS = value; }
		}

		public AssessmentQuestionnaireOrderCollection QuestionnaireOrders
		{
			get { return this.assessment.AssessmentQuestionnaireOrders; }
		}

		public QuestionCollection Questions
		{
			get { return this.questions; }
		}

		public ResponseCollection Responses
		{
			get 
			{ 
				return this.assessment.Responses; 
			}
		}

		public LogicEvaluator LogicEvaluator
		{
			get { return this.logicEvaluator; }
		}

		public string AssessmentGUID
		{
			get { return this.assessment.AssessmentGUID; }
		}

		public AssessmentQuestionNoteCollection QuestionNotes
		{
			get { return this.questionNotes; }
		}

		public InterventionTemplateCollection ITemplates
		{
			get { return this.iTemplates; }
			set { this.iTemplates = value; }
		}

		public int OverallRisk
		{
			get { return this.overallRisk; }
			set { this.overallRisk = value; }
		}

		public AssessmentContext(CMS cMS, string assessmentGUID)
		{
			this.cMS = cMS;
			this.assessment = new Assessment();
			this.assessment.Load(assessmentGUID);
			
			LoadContext();
		}

		public AssessmentContext(CMS cMS, Assessment assessment)
		{
			this.cMS = cMS;
			this.assessment = assessment;

			LoadContext();
		}


		/// <summary>
		/// Sets the dirty flag so the parent page cache
		/// </summary>
		public void Cache()
		{
			isDirty = true;	
		}
        
		private void LoadContext()
		{
			ReloadQuestions();
			ReloadResponses();
			
			questionNotes = new AssessmentQuestionNoteCollection();
			questionNotes.LoadByCMSID(cMS.CMSID);

			logicEvaluator = new LogicEvaluator();
			logicEvaluator.AssessmentContext = this;
			logicEvaluator.Questions = this.questions;

			ReloadQuestionnaireOrders();

			iTemplates = new InterventionTemplateCollection();
			iTemplates.LoadAssessmentInterventionTemplates(AssessmentGUID);
			
        }

		public void Reload()
		{
			ReloadQuestions();
			ReloadQuestionnaireOrders();
		}

		public void ReloadResponses()
		{
			this.assessment.LoadResponses(true);
			this.assessment.Responses.AssessmentContext = this;
		}

		public void ReloadQuestions()
		{
			questions = new QuestionCollection();
			questions.AssessmentContext = this;
			questions.LoadByContentOwnerID(assessment.ContentOwnerID);
		}

		public void ReloadQuestionnaireOrders()
		{
			this.assessment.LoadAssessmentQuestionnaireOrders(true);
		}
		

		/// <summary>
		/// Returns the responses to a specific question in all the assessments 
		/// for this CMS. It may exclude the current assessment depending on the value of the argument passed
		/// </summary>
		/// <param name="questionID">Question ID</param>
		/// <param name="excludeCurrentAssessment">If this is true the current assessment responses are disregarded</param>
		/// <returns></returns>
		public ArrayList GetLatestReponses(int questionID, bool checkCurrentAssessment, bool checkOldAssessments)
		{
			ArrayList latestResponses = new ArrayList();
			ArrayList tempResponses;

			// If current assessment is not excluded from the search, first look in there
			if (checkCurrentAssessment)
			{
				// Let's see if there is any answer for this question in this assessment
				tempResponses = assessment.Responses.FilterBy(questionID);	
				if (tempResponses != null)
				{
					for (int index = 0 ; index < tempResponses.Count; index++)
					{
						if (!((Response)tempResponses[index]).IsMarkedForDeletion) latestResponses.Add(tempResponses[index]);
					}
				}
			}

			if (latestResponses.Count > 0)
				return latestResponses;	

			if (checkOldAssessments)
			{
				cMS.LoadAssessments(false);
				// The Assessments collection of CMS MUST BE ordered by date
				foreach (Assessment assessment in cMS.Assessments)
				{
					if (assessment.AssessmentGUID != AssessmentGUID)
					{
						assessment.LoadResponses(false);
						// Let's see if there is any answer for this question in this assessment
						tempResponses = assessment.Responses.FilterBy(questionID);	
						if (tempResponses != null)
						{
							for (int index = 0 ; index < tempResponses.Count; index++)
							{
								if (!((Response)tempResponses[index]).IsMarkedForDeletion) latestResponses.Add(tempResponses[index]);
							}
						}
					}
				}

				if (latestResponses.Count > 0)
					return latestResponses;	
			}

			return null;
		}



	}
}
