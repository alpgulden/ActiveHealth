using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using Microsoft.JScript;
using Microsoft.JScript.Vsa;
using Microsoft.Vsa;
using System.Text.RegularExpressions;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.ApplicationBlocks.Data;
using NetsoftUSA.DataLayer;
using System.Text;


namespace ActiveAdvice.DataLayer
{

	#region Exception classes
	public class LogicException : Exception
	{
		public LogicException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

		public LogicException(string message)
			: base(message)
		{
		}
	}
	#endregion

	/// <summary>
	/// This class encapsulates all the logic necessary to evaluate given logical expressions.
	/// After creating an object of type LogicEvaluator, the caller must call EvaluateExpression method,
	/// which returns a boolean value depending on the validity of the expression.
	/// </summary>
	public class LogicEvaluator
	{

		private AssessmentContext assessmentContext;

		public AssessmentContext AssessmentContext
		{
			get { return assessmentContext; }
			set { assessmentContext = value; }
		}

		private QuestionCollection questions;

		public QuestionCollection Questions
		{
			get { return questions; }
			set { questions = value; }
		}

		
		private bool testMode = false;
		private ArrayList questionsInvolved = null;


		
		public void BeginTestMode()
		{
			this.testMode = true;
			questionsInvolved = new ArrayList(5);
		}

		public void EndTestMode()
		{
			this.testMode = false;
			questionsInvolved = null;
		}

		public ArrayList GetQuestionsInvolved()
		{
			if (this.testMode)
				return questionsInvolved;
			else
				throw new Exception("The method GetQuestionsInvolved can be used only in test mode");
		}



		/// <summary>
		/// Evaluates and returns the result for a logic expression given its ID
		/// </summary>
		/// <param name="logicID">ID for logic expression</param>
		/// <returns>TRUE if the expression is valid, otherwise FALSE</returns>
		public bool EvaluateExpression(int logicID)
		{
			Logic logic = null;

			try
			{
				logic = new Logic(logicID);
				return EvaluateExpression(logic.Expression);
			}
			catch
			{
				throw new LogicException(String.Format("Logic ID ({0}) cannot be found", logicID));
			}
		}



		/// <summary>
		/// This method deals with evaluating the whole expression by splitting it into logical subexpressions.
		/// The process is done as follows:
		/// - The expression is splitted into logical subexpressions like: (Q123,A1) = 1  
		/// - QuestionID, AnswerIndexID, Operator, Response is extracted for each subexpression.
		/// - The above values are passed to CheckResponse method, which returns either true or false 
		/// depending on the validity of that subexpression.
		/// - In the expression, the subexpression is replaced by the return value of CheckResponse.
		/// - After processing each subexpression and replacing posible matches for predefined operators 
		/// like "AND, OR", the expression turns into a simple logical expression which can be evaluated 
		/// using JScript's Evaluation method. (ex. "(true && false) || true")
		///  
		/// Following regular expression pattern is designed to match all possible variations of a 
		/// subexpression.
		/// 
		/// (<QuestionIndexID>, <AnswerIndexID>) <Operator> (<NumericResponse>, <AlphaNumericResponse>, <DateResponse>)	
		/// 	
		/// Pattern: "\\(\\s*Q(?<QuestionIndexID>[0-9]+)\\s*(,\\s*C(?<ComponentIndexID>((\\*)|([0-9]*)))\\s*)*(,\\s*A(?<AnswerIndexID>((\\*)|([0-9]*))))*\\s*\\)\\s*(?<Operator>(((=)|(>)|(<)|(!=)|(>=)|(<=)){1})) \\s* ( (?<AlphaNumericResponse>((\\\"\\\")|(\\\".*?([^\\\\]\\\")))) | (?<NumericResponse>[0-9\\.]+) | (?<DateResponse>(\\'[0-9]{2}\\.[0-9]{2}\\.[0-9]{4}(\\s[0-9]{2}:[0-9]{2}(:[0-9]{2})?(\\s[AP]M)?)?')))";
		/// 
		/// 
		/// Notes:
		/// - BackSlash and Quote characters are escaped.
		/// - A cheatsheet for the special characters used in regular expression patterns can be found at
		///		http://regexlib.com/CheatSheet.htm
		/// - When a match is found it is its components are extracted: QuestionID, ComponentIndexID, AnswerIndexID, Operator, AlphaNumericResponse, NumericResponse, DateResponse
		///	- QuestionIndexID can be any numeric value. No spaces allowed between the letter 'Q' and QuestionIndexID.
		///	- ComponentIndexID can be any numeric value. No spaces allowed between the letter 'C' and ComponentIndexID.
		///	- AnswerIndexID can be either a numeric value or '*' character, which means all the answers for a specific question.
		///		No spaces allowed between the letter 'A' and AnswerIndexID or '*' character.
		///	- Operator can be one of the following: =, >=, <=, <, <, != 
		///	- The righthand side of the subexpresion can be either numeric, alphanumeric or date. 
		///	  Alphanumeric values must be surrounded by double-quotes (ex. "abc").
		///	  If a double-quote must be used inside of an alphanumeric expression, Back-slash (\) character can be used to 
		///	  as an escape character. ex. "abc\"cde" 
		///	  Numeric values must be expressed without quotes and cannot include anything other than
		///	  digits and dot character for decimal values.
		///	- Date values must be surrended by single quotes. The format of the date is mm.dd.yyyy (hh:mm AM/PM)
		///	  
		/// </summary>
		/// <param name="expression">The string expression to be evaluated.</param>
		/// <returns>TRUE if the expression is valid, otherwise FALSE</returns>
		public bool EvaluateExpression(string expression)
		{
			try
			{

				// Declare local variables
				Regex regex;
				string temporaryExpression = expression;
		
				// This pattern is used to find all the posibble matches
				// Modified to accept date values
				string regPattern = "(?<Selected>S)?\\(\\s*Q(?<QuestionIndexID>[0-9]+)\\s*(,\\s*C(?<ComponentIndexID>((\\*)|([0-9]*)))\\s*)*(,\\s*A(?<AnswerIndexID>((\\*)|([0-9]*))))*\\s*\\)(\\s*(?<Operator>(((=)|(>)|(<)|(!=)|(>=)|(<=)){1})) \\s* ( (?<AlphaNumericResponse>((\\\"\\\")|(\\\".*?([^\\\\]\\\")))) | (?<NumericResponse>[0-9\\\\.]+) | (?<DateResponse>(\\'[0-9]{2}\\/[0-9]{2}\\/[0-9]{4}(\\s[0-9]{2}:[0-9]{2}(:[0-9]{2})?(\\s[AP]M)?)?'))))?";

				// RegEx object is created with following options:			
				// - RegexOptions.IgnoreCase: Finding a match is case-insensitive
				// - RegexOptions.Compiled: The pattern get compiled on the first run and consecutive operations run faster.
				// - RegexOptions.IgnorePatternWhitespace: White spaces in pattern expression are ignored.
				regex = new Regex( regPattern
					, RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.IgnorePatternWhitespace);
			
				// Call the Replace method
				// This call is going to look for matching patterns in the expression 
				// and for each match it's going call the GetReplacementValue method
				temporaryExpression = regex.Replace(expression, new MatchEvaluator(GetReplacementValue));

				// Active Advice currently does not have any functions
				//temporaryExpression = AnalyzeFunctions(temporaryExpression);

				// Replace human readible logical operators with their JScript versions.
				temporaryExpression = temporaryExpression.Replace("OR", " || ");
				temporaryExpression = temporaryExpression.Replace("AND", " && ");

				// Pass the simplified logical expression into JSCriptEvaluate method and return the result to the caller.
				return JScriptEvaluate(expression, temporaryExpression);

			}
			catch(Exception ex)
			{
					if (this.testMode) 
						throw;
					else
						return false;
			}
		}


		/// <summary>
		/// This method takes the "match" and evaluates if it should be true or false
		/// </summary>
		/// <param name="match"></param>
		/// <returns></returns>
		private string GetReplacementValue(Match match)
		{
			bool selected = false;
			int questionIndexID = 0;
			int componentIndexID = 0;
			int answerIndexID = -1;
			// Set Numeric Response to -1, which means no Numeric Response has been provided.
			double numericResponse = -1;
			// Set AlphaNumeric response to null, which means no AlphaNumeric response has been provided.
			string alphaNumericResponse = null;

			string expressionOperator = null;
			// Set Date response to min date, which means no Date response has been provided.
			DateTime dateResponse = DateTime.MinValue;
			bool valid;

			
			// Check if "S" is there
			selected = match.Groups["Selected"].Success;

			// Extract the QuestionIndexID from match
			questionIndexID = int.Parse(match.Groups["QuestionIndexID"].ToString());

			// Extract the ComponentIndexID from match. If AnswerID equals "*" then use -1 as the AnswerID.
			if (match.Groups["ComponentIndexID"].Success && !match.Groups["ComponentIndexID"].ToString().Equals("*"))
			{
				componentIndexID = int.Parse(match.Groups["ComponentIndexID"].ToString());
			}

			// Extract the AnswerIndexID from match. If AnswerID equals "*" then use -1 as the AnswerID.
			if (match.Groups["AnswerIndexID"].Success && !match.Groups["AnswerIndexID"].ToString().Equals("*"))
			{
				answerIndexID = int.Parse(match.Groups["AnswerIndexID"].ToString());
			}

			if (match.Groups["Operator"].Success)
			{
				// Extract the Operator from match
				expressionOperator = match.Groups["Operator"].ToString();
			}
				
			// If a Date Response does not exist 
			if (match.Groups["DateResponse"].Success)
			{
				// Extract Date Response from match and parse it into DateTime.
				dateResponse = DateTime.Parse(match.Groups["DateResponse"].ToString());
			}
				// If a Numeric response exists
			else if (match.Groups["NumericResponse"].Success)
			{
				// Extract Numeric Response from match and parse it into Double.
				numericResponse = Double.Parse(match.Groups["NumericResponse"].ToString());
			}
				// If an AlphaNumeric Response exists
			else if (match.Groups["AlphaNumericResponse"].Success)
			{
				// Extract the AlphaNumeric response from match.
				alphaNumericResponse = match.Groups["AlphaNumericResponse"].ToString();
				if (alphaNumericResponse.StartsWith("\"")) alphaNumericResponse = alphaNumericResponse.Substring(1);
				if (alphaNumericResponse.EndsWith("\"")) alphaNumericResponse = alphaNumericResponse.Substring(0, alphaNumericResponse.Length - 1);

				// Replace escaped double-quotes with unescaped quotes.
				alphaNumericResponse = alphaNumericResponse.Replace("\\\"", "\"");
			}
			// With the addition of S(Qx,Ax) syntax this is no longer needed 
			//			else 
			//			{
			//				throw new LogicException(String.Format("Numeric, Alphanumeric or DateValue must be present: {0}", match.Value));
			//			}
			
			bool isNumeric, isAlpha, isDate = false;
			isNumeric = numericResponse != -1;
			isAlpha = alphaNumericResponse != null;
			isDate = dateResponse != DateTime.MinValue;

			if (selected && answerIndexID == -1)
				throw new LogicException(String.Format("When selected ('S') keyword is used AnswerIndexID must be present: {0}", match.Value));
			if (selected && expressionOperator != null)
				throw new LogicException(String.Format("Selected ('S') and Operator ({0}) cannot be used to together: {0}", match.Value));
			if (expressionOperator != null && !(isNumeric || isAlpha || isDate))
				throw new LogicException(String.Format("Expression contains an operator but no right-hand side value. Make sure you have a value in the correct format after the operator.", match.Value));
			
			// When "selected" shortcut is used, the expression itself cannot contain operator (restricted by line above) or value on the right-hand side but we need the operator to behave as equals (=) and we need to use the answerindexid value
			if (selected)
			{
				expressionOperator = "=";
				numericResponse = answerIndexID;
			}
			
			
			// Pass extracted values to CheckResponse method and get the boolean result.
			valid = CheckResponse(match, questionIndexID, componentIndexID, answerIndexID, expressionOperator, alphaNumericResponse, numericResponse, dateResponse);

			if (valid) return " true "; else return "  false ";
		}



		/// <summary>
		/// This method takes a logic expression as its only parameter. It creates an instance of JScript engine,
		/// passes given expression to the JScriptEvaluate method of Eval class and returns the result returned by 
		/// that method to its caller. In case of an error in evaluation process it returns false.
		/// </summary>
		/// <param name="expression">Logical expression to be evaluated by the JScript engine</param>
		/// <returns></returns>
		private bool JScriptEvaluate(string originalExpression, string expression)
		{
			VsaEngine jsEngine = null;

			try
			{
				// Create an instance of VsaEngine 
				jsEngine = VsaEngine.CreateEngine();
				
				// Pass the expression and engine to Evaluator method.
				object result = Microsoft.JScript.Eval.JScriptEvaluate(expression, jsEngine);
				
				// If the result is something other than null return it
				if (result != null)
				{
					return (bool)result;
				}
				else
				{	
					// If result is null return false;
					return false;
				}

			}
			catch(Exception ex)
			{	
				// If an error occures return false;
				throw new LogicException(String.Format("JScript engine cannot evaluate the expression: {0} : {1}", originalExpression, expression), ex);
			}
		}


		private object JScriptCalculate(string expression)
		{
			VsaEngine jsEngine = null;

			try
			{
				// Create an instance of VsaEngine 
				jsEngine = VsaEngine.CreateEngine();
				
				// Pass the expression and engine to Evaluator method.
				object result = Microsoft.JScript.Eval.JScriptEvaluate(expression, jsEngine);
				
				return result;

			}
			catch
			{	
				// If an error occures return null;
				return null;
			}
		}



		/// <summary>
		/// This method queries the response table with the parameters passed to it, 
		/// in order to find out if the user has matching reponse(s).
		/// </summary>
		/// <param name="questionIndexID">The QuestionIndex ID</param>
		/// <param name="componentIndexID">The ComponentIndex ID</param>
		/// <param name="answerIndexID">The AnswerIndexID. Note: -1 means no specific AnswerID is provided (A*) </param>
		/// <param name="expressionOperator">The Operator used in the expression</param>
		/// <param name="alphaNumericResponse">If Answer type is freetext this is provided. If this is null then numericResponse is used.</param>
		/// <param name="numericResponse">Numeric Response</param>
		/// <returns></returns>
		private bool CheckResponse(Match match, int questionIndexID, int componentIndexID, int answerIndexID, string expressionOperator, string alphaNumericResponse, double numericResponse, DateTime dateResponse)
		{

			bool isNumeric, isAlpha, isDate = false;
			isNumeric = numericResponse != -1;
			isAlpha = alphaNumericResponse != null;
			isDate = dateResponse != DateTime.MinValue;

			try
			{

				ArrayList responses = null;
				Question question = questions.FindByIndexID(questionIndexID, componentIndexID);

				if (question == null)
					throw new LogicException(String.Format("QuestionIndexID {0} cannot be found: {1}", questionIndexID, match.Value));

				question.SqlData.Transaction = questions.SqlData.Transaction;

				if (!this.testMode)
					responses = assessmentContext.GetLatestReponses(question.QuestionID, true, true);

				Answer answer = null;
				Response responseToCheck = null;
				ArrayList responsesToCheck = new ArrayList(5);
				if (answerIndexID >= 0)
				{
					answer = question.Answers.FindByAnswerIndexID(answerIndexID);

					if (answer == null)
						throw new LogicException(String.Format("Question (QuestionIndexID = {0}) does not have an answer with AnswerIndexID {1}: {2}", questionIndexID, answerIndexID, match.Value));

					if (!this.testMode)
					{
						for (int index = 0; index < responses.Count; index++)
						{
							if (((Response)responses[index]).AnswerID == answer.AnswerID)
								responseToCheck = (Response)responses[index];
						}
						if (responseToCheck != null)
							responsesToCheck.Add(responseToCheck);
					}
				}
				else
				{
					if (!this.testMode)
					{
						responsesToCheck = responses;
					}
				}

			
				// At this point we know the question and answer are valid
				if (this.testMode)
				{
					bool foundQ = false;
					if (questionsInvolved != null)
					{
						for (int index = 0; index < questionsInvolved.Count; index++ )
						{
							if (((LogicQuestion)questionsInvolved[index]).QuestionID == question.QuestionID)
							{
								foundQ = true;
								break;
							}
						}
					}
					if (!foundQ)
						questionsInvolved.Add(question);	
					
					return true;
				}
			

				if (responsesToCheck != null)
				{
					Response currentResponse = null;
					bool found = false;
					for (int index = 0; index < responsesToCheck.Count; index++)
					{
						currentResponse = responsesToCheck[index] as Response;
						if (currentResponse != null)
						{
							if (CompareValues(match, currentResponse, isNumeric, isAlpha, isDate, expressionOperator, alphaNumericResponse, numericResponse, dateResponse))
							{
								found = true;
								break;
							}
						}
					}
			
					return found;
				}
			}
			catch(Exception ex)
			{
				throw new LogicException(String.Format("Error occured while evaluating the logic expression: {0}, Error Detail: {1}", match.Value, ex.Message), ex);
			}


			return false;
		}


		/// <summary>
		/// This method compares the user's response with the value in the logic expression
		/// </summary>
		/// <param name="currentResponse"></param>
		/// <param name="isNumeric"></param>
		/// <param name="isAlpha"></param>
		/// <param name="isDate"></param>
		/// <param name="expressionOperator"></param>
		/// <param name="alphaNumericResponse"></param>
		/// <param name="numericResponse"></param>
		/// <param name="dateResponse"></param>
		/// <returns></returns>
		private bool CompareValues(Match match, Response currentResponse, bool isNumeric, bool isAlpha, bool isDate, string expressionOperator, string alphaNumericResponse, double numericResponse, DateTime dateResponse)
		{
			switch (expressionOperator)
			{
				case "<":
					if ((isNumeric && double.Parse(currentResponse.AnswerText) < numericResponse) ||
						(isDate && DateTime.Parse(currentResponse.AnswerText) < dateResponse))
						return true;
					else if (isAlpha) 
						throw new LogicException(String.Format("Operator < cannot be used together with an alphanumeric value: {0}", match.Value));
					;
					break;
				case ">":
					if ((isNumeric && double.Parse(currentResponse.AnswerText) > numericResponse) ||
						(isDate && DateTime.Parse(currentResponse.AnswerText) > dateResponse))
						return true;
					else if (isAlpha) 
						throw new LogicException(String.Format("Operator > cannot be used together with an alphanumeric value: {0}", match.Value));
					break;
				case "=":
					if ((isNumeric && double.Parse(currentResponse.AnswerText) == numericResponse) ||
						(isDate && DateTime.Parse(currentResponse.AnswerText) == dateResponse) ||
						(isAlpha && currentResponse.AnswerText == alphaNumericResponse))
						return true;
					break;
				case "!=":
					if ((isNumeric && double.Parse(currentResponse.AnswerText) != numericResponse) ||
						(isDate && DateTime.Parse(currentResponse.AnswerText) != dateResponse) ||
						(isAlpha && currentResponse.AnswerText != alphaNumericResponse))
						return true;
					break;
				case ">=":
					if ((isNumeric && double.Parse(currentResponse.AnswerText) >= numericResponse) ||
						(isDate && DateTime.Parse(currentResponse.AnswerText) >= dateResponse))
						return true;
					else if (isAlpha)
						throw new LogicException(String.Format("Operator >= cannot be used together with an alphanumeric value: {0}", match.Value));
					break;
				case "<=":
					if ((isNumeric && double.Parse(currentResponse.AnswerText) <= numericResponse) ||
						(isDate && DateTime.Parse(currentResponse.AnswerText) <= dateResponse))
						return true;
					else if (isAlpha)
						throw new LogicException(String.Format("Operator <= cannot be used together with an alphanumeric value: {0}", match.Value));
					break;

			}

			return false;
		}
	}
}
