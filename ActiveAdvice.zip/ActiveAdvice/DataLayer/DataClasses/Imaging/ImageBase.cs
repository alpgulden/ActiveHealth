using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [Image]
	/// </summary>
	[SPAutoGen("usp_LoadAllImages","SelectAll.sptpl","")]
	[SPInsert("usp_InsertImage")]
	[SPUpdate("usp_UpdateImage")]
	[SPDelete("usp_DeleteImage")]
	[SPLoad("usp_LoadImage")]
	[TableMapping("ImageBase","imageBaseID")]
	public class ImageBase : BaseData
	{
		[NonSerialized]
		private ImageBaseCollection parentImageBaseCollection;
		[ColumnMapping("ImageBaseID",(int)0)]
		private int imageBaseID;
		[ColumnMapping("Description")]
		private string description;
		[ColumnMapping("Note")]
		private string note;
		[ColumnMapping("ImageByte")]
		private Byte[] imageByte;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		private ImageLinkCollection imageLinks;
	
		public ImageBase()
		{
		}
		
		public ImageBase(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ImageBaseID
		{
			get { return this.imageBaseID; }
			set { this.imageBaseID = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=45)]
		public string Description
		{
			get { return this.description; }
			set { this.description = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string Note
		{
			get { return this.note; }
			set { this.note = value; }
		}


		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Child ImageLinks mapped to related rows of table ImageLink where [ImageBaseID] = [ImageBaseID]
		/// </summary>
		[SPLoadChild("usp_LoadImageImageLink", "imageBaseID")]
		public ImageLinkCollection ImageLinks
		{
			get { return this.imageLinks; }
			set
			{
				this.imageLinks = value;
				if (value != null)
					value.ParentImageBase = this; // set this as a parent of the child collection
			}
		}

		/// <summary>
		/// Loads the ImageLinks collection
		/// </summary>
		public void LoadImageLinks(bool forceReload)
		{
			this.imageLinks = (ImageLinkCollection)ImageLinkCollection.LoadChildCollection("ImageLinks", this, typeof(ImageLinkCollection), imageLinks, forceReload, null);
		}

		/// <summary>
		/// Saves the ImageLinks collection
		/// </summary>
		public void SaveImageLinks()
		{
			ImageLinkCollection.SaveChildCollection(this.imageLinks, true);
		}

		/// <summary>
		/// Synchronizes the ImageLinks collection
		/// </summary>
		public void SynchronizeImageLinks()
		{
			ImageLinkCollection.SynchronizeChildCollection(this.imageLinks, true);
		}

		public byte[] ImageByte
		{
			get { return this.imageByte; }
			set { this.imageByte = value; }
		}

		/// <summary>
		/// Parent ImageBaseCollection that contains this element
		/// </summary>
		public ImageBaseCollection ParentImageBaseCollection
		{
			get
			{
				return this.parentImageBaseCollection;
			}
			set
			{
				this.parentImageBaseCollection = value; // parent is set when added to a collection
			}
		}

		/// <summary>
		/// Updates or Inserts the object into the table.  If the primary key is null, it'll be inserted.
		/// </summary>
		public new void Save()
		{
			// If there are contained objects to be saved in transaction
			// ensure transaction to use the passed transaction or to create one if there's no transaction;
			// this.SqlData.EnsureTransaction();
			try
			{
				base.Save();
				// this.SqlData.CommitTransaction(); // this works only if the transaction is not borrowed
			}
			catch
			{
				// this.SqlData.RollbackTransaction(); // this works only if the transaction is not borrowed
				// Failure handling code here
				throw; // always re-throw exception to notify the client
			}		
		}

		/// <summary>
		/// Loads the object specified by a PK value from table
		/// </summary>
		public bool Load(int imageBaseID)
		{
			return base.Load(imageBaseID);
		}
	}

	/// <summary>
	/// Strongly typed collection of ImageBase objects
	/// </summary>
	[ElementType(typeof(ImageBase))]
	public class ImageBaseCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_ImageBaseID;
		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int LoadAllImages(int maxRecords)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_LoadAllImages", maxRecords, this, false);
		}

		/// <summary>
		/// Hashtable based index on imageBaseID fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_ImageBaseID
		{
			get
			{
				if (this.indexBy_ImageBaseID == null)
					this.indexBy_ImageBaseID = new CollectionIndexer(this, new string[] { "imageBaseID" }, true);
				return this.indexBy_ImageBaseID;
			}
			
		}

		/// <summary>
		/// Hashtable based search on imageBaseID fields returns the collection index.  Uses the IndexBy_ImageBaseID indexer.
		/// </summary>
		public int IndexOf(int imageBaseID)
		{
			return this.IndexBy_ImageBaseID.IndexOf(imageBaseID);
		}

		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(ImageBase elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentImageBaseCollection = this;
			else
				elem.ParentImageBaseCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (ImageBase elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public ImageBase this[int index]
		{
			get
			{
				return (ImageBase)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((ImageBase)oldValue, false);
			SetParentOnElem((ImageBase)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}
	}
}
