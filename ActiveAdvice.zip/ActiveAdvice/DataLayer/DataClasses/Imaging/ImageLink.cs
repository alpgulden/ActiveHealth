using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [ImageLink]
	/// </summary>
	[SPInsert("usp_InsertImageLink")]
	[SPUpdate("usp_UpdateImageLink")]
	[SPDelete("usp_DeleteImageLink")]
	[SPLoad("usp_LoadImageLink")]
	[TableMapping("ImageLink","imageLinkID")]
	public class ImageLink : BaseData
	{
		[NonSerialized]
		private ImageLinkCollection parentImageLinkCollection;
		[ColumnMapping("ImageLinkID",(int)0)]
		private int imageLinkID;
		[ColumnMapping("EventID")]
		private int eventID;
		[ColumnMapping("PatientID")]
		private int patientID;
		[ColumnMapping("CMSID")]
		private int cMSID;
		[ColumnMapping("ImageBaseID")]
		private int imageBaseID;
		[ColumnMapping("CreateTime")]
		private DateTime createTime;
		[ColumnMapping("CreatedBy")]
		private int createdBy;
		[ColumnMapping("ModifyTime")]
		private DateTime modifyTime;
		[ColumnMapping("ModifiedBy")]
		private int modifiedBy;
		[ColumnMapping("Active")]
		private bool active;
		[ColumnMapping("ReferralID")]
		private int referralID;
		[ColumnMapping("PhysicianReviewID")]
		private int physicianReviewID;
		[ColumnMapping("SortOrder")]
		private int sortOrder;
	
		public ImageLink()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public ImageLink(bool initNew)
		{
			if (initNew) // initialize record if requested
				this.NewRecord();
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int ImageLinkID
		{
			get { return this.imageLinkID; }
			set { this.imageLinkID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int EventID
		{
			get { return this.eventID; }
			set { this.eventID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PatientID
		{
			get { return this.patientID; }
			set { this.patientID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int CMSID
		{
			get { return this.cMSID; }
			set { this.cMSID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ImageBaseID
		{
			get { return this.imageBaseID; }
			set { this.imageBaseID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime CreateTime
		{
			get { return this.createTime; }
			set { this.createTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int CreatedBy
		{
			get { return this.createdBy; }
			set { this.createdBy = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.ShortDate)]
		public System.DateTime ModifyTime
		{
			get { return this.modifyTime; }
			set { this.modifyTime = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ModifiedBy
		{
			get { return this.modifiedBy; }
			set { this.modifiedBy = value; }
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int ReferralID
		{
			get { return this.referralID; }
			set { this.referralID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int PhysicianReviewID
		{
			get { return this.physicianReviewID; }
			set { this.physicianReviewID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int)]
		public int SortOrder
		{
			get { return this.sortOrder; }
			set { this.sortOrder = value; }
		}

		/// <summary>
		/// Override this to initialize members for a new data object to be inserted into DB.
		/// </summary>
		protected override void NewRecord()
		{
			base.NewRecord();
			// Initialize members here.
			// Reset fk member values for the contained objects here so that they'll be created as new when they're accessed
		}

		/// <summary>
		/// Parent ImageLinkCollection that contains this element
		/// </summary>
		public ImageLinkCollection ParentImageLinkCollection
		{
			get
			{
				return this.parentImageLinkCollection;
			}
			set
			{
				this.parentImageLinkCollection = value; // parent is set when added to a collection
			}
		}
	}

	/// <summary>
	/// Strongly typed collection of ImageLink objects
	/// </summary>
	[ElementType(typeof(ImageLink))]
	public class ImageLinkCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		/// <summary>
		/// Parent Image that contains this collection
		/// </summary>
		public ImageBase ParentImageBase
		{
			get { return this.ParentDataObject as ImageBase; }
			set { this.ParentDataObject = value; /* parent is set when contained by a Image */ }
		}
	}
}
