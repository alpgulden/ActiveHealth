using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [NamePrefix]
	/// </summary>
	[SPAutoGen("usp_GetNamePrefixesByActive","SelectAllByGivenArgs.sptpl","active")]
	[SPInsert("usp_InsertNamePrefix")]
	[SPUpdate("usp_UpdateNamePrefix")]
	[SPDelete("usp_DeleteNamePrefix")]
	[SPLoad("usp_LoadNamePrefix")]
	[TableMapping("NamePrefix","namePrefixId")]
	public class NamePrefix : BaseData
	{
		[NonSerialized]
		private NamePrefixCollection parentNamePrefixCollection;
		[ColumnMapping("NamePrefixId",StereoType=DataStereoType.FK)]
		private int namePrefixId;
		[ColumnMapping("Prefix")]
		private string prefix;
		[ColumnMapping("Active")]
		private bool active = true;
		[ColumnMapping("ReadOnly")]
		private bool readOnly;
		[ColumnMapping("NotePad")]
		private string notePad;
	
		public NamePrefix()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		[ControlType(EnumControlTypes.TextBox, ValueForNull=(int)0)]
		public int NamePrefixId
		{
			get { return this.namePrefixId; }
			set { this.namePrefixId = value; }
		}

		[ControlType(EnumControlTypes.TextBox, ClientValidators=EnumClientValidators.Required, MaxLength=16)]
		public string Prefix
		{
			get { return this.prefix; }
			set { this.prefix = value; }
		}

		[ControlType(EnumControlTypes.CheckBox)]
		public bool Active
		{
			get { return this.active; }
			set { this.active = value; }
		}

		/// <summary>
		/// Parent NamePrefixCollection that contains this element
		/// </summary>
		public NamePrefixCollection ParentNamePrefixCollection
		{
			get
			{
				return this.parentNamePrefixCollection;
			}
			set
			{
				this.parentNamePrefixCollection = value; // parent is set when added to a collection
			}
		}

		[ControlType(EnumControlTypes.CheckBox, ClientValidators=EnumClientValidators.Required)]
		public bool ReadOnly
		{
			get { return this.readOnly; }
			set { this.readOnly = value; }
		}

		[ControlType(EnumControlTypes.TextBox, MaxLength=2000)]
		public string NotePad
		{
			get { return this.notePad; }
			set { this.notePad = value; }
		}
	}

	/// <summary>
	/// Strongly typed collection of NamePrefix objects
	/// </summary>
	[ElementType(typeof(NamePrefix))]
	public class NamePrefixCollection : NetsoftUSA.DataLayer.BaseDataCollectionClass
	{
		[NonSerialized]
		private CollectionIndexer indexBy_namePrefixId;
		/// <summary>
		/// Sets/Unsets this as the parent collection on the specified element
		/// </summary>
		private void SetParentOnElem(NamePrefix elem, bool setUnset)
		{
			if (setUnset)
				elem.ParentNamePrefixCollection = this;
			else
				elem.ParentNamePrefixCollection = null;		
		}

		protected override void OnClear()
		{
			foreach (NamePrefix elem in base.List)
				SetParentOnElem(elem, false);
			base.OnClear();		
		}

		/// <summary>
		/// Gets/Sets the object at the given index
		/// </summary>
		public NamePrefix this[int index]
		{
			get
			{
				return (NamePrefix)List[index];
			}
			set
			{
				List[index] = value;
			}
		}

		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			SetParentOnElem((NamePrefix)oldValue, false);
			SetParentOnElem((NamePrefix)newValue, true);
			base.OnSetComplete (index, oldValue, newValue);		
		}

		/// <summary>
		/// Executes a stored procedure.
		/// </summary>
		public int GetNamePrefixesByActive(int maxRecords, bool active)
		{
			this.Clear();
			return SqlData.SPExecReadCol("usp_GetNamePrefixesByActive", maxRecords, this, false, new object[] { active });
		}

		/// <summary>
		/// Accessor to a shared NamePrefixCollection which is cached in NSGlobal
		/// </summary>
		public static NamePrefixCollection ActiveNamePrefixes
		{
			get
			{
				bool initialize = true;

				// Get a cached instance of the collection
				NamePrefixCollection col = (NamePrefixCollection)NSGlobal.EnsureCachedObject("ActiveNamePrefixes", typeof(NamePrefixCollection), ref initialize);
				if (initialize)
				{
					// initialize the content of the collection
					col.GetNamePrefixesByActive(-1, true);
				}
				return col;
			}
			
		}

		/// <summary>
		/// Hashtable based index on namePrefixId fields allows fast access to item indices
		/// </summary>
		public CollectionIndexer IndexBy_namePrefixId
		{
			get
			{
				if (this.indexBy_namePrefixId == null)
					this.indexBy_namePrefixId = new CollectionIndexer(this, new string[] { "namePrefixId" }, true);
				return this.indexBy_namePrefixId;
			}
			
		}

		/// <summary>
		/// Hashtable based search on namePrefixId fields returns the object.  Uses the IndexBy_namePrefixId indexer.
		/// </summary>
		public NamePrefix FindBy(int namePrefixId)
		{
			return (NamePrefix)this.IndexBy_namePrefixId.GetObject(namePrefixId);
		}
	}
}
