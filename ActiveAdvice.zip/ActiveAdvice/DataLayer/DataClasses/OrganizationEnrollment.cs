using System;

using NetsoftUSA.DataLayer;


namespace ActiveAdvice.DataLayer
{
	/// <summary>
	/// Data class that wraps the entity access functionality to table [OrganizationEnrollment]
	/// </summary>
	[TableMapping("OrganizationEnrollment")]
	public class OrganizationEnrollment : BaseData
	{
		[ColumnMapping("OrganizationID")]
		private int organizationID;
		[ColumnMapping("EnrollmentID")]
		private int enrollmentID;
	
		public OrganizationEnrollment()
		{
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int OrganizationID
		{
			get { return this.organizationID; }
			set { this.organizationID = value; }
		}

		[ControlType(Macro=EnumControlTypeMacros.Int, IsRequired=true)]
		public int EnrollmentID
		{
			get { return this.enrollmentID; }
			set { this.enrollmentID = value; }
		}
	}
}
