using System;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using ActiveAdvice.DataLayer;
using NetsoftUSA.DataLayer;

namespace TestDataLayer
{
	public class TestSubscribers : TestDataLayer.BaseTestForm
	{
		private System.Windows.Forms.Button butTestCRUD;
		private System.Windows.Forms.Button butCreateSubscriberCoverage;
		private System.ComponentModel.IContainer components = null;

		public TestSubscribers()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.butTestCRUD = new System.Windows.Forms.Button();
			this.butCreateSubscriberCoverage = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// butTestCRUD
			// 
			this.butTestCRUD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butTestCRUD.Location = new System.Drawing.Point(8, 296);
			this.butTestCRUD.Name = "butTestCRUD";
			this.butTestCRUD.TabIndex = 1;
			this.butTestCRUD.Text = "TestCRUD";
			this.butTestCRUD.Click += new System.EventHandler(this.butTestCRUD_Click);
			// 
			// butCreateSubscriberCoverage
			// 
			this.butCreateSubscriberCoverage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butCreateSubscriberCoverage.Location = new System.Drawing.Point(8, 224);
			this.butCreateSubscriberCoverage.Name = "butCreateSubscriberCoverage";
			this.butCreateSubscriberCoverage.Size = new System.Drawing.Size(96, 56);
			this.butCreateSubscriberCoverage.TabIndex = 2;
			this.butCreateSubscriberCoverage.Text = "Create Subscriber-Coverage";
			this.butCreateSubscriberCoverage.Click += new System.EventHandler(this.butCreateSubscriberCoverage_Click);
			// 
			// TestSubscribers
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 321);
			this.Controls.Add(this.butCreateSubscriberCoverage);
			this.Controls.Add(this.butTestCRUD);
			this.Name = "TestSubscribers";
			this.Text = "DataLayer Test - Subscriber";
			this.Load += new System.EventHandler(this.TestSubscribers_Load);
			this.Controls.SetChildIndex(this.butTestCRUD, 0);
			this.Controls.SetChildIndex(this.butCreateSubscriberCoverage, 0);
			this.ResumeLayout(false);

		}
		#endregion

		private void TestSubscribers_Load(object sender, System.EventArgs e)
		{
			
		}

		private void butTestCRUD_Click(object sender, System.EventArgs e)
		{
			OrganizationCollection sorgs = new OrganizationCollection();
			//sorgs.LoadOrganizationsOf(1);

			Organization sorg = sorgs[0];

			for (int i = 0; i < 100; i++)
			{
				Subscriber obj = new Subscriber(true);  // Use appropriate constructor
				obj.SocialSecurityNumber = "12345";
				// Do other initializations on the object;
				//obj.Save();
				Debug.WriteLine("Saved Subscriber PK="+obj.PKString);
				Debug.Assert(obj.Load(obj.SubscriberId), "Load failed for Subscriber PK="+obj.PKString);
				Debug.WriteLine("Loaded Subscriber PK="+obj.PKString);
				// do some change in the properties
				//obj.Save();
				Debug.WriteLine("Updated Subscriber PK="+obj.PKString);
				obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
				Debug.WriteLine("Deleted Subscriber PK="+obj.PKString);
			}

		}

		private void butCreateSubscriberCoverage_Click(object sender, System.EventArgs e)
		{
			Subscriber subs = new Subscriber();
			if (!subs.Load(9))
				return;

			Plan plan = new Plan();
			if (!plan.Load(1))
				return;

			Organization sorg = new Organization();
			if (!sorg.Load(108))
				return;

		}
	}
}

