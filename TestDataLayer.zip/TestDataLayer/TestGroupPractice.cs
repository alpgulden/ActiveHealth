using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using ActiveAdvice.DataLayer;

namespace TestDataLayer
{
	public class TestGroupPractice : TestDataLayer.BaseTestForm
	{
		private System.Windows.Forms.Button butTest1;
		private System.Windows.Forms.TextBox txtGPID;
		private System.Windows.Forms.Button btnAddGPType;
		private System.Windows.Forms.Button btnLinkProvider;
		private System.Windows.Forms.Button btnAddGPLoc;
		private System.ComponentModel.IContainer components = null;

		public TestGroupPractice()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.butTest1 = new System.Windows.Forms.Button();
			this.txtGPID = new System.Windows.Forms.TextBox();
			this.btnAddGPType = new System.Windows.Forms.Button();
			this.btnLinkProvider = new System.Windows.Forms.Button();
			this.btnAddGPLoc = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// butTest1
			// 
			this.butTest1.Location = new System.Drawing.Point(16, 296);
			this.butTest1.Name = "butTest1";
			this.butTest1.TabIndex = 1;
			this.butTest1.Text = "Add GP";
			this.butTest1.Click += new System.EventHandler(this.butTest1_Click);
			// 
			// txtGPID
			// 
			this.txtGPID.Location = new System.Drawing.Point(624, 296);
			this.txtGPID.Name = "txtGPID";
			this.txtGPID.Size = new System.Drawing.Size(32, 20);
			this.txtGPID.TabIndex = 2;
			this.txtGPID.Text = "1";
			// 
			// btnAddGPType
			// 
			this.btnAddGPType.Location = new System.Drawing.Point(96, 296);
			this.btnAddGPType.Name = "btnAddGPType";
			this.btnAddGPType.Size = new System.Drawing.Size(80, 23);
			this.btnAddGPType.TabIndex = 3;
			this.btnAddGPType.Text = "Add GP Type";
			this.btnAddGPType.Click += new System.EventHandler(this.btnAddGPType_Click);
			// 
			// btnLinkProvider
			// 
			this.btnLinkProvider.Location = new System.Drawing.Point(264, 296);
			this.btnLinkProvider.Name = "btnLinkProvider";
			this.btnLinkProvider.Size = new System.Drawing.Size(80, 23);
			this.btnLinkProvider.TabIndex = 4;
			this.btnLinkProvider.Text = "Link Provider";
			this.btnLinkProvider.Click += new System.EventHandler(this.btnLinkProvider_Click);
			// 
			// btnAddGPLoc
			// 
			this.btnAddGPLoc.Location = new System.Drawing.Point(184, 296);
			this.btnAddGPLoc.Name = "btnAddGPLoc";
			this.btnAddGPLoc.TabIndex = 5;
			this.btnAddGPLoc.Text = "Add Location";
			this.btnAddGPLoc.Click += new System.EventHandler(this.btnAddGPLoc_Click);
			// 
			// TestGroupPractice
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 321);
			this.Controls.Add(this.btnAddGPLoc);
			this.Controls.Add(this.btnLinkProvider);
			this.Controls.Add(this.btnAddGPType);
			this.Controls.Add(this.txtGPID);
			this.Controls.Add(this.butTest1);
			this.Name = "TestGroupPractice";
			this.Load += new System.EventHandler(this.TestGroupPractice_Load);
			this.Controls.SetChildIndex(this.butTest1, 0);
			this.Controls.SetChildIndex(this.txtGPID, 0);
			this.Controls.SetChildIndex(this.btnAddGPType, 0);
			this.Controls.SetChildIndex(this.btnLinkProvider, 0);
			this.Controls.SetChildIndex(this.btnAddGPLoc, 0);
			this.ResumeLayout(false);

		}
		#endregion

		private void butTest1_Click(object sender, System.EventArgs e)
		{
			for (int i=1; i <= 5; i++)
			{
				GroupPractice gp = new GroupPractice();
				gp.New();
				gp.Active			= true;
				gp.AddedOnTheFly	= false;
				gp.AlternateID		= "124012213123" + i.ToString();
				gp.CreatedBy		= 1;
				gp.CreateTime		= DateTime.Now;
				gp.Email			= "testgp" + i.ToString() + "@netsoft-usa.com";
				//gp.FederalTaxID		= "1233312312" + i.ToString();
				//gp.MedicareID		= "4141231231" + i.ToString();
				gp.Name				= "Test Group Practice" + i.ToString();
				gp.Note				= "This is a test group practice #" + i.ToString() + " added through the testGP module";
				gp.TypeID			= 1;
				gp.Save();
				WriteLine("Test Group Practice Added");
			}

			return;

		}

		private void btnAddGPType_Click(object sender, System.EventArgs e)
		{

		}

		private void btnLinkProvider_Click(object sender, System.EventArgs e)
		{
			GroupPractice gp = new GroupPractice();
			try
			{
				gp.Load(int.Parse(txtGPID.Text));
			}
			catch
			{
				MessageBox.Show("An error has occurred while loading the group practice, please check GPID and try again.");
				return;
			}
			
			try
			{
				gp.LoadLocations(false);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
				return;
			}

			if (gp.Locations.Count > 0)
			{
				foreach (GroupPracticeLocation gpLoc in gp.Locations)
				{
//					GroupPracticeProviderLink gpProviderLink = new GroupPracticeProviderLink();
//					gpProviderLink.New();
//					gpProviderLink.ProviderID = 4;
//					gpProviderLink.LocationID = 7;
//					gpProviderLink.CreatedBy  = 1;
//					gpProviderLink.CreateTime = DateTime.Now;
//					gpProviderLink.AsOfDate	  = DateTime.Now;
					
					
					
//					gpProviderLink.Save();
					gpLoc.LoadProviders(true);
//					gpLoc.Providers.Add(gpProviderLink);
//					WriteLine("Provider #4 added to current GP w/ Location ID# 7");
					foreach (GroupPracticeProviderLink gpProvLink in gpLoc.Providers)
					{
						//gpProvLink.EffDate		= DateTime.Now.AddDays(4);
						//gpProvLink.TerminationDate = DateTime.Now.AddDays(10);
						//gpProvLink.AsOfDate	= DateTime.Now;
						//gpProvLink.TermID	= 1;
						gpProvLink.MarkDirty();
						WriteLine("Provider Effective and Term Dates have been changed");
					}
					gpLoc.Save();
					WriteLine("GP Location saved");
				}
			}
			else
				WriteLine("No locations found, please add locations to this GP first.");

		
			


		}

		private void TestGroupPractice_Load(object sender, System.EventArgs e)
		{
			
		}

		private void btnAddGPLoc_Click(object sender, System.EventArgs e)
		{
			GroupPractice gp = new GroupPractice();
			try
			{
				gp.Load(int.Parse(txtGPID.Text));
			}
			catch
			{
				MessageBox.Show("An error occured wile loading specigied GP, please check GPID and try again.");
				return;
			}
			
			gp.LoadLocations(true);
			
			Address addr = new Address();
			addr.New();
			addr.Line1			= "46 East Joh St.";
			addr.City			= "Hicksville";
			addr.State			= "NY";
			addr.Zip			= "11801";
			addr.PhoneNumber1	= "5163331303";
			addr.FaxNumber		= "1234234234";
			addr.DeliveryMethod = Address.EnumDeliveryMethod.Mail;
			addr.County			= "Nassau";
			addr.County			= "U.S.";
			addr.Save();
			WriteLine("New address created w/ ID:" + addr.AddressID);

			GroupPracticeLocation gpLoc = new GroupPracticeLocation();
			gpLoc.New();
			gpLoc.GroupPracticeID		  = gp.GroupPracticeID;
			gpLoc.Location.ServiceAddress = addr;
			gpLoc.Location.BillingAddress = addr;
			gpLoc.CreateTime			  = DateTime.Now;
			gpLoc.CreatedBy				  = 1;
			gpLoc.Save();
			
			gp.Locations.Add(gpLoc);
			WriteLine("New location added to locations collection");
			gp.Locations.Save();
			WriteLine("Locations saved");
		}
	}
}

