using System;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using ActiveAdvice.DataLayer;

namespace TestDataLayer
{
	public class TestProvider : TestDataLayer.BaseTestForm
	{
		private System.Windows.Forms.Button butTest1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox txtProviderID;
		private System.Windows.Forms.Button btnSpecialties;
		private System.Windows.Forms.Button btnAddSpecialties;
		private System.Windows.Forms.Button btnLanguages;
		private System.Windows.Forms.Button btnAddLanguage;
		private System.Windows.Forms.Button btnServices;
		private System.Windows.Forms.Button btnAddServType;
		private System.ComponentModel.IContainer components = null;

		public TestProvider()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.butTest1 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.txtProviderID = new System.Windows.Forms.TextBox();
			this.btnSpecialties = new System.Windows.Forms.Button();
			this.btnAddSpecialties = new System.Windows.Forms.Button();
			this.btnLanguages = new System.Windows.Forms.Button();
			this.btnAddLanguage = new System.Windows.Forms.Button();
			this.btnServices = new System.Windows.Forms.Button();
			this.btnAddServType = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// butTest1
			// 
			this.butTest1.Location = new System.Drawing.Point(8, 296);
			this.butTest1.Name = "butTest1";
			this.butTest1.Size = new System.Drawing.Size(72, 23);
			this.butTest1.TabIndex = 1;
			this.butTest1.Text = "Test Location ";
			this.butTest1.Click += new System.EventHandler(this.butTest1_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(80, 296);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(80, 23);
			this.button1.TabIndex = 2;
			this.button1.Text = "Add Provider";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// txtProviderID
			// 
			this.txtProviderID.Location = new System.Drawing.Point(632, 296);
			this.txtProviderID.Name = "txtProviderID";
			this.txtProviderID.Size = new System.Drawing.Size(32, 20);
			this.txtProviderID.TabIndex = 3;
			this.txtProviderID.Text = "1";
			// 
			// btnSpecialties
			// 
			this.btnSpecialties.Location = new System.Drawing.Point(160, 296);
			this.btnSpecialties.Name = "btnSpecialties";
			this.btnSpecialties.Size = new System.Drawing.Size(72, 23);
			this.btnSpecialties.TabIndex = 4;
			this.btnSpecialties.Text = "Specialty T";
			this.btnSpecialties.Click += new System.EventHandler(this.btnSpecialties_Click);
			// 
			// btnAddSpecialties
			// 
			this.btnAddSpecialties.Location = new System.Drawing.Point(232, 296);
			this.btnAddSpecialties.Name = "btnAddSpecialties";
			this.btnAddSpecialties.Size = new System.Drawing.Size(80, 23);
			this.btnAddSpecialties.TabIndex = 5;
			this.btnAddSpecialties.Text = "Add 10 Specialties";
			this.btnAddSpecialties.Click += new System.EventHandler(this.btnAddSpecialties_Click);
			// 
			// btnLanguages
			// 
			this.btnLanguages.Location = new System.Drawing.Point(312, 296);
			this.btnLanguages.Name = "btnLanguages";
			this.btnLanguages.Size = new System.Drawing.Size(56, 23);
			this.btnLanguages.TabIndex = 6;
			this.btnLanguages.Text = "Languages";
			this.btnLanguages.Click += new System.EventHandler(this.btnLanguages_Click);
			// 
			// btnAddLanguage
			// 
			this.btnAddLanguage.Location = new System.Drawing.Point(368, 296);
			this.btnAddLanguage.Name = "btnAddLanguage";
			this.btnAddLanguage.Size = new System.Drawing.Size(64, 23);
			this.btnAddLanguage.TabIndex = 7;
			this.btnAddLanguage.Text = "Add Languages";
			this.btnAddLanguage.Click += new System.EventHandler(this.button2_Click);
			// 
			// btnServices
			// 
			this.btnServices.Location = new System.Drawing.Point(432, 296);
			this.btnServices.Name = "btnServices";
			this.btnServices.TabIndex = 8;
			this.btnServices.Text = "Add Service";
			this.btnServices.Click += new System.EventHandler(this.btnServices_Click);
			// 
			// btnAddServType
			// 
			this.btnAddServType.Location = new System.Drawing.Point(504, 296);
			this.btnAddServType.Name = "btnAddServType";
			this.btnAddServType.TabIndex = 9;
			this.btnAddServType.Text = "Add SType";
			this.btnAddServType.Click += new System.EventHandler(this.btnAddServType_Click);
			// 
			// TestProvider
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 321);
			this.Controls.Add(this.btnAddServType);
			this.Controls.Add(this.btnServices);
			this.Controls.Add(this.btnAddLanguage);
			this.Controls.Add(this.btnLanguages);
			this.Controls.Add(this.btnAddSpecialties);
			this.Controls.Add(this.btnSpecialties);
			this.Controls.Add(this.txtProviderID);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.butTest1);
			this.Name = "TestProvider";
			this.Load += new System.EventHandler(this.TestProvider_Load);
			this.Controls.SetChildIndex(this.butTest1, 0);
			this.Controls.SetChildIndex(this.button1, 0);
			this.Controls.SetChildIndex(this.txtProviderID, 0);
			this.Controls.SetChildIndex(this.btnSpecialties, 0);
			this.Controls.SetChildIndex(this.btnAddSpecialties, 0);
			this.Controls.SetChildIndex(this.btnLanguages, 0);
			this.Controls.SetChildIndex(this.btnAddLanguage, 0);
			this.Controls.SetChildIndex(this.btnServices, 0);
			this.Controls.SetChildIndex(this.btnAddServType, 0);
			this.ResumeLayout(false);

		}
		#endregion

		private void butTest1_Click(object sender, System.EventArgs e)
		{
			
			Provider prov = new Provider();
			prov.Load(int.Parse(txtProviderID.Text));
			
			prov.LoadLocations(false);
			if (prov.Locations.Count > 0)
			{
				foreach (ProviderLocation loc in prov.Locations)
				{
					WriteLine(loc.LocationID + " " + loc.Location.ServiceAddress.ToString());
				}
			}
			else
			{
				WriteLine("No Provider Locations Found.");
				/*Address addr = new Address();
				addr.New();
				addr.Line1   = "24 25W";
				addr.City	 = "NYC";
				addr.State	 = "NY";
				addr.Zip	 = "10001";
				addr.PhoneNumber1 = "2126743442";
				addr.Save();

				Location loc = new Location();
				loc.New();
				loc.ServiceAddressID	= addr.AddressID;
				loc.BillingAddressID	= addr.AddressID;
				loc.MailingAddressID	= addr.AddressID;
				loc.Save();

				ProviderLocation provLoc = new ProviderLocation();
				provLoc.New();
				provLoc.CreateTime					  = DateTime.Now;
				provLoc.CreatedBy					  = 1;

				provLoc.ProviderID		 = int.Parse(txtProviderID.Text);
				provLoc.Location.ServiceAddress.Line1 = "24 25W";
				provLoc.Location.ServiceAddress.City  = "NYC";
				provLoc.Location.ServiceAddress.State = "NY";
				provLoc.Location.ServiceAddress.Zip   = "10001";
				provLoc.Location.ServiceAddress.PhoneNumber1 = "2123314134";
				provLoc.Save();*/
				
			}

		}

		private void TestProvider_Load(object sender, System.EventArgs e)
		{
			
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			Provider myProvider				= new Provider();
			myProvider.New();
			myProvider.FirstName			= "Anderson";
			myProvider.LastName				= "Smith";
			myProvider.Active				= true;
			myProvider.AddedOnTheFly		= false;
			myProvider.AlternateID			= "5489858";
			myProvider.Beeper				= null;
			myProvider.BeeperExtension		= null;
			myProvider.CreatedBy			= 1;
			myProvider.CreateTime			= DateTime.Now;
			myProvider.DateActive			= DateTime.Now;
			myProvider.Email				= "smith@netsoft-usa.com";
			//myProvider.FederalTaxID			= "123-33-3313";
			myProvider.Gender				= "M";
			//myProvider.MedicareID			= "333233123133";
			myProvider.MiddleInitial		= null;
			myProvider.Note					= "Test Provider created using test form";
			myProvider.PrefixId				= 1;

			
			//myProvider.ProviderLanguages	= new ProviderLanguageCollection();
			//ProviderLanguage provLang		= new ProviderLanguage();
			//provLang.Load(1);
			//myProvider.ProviderLanguages.Add(provLang);
			//myProvider.UPIN					= "311-143-4839";
			myProvider.Save();
			this.Text = "Provider Added";
				
		}

		private void btnSpecialties_Click(object sender, System.EventArgs e)
		{
			Provider prov = new Provider();
			prov.Load(int.Parse(txtProviderID.Text));
			prov.LoadSpecialties(false);		// fixed
			if (prov.Specialties.Count > 0)
			{
				foreach (ProviderSpecialty ps in prov.Specialties)
				{
					WriteLine(ps.SpecialtyID.ToString());
					
					

				}
			}
			else
			{
				WriteLine("No specialties found.");
			}
		}

		private void btnAddSpecialties_Click(object sender, System.EventArgs e)
		{
			/*
			for (int i = 0; i < 9; i++)
			{
				Specialty spec		= new Specialty();
				spec.New();
				spec.Inactive		= false;
				spec.Note			= "Test Provider Specialty " + i.ToString();
				spec.SpecialtyCode	= "Test" + i.ToString();
				spec.Save();
				WriteLine("Specialty Added. ID: " + spec.SpecialtyID);
			}*/
			
			for (int i = 1; i < 11; i++)
			{
				try
				{
					ProviderSpecialty specialty = new ProviderSpecialty();
					specialty.New();
					specialty.CreateTime		= DateTime.Now;
					specialty.CreatedBy 		= 1;
					specialty.ProviderID		= int.Parse(txtProviderID.Text);
					specialty.SpecialtyID		= i;
					
					
					specialty.Save();
					WriteLine("Provider Specialty Added. ProviderSpecialtyID: " + specialty.ProviderSpecialtyID);
				}
				catch (Exception ex)
				{
					WriteLine(ex.Message);
				}
			}

		}

		private void btnLanguages_Click(object sender, System.EventArgs e)
		{
			Provider provider = new Provider();
			provider.Load(int.Parse(txtProviderID.Text));
			provider.LoadProviderLanguages(false);		// fixed
			if (provider.ProviderLanguages.Count > 0)
			{
				foreach (ProviderLanguage provLang in provider.ProviderLanguages)
				{
					WriteLine(provLang.Language);
				}
			}
			else
			{
				WriteLine("No Languages Found for this provider.");
			}
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			Provider prov = new Provider();
			prov.Load(int.Parse(txtProviderID.Text));
			for (int i = 0; i < 10; i++)
			{
				ProviderLanguage lang = new ProviderLanguage();
				lang.New();
				lang.LanguageID		  = 1;
				lang.ProviderID		  = int.Parse(txtProviderID.Text);
				lang.CreatedBy		  = 1;
				lang.CreateTime		  = DateTime.Now;
				lang.Save();
			}
		}

		private void btnServices_Click(object sender, System.EventArgs e)
		{
			Provider provider = new Provider();
			provider.Load(int.Parse(txtProviderID.Text));
			provider.LoadLocations(false);		// fixed
			if (provider.Locations.Count > 0)
			{
				foreach (ProviderLocation loc in provider.Locations)
				{
					loc.LoadServices(true);
					for (int i=0; i < 5; i++)
					{
						
						ProviderLocationService locService = new ProviderLocationService();
						locService.New();
						//locService.CreateTime				= DateTime.Now;		// auto-set
						locService.CreatedBy				= 1;
						//locService.EffectiveTime			= DateTime.Now;		// auto-set
						locService.ProviderLocationID		= loc.LocationID;
						locService.ProviderServiceTypeID	= 1;
						locService.Save();
						loc.Services.Add(locService);		
						WriteLine("Location Service Added: " + locService.ProviderLocationServiceID);
					}
					loc.Save();
                    WriteLine("Location saved");
				}
				provider.Locations.Save();
				WriteLine("Provider Locations Saved");
				provider.Save();
				WriteLine("Provider Saved" + provider.ProviderID);
			}
			else
			{
				WriteLine("No Locations");
			}

		}

		private void btnAddServType_Click(object sender, System.EventArgs e)
		{
			ProviderServiceType servType = new ProviderServiceType();
			servType.New();
			
			servType.Description			 = "Some Service";
			servType.Code = "SERV1";
////			servType.Notepad				 = "Note regarding this service type";
			servType.Save();		
		}
	}
}

