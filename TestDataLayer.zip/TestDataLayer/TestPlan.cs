using System;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using NetsoftUSA.DataLayer;
using ActiveAdvice.DataLayer;

namespace TestDataLayer
{
	public class TestPlan : TestDataLayer.BaseTestForm
	{
		private System.Windows.Forms.Button butTestCRUD;
		private System.Windows.Forms.Button butCreateVariousPlans;
		private System.ComponentModel.IContainer components = null;

		public TestPlan()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.butTestCRUD = new System.Windows.Forms.Button();
			this.butCreateVariousPlans = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// butTestCRUD
			// 
			this.butTestCRUD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butTestCRUD.Location = new System.Drawing.Point(8, 296);
			this.butTestCRUD.Name = "butTestCRUD";
			this.butTestCRUD.TabIndex = 2;
			this.butTestCRUD.Text = "TestCRUD";
			this.butTestCRUD.Click += new System.EventHandler(this.butTestCRUD_Click);
			// 
			// butCreateVariousPlans
			// 
			this.butCreateVariousPlans.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butCreateVariousPlans.Location = new System.Drawing.Point(96, 296);
			this.butCreateVariousPlans.Name = "butCreateVariousPlans";
			this.butCreateVariousPlans.Size = new System.Drawing.Size(128, 23);
			this.butCreateVariousPlans.TabIndex = 3;
			this.butCreateVariousPlans.Text = "Create Various Plans";
			this.butCreateVariousPlans.Click += new System.EventHandler(this.butCreateVariousPlans_Click);
			// 
			// TestPlan
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 321);
			this.Controls.Add(this.butCreateVariousPlans);
			this.Controls.Add(this.butTestCRUD);
			this.Name = "TestPlan";
			this.Text = "DataLayer Test - Plan";
			this.Load += new System.EventHandler(this.TestPlan_Load);
			this.Controls.SetChildIndex(this.butTestCRUD, 0);
			this.Controls.SetChildIndex(this.butCreateVariousPlans, 0);
			this.ResumeLayout(false);

		}
		#endregion

		private void TestPlan_Load(object sender, System.EventArgs e)
		{
			
		}

		private void butTestCRUD_Click(object sender, System.EventArgs e)
		{
			for (int i = 0; i < 100; i++)
			{
				Plan obj = new Plan("PLAN " + i.ToString(), 1, 1, 1, 1, 1);  // Use appropriate constructor
				// Do other initializations on the object;
				obj.CreatedBy = 2;	// ilkay
				obj.Save();
				Debug.WriteLine("Saved Subscriber PK="+obj.PKString);
				Debug.Assert(obj.Load(obj.PlanId), "Load failed for Subscriber PK="+obj.PKString);
				Debug.WriteLine("Loaded Subscriber PK="+obj.PKString);
				// do some change in the properties
				obj.Save();
				Debug.WriteLine("Updated Subscriber PK="+obj.PKString);
				obj.MarkDel();  // Mark for deletion
				obj.Save();  // Delete it
				Debug.WriteLine("Deleted Subscriber PK="+obj.PKString);
			}
		}

		private void butCreateVariousPlans_Click(object sender, System.EventArgs e)
		{
			Plan plan = null;
			
			plan = new Plan("PLAN With empty management service", 1, 1, 1, 1, 1);  // Use appropriate constructor
			plan.CreatedBy = 2;
			plan.Save();

			plan = new Plan("PLAN With Management Service", 1, 1, 1, 1, 1);  // Use appropriate constructor
			plan.ManagementService.Note = "the note of the plan's management service";
			plan.CreatedBy = 2;
			plan.Save();
		}

	}
}

