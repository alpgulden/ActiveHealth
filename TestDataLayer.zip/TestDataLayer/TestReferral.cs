using System;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using NetsoftUSA.DataLayer;
using ActiveAdvice.DataLayer;

namespace TestDataLayer
{
	public class TestReferral: TestDataLayer.BaseTestForm
	{
		private System.Windows.Forms.TextBox txtFacID;
		private System.Windows.Forms.Button btnAddReferralType;
		private System.Windows.Forms.Button btnAddReferralUnitType;
		private System.Windows.Forms.Button btnGetReferralUnitType;
		private System.Windows.Forms.Button btnGetReferralType;
		private System.Windows.Forms.Button btnGetUrgency;
		private System.Windows.Forms.Button btnAddUrgency;
		private System.Windows.Forms.Button btnGetAuthorizationDecision;
		private System.Windows.Forms.Button btnAddAuthorizationDecision;
		private System.Windows.Forms.Button btnGetDecisionReason;
		private System.Windows.Forms.Button btnAddDecisionReason;
		private System.Windows.Forms.Button btnGetReferralScheduleBy;
		private System.Windows.Forms.Button btnAddReferralScheduleBy;
		private System.Windows.Forms.Button btnGetReferralRole;
		private System.Windows.Forms.Button btnAllReferralRole;
		private System.Windows.Forms.Button btnAddReferral;
		private System.Windows.Forms.Button btnReferralChilds;
		private System.ComponentModel.IContainer components = null;

		public TestReferral()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnAddReferral = new System.Windows.Forms.Button();
			this.txtFacID = new System.Windows.Forms.TextBox();
			this.btnAddReferralType = new System.Windows.Forms.Button();
			this.btnAddReferralUnitType = new System.Windows.Forms.Button();
			this.btnGetReferralUnitType = new System.Windows.Forms.Button();
			this.btnGetUrgency = new System.Windows.Forms.Button();
			this.btnAddUrgency = new System.Windows.Forms.Button();
			this.btnGetReferralType = new System.Windows.Forms.Button();
			this.btnGetAuthorizationDecision = new System.Windows.Forms.Button();
			this.btnAddAuthorizationDecision = new System.Windows.Forms.Button();
			this.btnGetDecisionReason = new System.Windows.Forms.Button();
			this.btnAddDecisionReason = new System.Windows.Forms.Button();
			this.btnGetReferralScheduleBy = new System.Windows.Forms.Button();
			this.btnAddReferralScheduleBy = new System.Windows.Forms.Button();
			this.btnGetReferralRole = new System.Windows.Forms.Button();
			this.btnAllReferralRole = new System.Windows.Forms.Button();
			this.btnReferralChilds = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnAddReferral
			// 
			this.btnAddReferral.Location = new System.Drawing.Point(312, 280);
			this.btnAddReferral.Name = "btnAddReferral";
			this.btnAddReferral.Size = new System.Drawing.Size(88, 23);
			this.btnAddReferral.TabIndex = 1;
			this.btnAddReferral.Text = "Add Referral";
			this.btnAddReferral.Click += new System.EventHandler(this.btnAddReferral_Click);
			// 
			// txtFacID
			// 
			this.txtFacID.Location = new System.Drawing.Point(624, 296);
			this.txtFacID.Name = "txtFacID";
			this.txtFacID.Size = new System.Drawing.Size(40, 20);
			this.txtFacID.TabIndex = 3;
			this.txtFacID.Text = "1";
			// 
			// btnAddReferralType
			// 
			this.btnAddReferralType.Location = new System.Drawing.Point(0, 208);
			this.btnAddReferralType.Name = "btnAddReferralType";
			this.btnAddReferralType.Size = new System.Drawing.Size(120, 23);
			this.btnAddReferralType.TabIndex = 4;
			this.btnAddReferralType.Text = "ADD ReferralType";
			this.btnAddReferralType.Click += new System.EventHandler(this.btnAddReferralType_Click);
			// 
			// btnAddReferralUnitType
			// 
			this.btnAddReferralUnitType.Location = new System.Drawing.Point(120, 208);
			this.btnAddReferralUnitType.Name = "btnAddReferralUnitType";
			this.btnAddReferralUnitType.Size = new System.Drawing.Size(128, 23);
			this.btnAddReferralUnitType.TabIndex = 6;
			this.btnAddReferralUnitType.Text = "ADD ReferralUnitType";
			this.btnAddReferralUnitType.Click += new System.EventHandler(this.btnAddReferralUnitType_Click);
			// 
			// btnGetReferralUnitType
			// 
			this.btnGetReferralUnitType.Location = new System.Drawing.Point(120, 232);
			this.btnGetReferralUnitType.Name = "btnGetReferralUnitType";
			this.btnGetReferralUnitType.Size = new System.Drawing.Size(128, 23);
			this.btnGetReferralUnitType.TabIndex = 8;
			this.btnGetReferralUnitType.Text = "Get ReferralUnitType";
			this.btnGetReferralUnitType.Click += new System.EventHandler(this.btnGetReferralUnitType_Click);
			// 
			// btnGetUrgency
			// 
			this.btnGetUrgency.Location = new System.Drawing.Point(248, 232);
			this.btnGetUrgency.Name = "btnGetUrgency";
			this.btnGetUrgency.Size = new System.Drawing.Size(128, 23);
			this.btnGetUrgency.TabIndex = 10;
			this.btnGetUrgency.Text = "Get Urgency";
			this.btnGetUrgency.Click += new System.EventHandler(this.btnGetUrgency_Click);
			// 
			// btnAddUrgency
			// 
			this.btnAddUrgency.Location = new System.Drawing.Point(248, 208);
			this.btnAddUrgency.Name = "btnAddUrgency";
			this.btnAddUrgency.Size = new System.Drawing.Size(128, 23);
			this.btnAddUrgency.TabIndex = 9;
			this.btnAddUrgency.Text = "ADD Urgency";
			this.btnAddUrgency.Click += new System.EventHandler(this.btnAddUrgency_Click);
			// 
			// btnGetReferralType
			// 
			this.btnGetReferralType.Location = new System.Drawing.Point(0, 232);
			this.btnGetReferralType.Name = "btnGetReferralType";
			this.btnGetReferralType.Size = new System.Drawing.Size(120, 23);
			this.btnGetReferralType.TabIndex = 11;
			this.btnGetReferralType.Text = "Get ReferralType";
			this.btnGetReferralType.Click += new System.EventHandler(this.btnGetReferralType_Click);
			// 
			// btnGetAuthorizationDecision
			// 
			this.btnGetAuthorizationDecision.Location = new System.Drawing.Point(376, 232);
			this.btnGetAuthorizationDecision.Name = "btnGetAuthorizationDecision";
			this.btnGetAuthorizationDecision.Size = new System.Drawing.Size(144, 23);
			this.btnGetAuthorizationDecision.TabIndex = 13;
			this.btnGetAuthorizationDecision.Text = "Get AuthorizationDecision";
			this.btnGetAuthorizationDecision.Click += new System.EventHandler(this.btnGetAuthorizationDecision_Click);
			// 
			// btnAddAuthorizationDecision
			// 
			this.btnAddAuthorizationDecision.Location = new System.Drawing.Point(376, 208);
			this.btnAddAuthorizationDecision.Name = "btnAddAuthorizationDecision";
			this.btnAddAuthorizationDecision.Size = new System.Drawing.Size(144, 23);
			this.btnAddAuthorizationDecision.TabIndex = 12;
			this.btnAddAuthorizationDecision.Text = "ADD AuthorizationDecision";
			this.btnAddAuthorizationDecision.Click += new System.EventHandler(this.btnAddAuthorizationDecision_Click);
			// 
			// btnGetDecisionReason
			// 
			this.btnGetDecisionReason.Location = new System.Drawing.Point(520, 232);
			this.btnGetDecisionReason.Name = "btnGetDecisionReason";
			this.btnGetDecisionReason.Size = new System.Drawing.Size(144, 23);
			this.btnGetDecisionReason.TabIndex = 15;
			this.btnGetDecisionReason.Text = "Get DecisionReason";
			this.btnGetDecisionReason.Click += new System.EventHandler(this.btnGetDecisionReason_Click);
			// 
			// btnAddDecisionReason
			// 
			this.btnAddDecisionReason.Location = new System.Drawing.Point(520, 208);
			this.btnAddDecisionReason.Name = "btnAddDecisionReason";
			this.btnAddDecisionReason.Size = new System.Drawing.Size(144, 23);
			this.btnAddDecisionReason.TabIndex = 14;
			this.btnAddDecisionReason.Text = "ADD DecisionReason";
			this.btnAddDecisionReason.Click += new System.EventHandler(this.btnAddDecisionReason_Click);
			// 
			// btnGetReferralScheduleBy
			// 
			this.btnGetReferralScheduleBy.Location = new System.Drawing.Point(0, 280);
			this.btnGetReferralScheduleBy.Name = "btnGetReferralScheduleBy";
			this.btnGetReferralScheduleBy.Size = new System.Drawing.Size(144, 23);
			this.btnGetReferralScheduleBy.TabIndex = 17;
			this.btnGetReferralScheduleBy.Text = "Get ReferralScheduleBy";
			this.btnGetReferralScheduleBy.Click += new System.EventHandler(this.btnGetReferralScheduleBy_Click);
			// 
			// btnAddReferralScheduleBy
			// 
			this.btnAddReferralScheduleBy.Location = new System.Drawing.Point(0, 256);
			this.btnAddReferralScheduleBy.Name = "btnAddReferralScheduleBy";
			this.btnAddReferralScheduleBy.Size = new System.Drawing.Size(144, 23);
			this.btnAddReferralScheduleBy.TabIndex = 16;
			this.btnAddReferralScheduleBy.Text = "ADD ReferralScheduleBy";
			this.btnAddReferralScheduleBy.Click += new System.EventHandler(this.btnAddReferralScheduleBy_Click);
			// 
			// btnGetReferralRole
			// 
			this.btnGetReferralRole.Location = new System.Drawing.Point(144, 280);
			this.btnGetReferralRole.Name = "btnGetReferralRole";
			this.btnGetReferralRole.Size = new System.Drawing.Size(144, 23);
			this.btnGetReferralRole.TabIndex = 19;
			this.btnGetReferralRole.Text = "Get ReferralRole";
			this.btnGetReferralRole.Click += new System.EventHandler(this.btnGetReferralRole_Click);
			// 
			// btnAllReferralRole
			// 
			this.btnAllReferralRole.Location = new System.Drawing.Point(144, 256);
			this.btnAllReferralRole.Name = "btnAllReferralRole";
			this.btnAllReferralRole.Size = new System.Drawing.Size(144, 23);
			this.btnAllReferralRole.TabIndex = 18;
			this.btnAllReferralRole.Text = "ADD ReferralRole";
			this.btnAllReferralRole.Click += new System.EventHandler(this.btnAllReferralRole_Click);
			// 
			// btnReferralChilds
			// 
			this.btnReferralChilds.Location = new System.Drawing.Point(400, 280);
			this.btnReferralChilds.Name = "btnReferralChilds";
			this.btnReferralChilds.Size = new System.Drawing.Size(112, 23);
			this.btnReferralChilds.TabIndex = 20;
			this.btnReferralChilds.Text = "Add Referral Childs";
			this.btnReferralChilds.Click += new System.EventHandler(this.btnReferralChilds_Click);
			// 
			// TestReferral
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 319);
			this.Controls.Add(this.btnReferralChilds);
			this.Controls.Add(this.btnGetReferralRole);
			this.Controls.Add(this.btnAllReferralRole);
			this.Controls.Add(this.btnGetReferralScheduleBy);
			this.Controls.Add(this.btnAddReferralScheduleBy);
			this.Controls.Add(this.btnGetDecisionReason);
			this.Controls.Add(this.btnAddDecisionReason);
			this.Controls.Add(this.btnGetAuthorizationDecision);
			this.Controls.Add(this.btnAddAuthorizationDecision);
			this.Controls.Add(this.btnGetReferralType);
			this.Controls.Add(this.btnGetUrgency);
			this.Controls.Add(this.btnAddUrgency);
			this.Controls.Add(this.btnGetReferralUnitType);
			this.Controls.Add(this.btnAddReferralUnitType);
			this.Controls.Add(this.btnAddReferralType);
			this.Controls.Add(this.txtFacID);
			this.Controls.Add(this.btnAddReferral);
			this.Name = "TestReferral";
			this.Load += new System.EventHandler(this.TestModuleX_Load);
			this.Controls.SetChildIndex(this.btnAddReferral, 0);
			this.Controls.SetChildIndex(this.txtFacID, 0);
			this.Controls.SetChildIndex(this.btnAddReferralType, 0);
			this.Controls.SetChildIndex(this.btnAddReferralUnitType, 0);
			this.Controls.SetChildIndex(this.btnGetReferralUnitType, 0);
			this.Controls.SetChildIndex(this.btnAddUrgency, 0);
			this.Controls.SetChildIndex(this.btnGetUrgency, 0);
			this.Controls.SetChildIndex(this.btnGetReferralType, 0);
			this.Controls.SetChildIndex(this.btnAddAuthorizationDecision, 0);
			this.Controls.SetChildIndex(this.btnGetAuthorizationDecision, 0);
			this.Controls.SetChildIndex(this.btnAddDecisionReason, 0);
			this.Controls.SetChildIndex(this.btnGetDecisionReason, 0);
			this.Controls.SetChildIndex(this.btnAddReferralScheduleBy, 0);
			this.Controls.SetChildIndex(this.btnGetReferralScheduleBy, 0);
			this.Controls.SetChildIndex(this.btnAllReferralRole, 0);
			this.Controls.SetChildIndex(this.btnGetReferralRole, 0);
			this.Controls.SetChildIndex(this.btnReferralChilds, 0);
			this.ResumeLayout(false);

		}
		#endregion

		private void TestModuleX_Load(object sender, System.EventArgs e)
		{
			
		}

		private void btnAddNetwork_Click(object sender, System.EventArgs e)
		{


			for (int i=1; i < 10; i++)
			{
				Network network = null;
				try
				{
					Address addrNew			= new Address();
					addrNew.New();
					
					addrNew.City			= "Hicksville";
					addrNew.County			= "NASSAU";
					addrNew.Country			= "U.S.";
					addrNew.DeliveryMethod	= Address.EnumDeliveryMethod.Email;
					addrNew.Line1			= "46 East John St " + i.ToString();
					addrNew.PhoneNumber1	= "5166723540";
					addrNew.PhoneExt1		= "12";
					addrNew.State			= "NY";
					addrNew.Save();
					network = new Network();
					network.New();
					network.Name			= "Test Network #" + i.ToString();
					network.New();
					network.CreatedBy		= 1;
					network.CreateTime		= DateTime.Now;
					network.AddressID		= addrNew.AddressID;
					network.AlternateID		= "ALT123123" + i.ToString();
					network.EffectiveDate	= DateTime.Now.AddDays(i);
					network.Email			= "testnetwork" + i.ToString() + "@netsoft-usa.com";
					network.Note			= "Note for Test Network #" + i.ToString();
					network.TypeID			= (i % 5) + 1;
					network.Save();
				}
				catch (Exception ex)
				{
					MessageBox.Show("An error occurred while saving Network: " + ex.Message);
					return;
				}
				WriteLine("Network saved; network ID #" + network.NetworkID.ToString());
			}

			
		}

		private void btnAddReferralType_Click(object sender, System.EventArgs e)
		{
			for (int i=0; i < 5; i++)
			{
				ReferralType referralType = new ReferralType();
				referralType.New();
				referralType.Active		= true;
				referralType.Description		= "ReferralType" + i.ToString();
				referralType.Code	= "REFTYPE#" + i.ToString();
				WriteLine("Referral Type ID #" + i.ToString() + " saved to DB");
				referralType.Save();
			}
		}

		private void btnAddReferralUnitType_Click(object sender, System.EventArgs e)
		{
			for (int i=0; i < 1; i++)
			{
				ReferralUnitType referralUnitType = new ReferralUnitType();
				referralUnitType.New();
				referralUnitType.Active		= true;
				referralUnitType.Description		= "ReferralUnitType" + i.ToString();
				referralUnitType.Code	= "REFTYPE#" + i.ToString();
				WriteLine("Referral Unit Type ID #" + i.ToString() + " saved to DB");
				referralUnitType.Save();
			}
		}

		private void btnGetReferralUnitType_Click(object sender, System.EventArgs e)
		{			
			ReferralUnitTypeCollection referralUnitTypeCollection = new ReferralUnitTypeCollection();
			referralUnitTypeCollection.LoadReferralUnitTypesByActive(-1,true);
			for (int i=0 ;i< referralUnitTypeCollection.Count ; i++)
			{
				WriteLine(referralUnitTypeCollection[i].Description.ToString());	
			}		
		}

		private void btnGetReferralType_Click(object sender, System.EventArgs e)
		{
			ReferralTypeCollection referralTypeCollection = new ReferralTypeCollection();
			referralTypeCollection.LoadReferralTypesByActive(-1,true);
			for (int i=0 ;i< referralTypeCollection.Count ; i++)
			{
				WriteLine(referralTypeCollection[i].Description.ToString());
			}			
		}

		private void btnAddUrgency_Click(object sender, System.EventArgs e)
		{
//			for (int i=0; i < 5; i++)
//			{
//				Urgency urgency = new Urgency();
//				urgency.New();
//				urgency.Active		= true;
//				urgency.Description	= ((int)(i+1)*24).ToString();
//				urgency.Code	= "URG#" + i.ToString();
//				WriteLine("Urgency Unit #" + i.ToString() + " saved to DB");
//				urgency.Save();
//			}		
		}

		private void btnGetUrgency_Click(object sender, System.EventArgs e)
		{
			UrgencyCollection urgencyColl = new UrgencyCollection();
			urgencyColl.LoadUrgencyByActive(-1,true);
			for (int i=0 ;i< urgencyColl.Count ; i++)
			{
				WriteLine(urgencyColl[i].Description.ToString());
			}		
		}

		private void btnAddAuthorizationDecision_Click(object sender, System.EventArgs e)
		{
//			for (int i=0; i < 5; i++)
//			{
//				AuthorizationDecision authDecision = new AuthorizationDecision();
//				//authDecision.New();
//				//authDecision.Active		= true;
//				//authDecision.Description	= "AuthorizationDecision" + i.ToString();
//				//authDecision.Code	= "AUT#" + i.ToString();
//				WriteLine("Authorization Decision #" + i.ToString() + " saved to DB");
//				//authDecision.Save();
//			}			
		}

		private void btnGetAuthorizationDecision_Click(object sender, System.EventArgs e)
		{
//			AuthorizationDecisionCollection authDecisionColl = new AuthorizationDecisionCollection();
//			authDecisionColl.LoadAuthorizationDecisionByActive(-1,true);
//			for (int i=0 ;i< authDecisionColl.Count ; i++)
//			{
//				WriteLine(authDecisionColl[i].Description.ToString());
//			}			
		}

		private void btnGetDecisionReason_Click(object sender, System.EventArgs e)
		{
			DecisionReasonCollection decisionReasonColl = new DecisionReasonCollection();
			decisionReasonColl.LoadDecisionReasonByActive(-1,true);
			for (int i=0 ;i< decisionReasonColl.Count ; i++)
			{
				WriteLine(decisionReasonColl[i].Description.ToString());
			}			
		}

		private void btnAddDecisionReason_Click(object sender, System.EventArgs e)
		{
			for (int i=0; i < 5; i++)
			{
				DecisionReason decisionReason = new DecisionReason();
				decisionReason.New();
				decisionReason.Active		= true;
				decisionReason.Description	= "DecisionReason" + i.ToString();
				decisionReason.Code	= "AUT#" + i.ToString();
				WriteLine("Decision Reason #" + i.ToString() + " saved to DB");
				decisionReason.Save();
			}	
		}

		private void btnAddReferralScheduleBy_Click(object sender, System.EventArgs e)
		{
			for (int i=0; i < 5; i++)
			{
				ReferralScheduledBy refScheduleBy = new ReferralScheduledBy();
				refScheduleBy.New();
				refScheduleBy.Active		= true;
				refScheduleBy.Description	= "ReferralScheduledBy" + i.ToString();
				refScheduleBy.Code	= "AUT#" + i.ToString();
				WriteLine("Referral Scheduled By #" + i.ToString() + " saved to DB");
				refScheduleBy.Save();
			}			
		}

		private void btnGetReferralScheduleBy_Click(object sender, System.EventArgs e)
		{
			/*ReferralScheduledByCollection refScheduleByColl = new ReferralScheduledByCollection();
			refScheduleByColl.LoadReferralScheduledBy_ByActive(-1,true);
			for (int i=0 ;i< refScheduleByColl.Count ; i++)
			{
				WriteLine(refScheduleByColl[i].Description.ToString());
			}*/			
		}

		private void btnAllReferralRole_Click(object sender, System.EventArgs e)
		{
			for (int i=0; i < 5; i++)
			{
				ReferralRole referralRole = new ReferralRole();
				referralRole.New();
				referralRole.Active		= true;
				referralRole.Description	= "ReferralRole" + i.ToString();
				referralRole.Code	= "AUT#" + i.ToString();
				WriteLine("Referral Role #" + i.ToString() + " saved to DB");
				referralRole.Save();
			}			
		}

		private void btnGetReferralRole_Click(object sender, System.EventArgs e)
		{
			ReferralRoleCollection referralRoleColl = new ReferralRoleCollection();
			referralRoleColl.LoadReferralRoleByActive(-1,true);
			for (int i=0 ;i< referralRoleColl.Count ; i++)
			{
				WriteLine(referralRoleColl[i].Description.ToString());
			}			
		}

		private void btnAddReferral_Click(object sender, System.EventArgs e)
		{
			/*
			Referral obj = new Referral(true);			
			obj.ReferralTypeID = 1;
			obj.CreatedBy = 1;
			obj.CreateTime = DateTime.Now;;
			obj.Save();
			Debug.WriteLine("Referral Class saved to DB"  + "XXX" +  obj.IsNew.ToString() + "XXX" /*+ obj.LookupOf_ReferralTypeID.Count.ToString());
			obj.MarkDel();
			obj.Save();
			Debug.WriteLine("Deleted Referral PK="+obj.PKString);			
			//Referral obj1 = new Referral(20,2);
			//obj1.Save();
			Debug.WriteLine("Referral Class obj1 saved to DB" + obj.PKString);
			obj1.ReferralDescription = "Test1";
			obj1.Save();
			Referral obj2 = new Referral();
			obj2.Load(obj1.ReferralID);
			Debug.WriteLine("loaded obj1 to obj2" + obj2.PKString);
			Debug.WriteLine("Referral Class obj2" + obj2.ReferralDescription);			
			*/
		}

		private void btnReferralChilds_Click(object sender, System.EventArgs e)
		{
			/*
			Referral obj = new Referral();
			obj.Load(42);
			obj.ReferralDescription = "description XXX";
			obj.Save();
			Debug.WriteLine(obj.LookupOf_ReferralTypeID[obj.ReferralTypeID].Description.ToString());
			ReferralDetail obj1 = new ReferralDetail();
			obj1.Load(16);
			obj.LoadReferralDetails(true);
			if(obj.ReferralDetails.Count>0)
				Debug.WriteLine(obj.ReferralDetails[0].Reason.ToString());
			//ReferralAppointment obj2 = new ReferralAppointment(true);
			//obj2.ReferralDetailID = obj1.ReferralDetailID;
			//obj2.AppointmentDate = DateTime.Now;
			//obj2.ReferralScheduledByID = 1;
			//obj2.CreatedBy = 1;
			//obj2.CreateTime = DateTime.Now;
			//obj2.Save();
			//obj1.LoadReferralAppointments(true);
			//Debug.WriteLine(obj1.ReferralAppointments[0].AppointmentDate.ToString());
			//ReferralReportEntry obj3 = new ReferralReportEntry(true);
			//obj3.ReferralDetailID= obj1.ReferralDetailID;
			obj3.CreatedBy = 2;
			obj3.CreateTime = DateTime.Now;
			obj3.Save();
			//obj1.LoadReferralReportEntries(true);
			//Debug.WriteLine(obj1.ReferralReportEntries[0].ReferralDetailID.ToString());*/
		}
	}
}

