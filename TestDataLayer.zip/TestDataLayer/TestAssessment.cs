using System;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using NetsoftUSA.DataLayer;
using ActiveAdvice.DataLayer;

namespace TestDataLayer
{
	public class TestAssessment : TestDataLayer.BaseTestForm
	{
		private System.Windows.Forms.Button button1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public TestAssessment()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(16, 296);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(168, 23);
			this.button1.TabIndex = 1;
			this.button1.Text = "Create Asthma Question";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// TestAssessment
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(768, 337);
			this.Controls.Add(this.button1);
			this.Name = "TestAssessment";
			this.Text = "TestAssessment";
			this.Controls.SetChildIndex(this.button1, 0);
			this.ResumeLayout(false);

		}
		#endregion

		private void button1_Click(object sender, System.EventArgs e)
		{
			Question question = null;
            
			try
			{

				question = new Question(0, "AsthmaLOD test question", QuestionControlTypeEnum.AsthmaLOD, null);
				question.QuestionIndexID = 1;
				question.BuildSubQuestionsAndAnswers();
				question.ContentOwnerID = 1;
				question.Save();


				question = new Question(0, "BMI test question", QuestionControlTypeEnum.BMI, null);
				question.QuestionIndexID = 2;
				question.BuildSubQuestionsAndAnswers();
				question.ContentOwnerID = 1;
				question.Save();


				question = new Question(0, "BP test question", QuestionControlTypeEnum.BP, null);
				question.QuestionIndexID = 3;
				question.BuildSubQuestionsAndAnswers();
				question.ContentOwnerID = 1;
				question.Save();

				question = new Question(0, "DeliveryAge test question", QuestionControlTypeEnum.DeliveryAge, null);
				question.QuestionIndexID = 4;
				question.BuildSubQuestionsAndAnswers();
				question.ContentOwnerID = 1;
				question.Save();

				question = new Question(0, "GestationalAge test question", QuestionControlTypeEnum.GestationalAge, null);
				question.QuestionIndexID = 5;
				question.BuildSubQuestionsAndAnswers();
				question.ContentOwnerID = 1;
				question.Save();

				question = new Question(0, "GramsToPounds test question", QuestionControlTypeEnum.GramsToPounds, null);
				question.QuestionIndexID = 6;
				question.BuildSubQuestionsAndAnswers();
				question.ContentOwnerID = 1;
				question.Save();

				question = new Question(0, "PoundsToGrams test question", QuestionControlTypeEnum.PoundsToGrams, null);
				question.QuestionIndexID = 7;
				question.BuildSubQuestionsAndAnswers();
				question.ContentOwnerID = 1;
				question.Save();


			}
			catch (Exception ex)
			{
				ex = ex;
			}
 






		}
	}
}
