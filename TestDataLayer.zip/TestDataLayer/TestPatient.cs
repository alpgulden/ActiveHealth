using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using NetsoftUSA.DataLayer;
using ActiveAdvice.DataLayer;

namespace TestDataLayer
{
	public class TestPatient : TestDataLayer.BaseTestForm
	{
		private System.Windows.Forms.Button butTestCRUD;
		private System.Windows.Forms.Button butPatientSubscriberCoverage;
		private System.Windows.Forms.Button butPatientProblem;
		private System.Windows.Forms.Button butGetAvailableCoverages;
		private System.Windows.Forms.Button butCreateCoverageFromElig;
		private System.Windows.Forms.Button butTestDRG;
		private System.Windows.Forms.Button butLoadForMomBabyCodeRange;
		private System.Windows.Forms.Button butTestAutoActivity;
		private System.Windows.Forms.Button butAutoActivityManager;
		private System.Windows.Forms.Button butTestEventAutoActivities;
		private System.Windows.Forms.Button btnCreatePatientWithProblems;
		private System.Windows.Forms.TextBox txtDiagCode;
		private System.Windows.Forms.Button butInitDRG;
		private System.Windows.Forms.Button butMemUsageTest;
		private System.ComponentModel.IContainer components = null;

		public TestPatient()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.butTestCRUD = new System.Windows.Forms.Button();
			this.butPatientSubscriberCoverage = new System.Windows.Forms.Button();
			this.butPatientProblem = new System.Windows.Forms.Button();
			this.butGetAvailableCoverages = new System.Windows.Forms.Button();
			this.butCreateCoverageFromElig = new System.Windows.Forms.Button();
			this.butTestDRG = new System.Windows.Forms.Button();
			this.butLoadForMomBabyCodeRange = new System.Windows.Forms.Button();
			this.butTestAutoActivity = new System.Windows.Forms.Button();
			this.butAutoActivityManager = new System.Windows.Forms.Button();
			this.butTestEventAutoActivities = new System.Windows.Forms.Button();
			this.btnCreatePatientWithProblems = new System.Windows.Forms.Button();
			this.txtDiagCode = new System.Windows.Forms.TextBox();
			this.butInitDRG = new System.Windows.Forms.Button();
			this.butMemUsageTest = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// butTestCRUD
			// 
			this.butTestCRUD.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butTestCRUD.Location = new System.Drawing.Point(16, 160);
			this.butTestCRUD.Name = "butTestCRUD";
			this.butTestCRUD.Size = new System.Drawing.Size(160, 23);
			this.butTestCRUD.TabIndex = 2;
			this.butTestCRUD.Text = "TestCRUD";
			this.butTestCRUD.Click += new System.EventHandler(this.butTestCRUD_Click);
			// 
			// butPatientSubscriberCoverage
			// 
			this.butPatientSubscriberCoverage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.butPatientSubscriberCoverage.Location = new System.Drawing.Point(184, 160);
			this.butPatientSubscriberCoverage.Name = "butPatientSubscriberCoverage";
			this.butPatientSubscriberCoverage.Size = new System.Drawing.Size(184, 23);
			this.butPatientSubscriberCoverage.TabIndex = 3;
			this.butPatientSubscriberCoverage.Text = "TestPatientSubscriberCoverage";
			this.butPatientSubscriberCoverage.Click += new System.EventHandler(this.butPatientSubscriberCoverage_Click);
			// 
			// butPatientProblem
			// 
			this.butPatientProblem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.butPatientProblem.Location = new System.Drawing.Point(16, 192);
			this.butPatientProblem.Name = "butPatientProblem";
			this.butPatientProblem.Size = new System.Drawing.Size(160, 23);
			this.butPatientProblem.TabIndex = 4;
			this.butPatientProblem.Text = "Patient Problem";
			this.butPatientProblem.Click += new System.EventHandler(this.butPatientProblem_Click);
			// 
			// butGetAvailableCoverages
			// 
			this.butGetAvailableCoverages.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.butGetAvailableCoverages.Location = new System.Drawing.Point(184, 192);
			this.butGetAvailableCoverages.Name = "butGetAvailableCoverages";
			this.butGetAvailableCoverages.Size = new System.Drawing.Size(184, 23);
			this.butGetAvailableCoverages.TabIndex = 5;
			this.butGetAvailableCoverages.Text = "Get Available Coverages";
			this.butGetAvailableCoverages.Click += new System.EventHandler(this.butGetAvailableCoverages_Click);
			// 
			// butCreateCoverageFromElig
			// 
			this.butCreateCoverageFromElig.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.butCreateCoverageFromElig.Location = new System.Drawing.Point(184, 224);
			this.butCreateCoverageFromElig.Name = "butCreateCoverageFromElig";
			this.butCreateCoverageFromElig.Size = new System.Drawing.Size(184, 23);
			this.butCreateCoverageFromElig.TabIndex = 6;
			this.butCreateCoverageFromElig.Text = "Create Coverage From Eligibility";
			this.butCreateCoverageFromElig.Click += new System.EventHandler(this.butCreateCoverageFromElig_Click);
			// 
			// butTestDRG
			// 
			this.butTestDRG.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.butTestDRG.Location = new System.Drawing.Point(184, 256);
			this.butTestDRG.Name = "butTestDRG";
			this.butTestDRG.Size = new System.Drawing.Size(184, 23);
			this.butTestDRG.TabIndex = 7;
			this.butTestDRG.Text = "Test DRG";
			this.butTestDRG.Click += new System.EventHandler(this.butTestDRG_Click);
			// 
			// butLoadForMomBabyCodeRange
			// 
			this.butLoadForMomBabyCodeRange.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.butLoadForMomBabyCodeRange.Location = new System.Drawing.Point(376, 160);
			this.butLoadForMomBabyCodeRange.Name = "butLoadForMomBabyCodeRange";
			this.butLoadForMomBabyCodeRange.Size = new System.Drawing.Size(248, 23);
			this.butLoadForMomBabyCodeRange.TabIndex = 8;
			this.butLoadForMomBabyCodeRange.Text = "Load Diags Procs for MomBabyCodeRanges";
			this.butLoadForMomBabyCodeRange.Click += new System.EventHandler(this.butLoadForMomBabyCodeRange_Click);
			// 
			// butTestAutoActivity
			// 
			this.butTestAutoActivity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.butTestAutoActivity.Location = new System.Drawing.Point(376, 192);
			this.butTestAutoActivity.Name = "butTestAutoActivity";
			this.butTestAutoActivity.Size = new System.Drawing.Size(248, 23);
			this.butTestAutoActivity.TabIndex = 9;
			this.butTestAutoActivity.Text = "Test AutoActivity Load Rules";
			this.butTestAutoActivity.Click += new System.EventHandler(this.butTestAutoActivity_Click);
			// 
			// butAutoActivityManager
			// 
			this.butAutoActivityManager.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.butAutoActivityManager.Location = new System.Drawing.Point(376, 224);
			this.butAutoActivityManager.Name = "butAutoActivityManager";
			this.butAutoActivityManager.Size = new System.Drawing.Size(248, 23);
			this.butAutoActivityManager.TabIndex = 10;
			this.butAutoActivityManager.Text = "Test AutoActivityManager";
			this.butAutoActivityManager.Click += new System.EventHandler(this.butAutoActivityManager_Click);
			// 
			// butTestEventAutoActivities
			// 
			this.butTestEventAutoActivities.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.butTestEventAutoActivities.Location = new System.Drawing.Point(376, 256);
			this.butTestEventAutoActivities.Name = "butTestEventAutoActivities";
			this.butTestEventAutoActivities.Size = new System.Drawing.Size(248, 23);
			this.butTestEventAutoActivities.TabIndex = 11;
			this.butTestEventAutoActivities.Text = "Test Event AutoActivities";
			this.butTestEventAutoActivities.Click += new System.EventHandler(this.butTestEventAutoActivities_Click);
			// 
			// btnCreatePatientWithProblems
			// 
			this.btnCreatePatientWithProblems.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnCreatePatientWithProblems.Location = new System.Drawing.Point(16, 224);
			this.btnCreatePatientWithProblems.Name = "btnCreatePatientWithProblems";
			this.btnCreatePatientWithProblems.Size = new System.Drawing.Size(160, 23);
			this.btnCreatePatientWithProblems.TabIndex = 12;
			this.btnCreatePatientWithProblems.Text = "Create Patients w/ Prob";
			this.btnCreatePatientWithProblems.Click += new System.EventHandler(this.btnCreatePatientWithProblems_Click);
			// 
			// txtDiagCode
			// 
			this.txtDiagCode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.txtDiagCode.Location = new System.Drawing.Point(184, 280);
			this.txtDiagCode.Name = "txtDiagCode";
			this.txtDiagCode.TabIndex = 13;
			this.txtDiagCode.Text = "427.5";
			// 
			// butInitDRG
			// 
			this.butInitDRG.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.butInitDRG.Location = new System.Drawing.Point(16, 256);
			this.butInitDRG.Name = "butInitDRG";
			this.butInitDRG.Size = new System.Drawing.Size(160, 23);
			this.butInitDRG.TabIndex = 14;
			this.butInitDRG.Text = "Init DRG";
			this.butInitDRG.Click += new System.EventHandler(this.butInitDRG_Click);
			// 
			// butMemUsageTest
			// 
			this.butMemUsageTest.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.butMemUsageTest.Location = new System.Drawing.Point(376, 288);
			this.butMemUsageTest.Name = "butMemUsageTest";
			this.butMemUsageTest.Size = new System.Drawing.Size(248, 23);
			this.butMemUsageTest.TabIndex = 15;
			this.butMemUsageTest.Text = "Memory usage test";
			this.butMemUsageTest.Click += new System.EventHandler(this.butMemUsageTest_Click);
			// 
			// TestPatient
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 326);
			this.Controls.Add(this.butMemUsageTest);
			this.Controls.Add(this.butInitDRG);
			this.Controls.Add(this.txtDiagCode);
			this.Controls.Add(this.btnCreatePatientWithProblems);
			this.Controls.Add(this.butTestEventAutoActivities);
			this.Controls.Add(this.butAutoActivityManager);
			this.Controls.Add(this.butTestAutoActivity);
			this.Controls.Add(this.butLoadForMomBabyCodeRange);
			this.Controls.Add(this.butTestDRG);
			this.Controls.Add(this.butCreateCoverageFromElig);
			this.Controls.Add(this.butGetAvailableCoverages);
			this.Controls.Add(this.butPatientProblem);
			this.Controls.Add(this.butPatientSubscriberCoverage);
			this.Controls.Add(this.butTestCRUD);
			this.Name = "TestPatient";
			this.Text = "DataLayer Test - Patient";
			this.Load += new System.EventHandler(this.TestPatient_Load);
			this.Closed += new System.EventHandler(this.TestPatient_Closed);
			this.Controls.SetChildIndex(this.butTestCRUD, 0);
			this.Controls.SetChildIndex(this.butPatientSubscriberCoverage, 0);
			this.Controls.SetChildIndex(this.butPatientProblem, 0);
			this.Controls.SetChildIndex(this.butGetAvailableCoverages, 0);
			this.Controls.SetChildIndex(this.butCreateCoverageFromElig, 0);
			this.Controls.SetChildIndex(this.butTestDRG, 0);
			this.Controls.SetChildIndex(this.butLoadForMomBabyCodeRange, 0);
			this.Controls.SetChildIndex(this.butTestAutoActivity, 0);
			this.Controls.SetChildIndex(this.butAutoActivityManager, 0);
			this.Controls.SetChildIndex(this.butTestEventAutoActivities, 0);
			this.Controls.SetChildIndex(this.btnCreatePatientWithProblems, 0);
			this.Controls.SetChildIndex(this.txtDiagCode, 0);
			this.Controls.SetChildIndex(this.butInitDRG, 0);
			this.Controls.SetChildIndex(this.butMemUsageTest, 0);
			this.ResumeLayout(false);

		}
		#endregion

		private void TestPatient_Load(object sender, System.EventArgs e)
		{
			GrouperHIPAA.dllPath = Application.StartupPath + @"\hcfa_020.dll";
			/*ArrayList arr = new ArrayList();
			ActivityTotal tot = new ActivityTotal();
			Debug.WriteLine( tot.GetSingleColumn(arr, "BatchNumber") );

			arr = new ArrayList();
			Debug.WriteLine( tot.GetAllColumns(arr) );

			Debug.WriteLine(arr.Count);*/
		}

		private void butTestCRUD_Click(object sender, System.EventArgs e)
		{
			for (int i = 0; i < 100; i++)
			{
				Patient obj = new Patient("Ilkay", "Benian", GenderCode.Male);  // Use appropriate constructor
				// Do other initializations on the object;
				obj.CreatedBy = 2;	// ilkay
				obj.LanguageCode = "ENGL";
				obj.Save();
				Debug.WriteLine("Saved Subscriber PK="+obj.PKString);
				Debug.Assert(obj.Load(obj.PatientId), "Load failed for Subscriber PK="+obj.PKString);
				Debug.WriteLine("Loaded Subscriber PK="+obj.PKString);
				// do some change in the properties
				obj.Save();
				Debug.WriteLine("Updated Subscriber PK="+obj.PKString);
				obj.MarkDel();  // Mark for deletion
				obj.Save();  // Delete it
				Debug.WriteLine("Deleted Subscriber PK="+obj.PKString);
			}
		}

		private void butPatientSubscriberCoverage_Click(object sender, System.EventArgs e)
		{
			/*SORGCollection sorgs = new SORGCollection();
			sorgs.LoadSORGs(-1);
			SORG sorg = sorgs[0];
			Subscriber subs = new Subscriber(sorg.OrganizationID);
			subs.Save();
			Patient patient = new Patient("Ilkay", "Benian", GenderCode.Male);  // Use appropriate constructor
			patient.LoadPatientSubscriberCoverages(false);
			PatientSubscriberCoverage subscriberCoverage = new PatientSubscriberCoverage(0, subs.SubscriberId, 1);
			patient.LanguageCode = "FREN";
			patient.PatientSubscriberCoverages.Add(subscriberCoverage);
			patient.CreatedBy = 2;	// ilkay
			patient.Save();
			patient.SavePatientSubscriberCoverages();

			subs.LoadPatientSubscriberCoverages(false);
			patient.LoadPatientSubscriberCoverages(true);*/

		
		}

		private void butPatientProblem_Click(object sender, System.EventArgs e)
		{
			Patient pat = new Patient();
			if (!pat.Load(2))
				return;

			//pat.patin

			//Plan

			//PatientProblem prob =  new PatientProblem(

			ProblemCollection problems = pat.GetLinkedProblems();
			Problem problem = new Problem(pat);
			problem.ProblemDescription = "I love my problem.";
			problem.Save();
			problems = pat.GetLinkedProblems();
		}

		private void butGetAvailableCoverages_Click(object sender, System.EventArgs e)
		{
			Patient patient = new Patient();
			if (!patient.Load(2))
				return;

			AvailableCoverageCollection availCovs = new AvailableCoverageCollection();
			availCovs.GenerateCoverageList(-1, patient.PatientId, DateTime.Today);
			this.WriteLine( availCovs.ToString() );
		}

		private void butCreateCoverageFromElig_Click(object sender, System.EventArgs e)
		{
			// Test for creating coverage records from Eligibility

			Patient patient = new Patient();
			if (!patient.Load(233))
				return;
			patient.LoadPatientCoverages(false);
			PatientCoverage patCov = patient.PatientCoverages[0];
			patient.LoadPatientProblems(false);
			//PatientProblem patProblem = patient.PatientProblems[0];
			Problem problem = new Problem(patient);
			CoverageSelectionContext covSelContext = new CoverageSelectionContext(true, patient, patCov, problem, null);
			
			AvailableCoverageCollection availCovs = new AvailableCoverageCollection();
			availCovs.GenerateCoverageList(-1, patient.PatientId, DateTime.Today);
			this.WriteLine( availCovs.ToString() );

			int index = availCovs.GetIndexOfFirstValidCoverageFromEligibility();
			AvailableCoverage avaCov = availCovs[index];
			
			avaCov.EnsurePatientCoverage(covSelContext);

			WriteLine(covSelContext.ToString());
		}

		private void butTestDRG_Click(object sender, System.EventArgs e)
		{
			Patient patient = new Patient();
			if (!patient.Load(2))
				return;

			Event eve = new Event();
			if (!eve.Load(patient, 22))
				return;

			//eve.LoadEventDiagnoses(false);
			//Debug.WriteLine(eve.EventDiagnoses.ToString(false, true));

			//DRGClass drg = new DRGClass(patient, eve);
			//drg.QueryDRG();
			//Debug.WriteLine(drg);

			/*
			ICD9CodeCollection icd9Codes = new ICD9CodeCollection();
			icd9Codes.SearchICD9Codes(200, "", "", "" , "D", null, false, 0);

			eve.LoadEventDiagnoses(false);
			for (int i = 0; i < icd9Codes.Count; i++)
			{
				ICD9Code c = icd9Codes[i];
				EventReferralDiagnose d = new EventReferralDiagnose(true);
				d.DiagnosisType = c.CodeType;
				d.DiagnosisCode = c.CodeValue;
				eve.EventDiagnoses.AddRecord(  d);

				eve.CalculateDRGData(patient);
			}*/

			eve.StartDate = new DateTime(2005, 10, 31);
			eve.EndDate = DateTime.MinValue;
			eve.LoadEventDiagnoses(false);
			eve.EventDiagnoses.Clear();
			eve.LoadEventProcedures(false);
			eve.EventProcedures.Clear();
			patient.DateOfBirth = new DateTime(1994, 5, 4);
			patient.Gender = "F";
			for (int i = 0; i < 1; i++)
			{
				WriteLine(String.Format("i = {0}", i ) );
				EventReferralDiagnose erd = null;
				EventReferralProcedure erp = null;

				erd = new EventReferralDiagnose();
				erd.Sequence = 10;
				erd.DiagnosisType = "ICD9";
				erd.DiagnosisCode = "486.";
				eve.EventDiagnoses.AddRecord(erd);

				erd = new EventReferralDiagnose();
				erd.Sequence = 20;
				erd.DiagnosisType = "ICD9";
				erd.DiagnosisCode = "714.0";
				eve.EventDiagnoses.AddRecord(erd);

				///

				erp = new EventReferralProcedure();
				erp.Sequence = 10;
				erp.ProcedureType = "ICD9";
				erp.ProcedureCode = "87.44";
				eve.EventProcedures.AddRecord(erp);

				erp = new EventReferralProcedure();
				erp.Sequence = 20;
				erp.ProcedureType = "ICD9";
				erp.ProcedureCode = "99.21";
				eve.EventProcedures.AddRecord(erp);

				erp = new EventReferralProcedure();
				erp.Sequence = 30;
				erp.ProcedureType = "ICD9";
				erp.ProcedureCode = "99.23";
				eve.EventProcedures.AddRecord(erp);

				eve.CalculateDRGData(patient);

				if (eve.DrgCalcEx != null)
					WriteLine(eve.DrgCalcEx.ToString());
				WriteLine(String.Format("DrgType: {0}", eve.DrgType ) );
				WriteLine(String.Format("DrgCode: {0}", eve.DrgCode ) );
				WriteLine(String.Format("DrgVersion: {0}", eve.DrgVersion ) );

				/*EventReferralProcedure erp = new EventReferralProcedure();
				erp.ProcedureType = "ICD9";
				erp.ProcedureCode = "75" + i.ToString() + ".1";
				eve.EventProcedures.AddRecord(erp);*/
			}

		}

		private void butLoadForMomBabyCodeRange_Click(object sender, System.EventArgs e)
		{
			Patient patient = new Patient();
			if (!patient.Load(2))
				return;

			Event eve = new Event();
			if (!eve.Load(patient, 22))
				return;

			WriteLine("IsMom:{0}", eve.IsMom );
			WriteLine("IsBaby:{1}", eve.IsBaby );
		}

		private void butTestAutoActivity_Click(object sender, System.EventArgs e)
		{
			AutoActivityManager.AutoActivityEvaluateEnabled = true;
			AutoActivityManager.AutoActivityGenerateEnabled = true;
			
			Patient patient = new Patient();
			if (!patient.Load(254))
				return;

			Event eve = new Event();
			if (!eve.Load(patient, 62))
				return;

			MatchingRuleCollection rules = new MatchingRuleCollection();
			rules.LoadMatchingRules( AutoActivityRuleType.ES1, 254, 0, 62, 0, 0, 0, 0, null, null);

			WriteLine(rules.ToString(false, true));

			// check if it realy worked
			

			//AutoActivityRuleCollection 
		}

		private void DumpAutoActivityContext(AutoActivityManager autoActivityManager)
		{
			if (autoActivityManager == null)
			{
				WriteLine("No auto-activity context was created");
				return;
			}

			foreach (string s in autoActivityManager.MessageLog)
				WriteLine(s);
		}

		private void butAutoActivityManager_Click(object sender, System.EventArgs e)
		{
			AutoActivityManager.AutoActivityEvaluateEnabled = true;
			AutoActivityManager.AutoActivityGenerateEnabled = true;

			Patient patient = new Patient();
			if (!patient.Load(254))
				return;

			Event eve = new Event();
			if (!eve.Load(patient, 62))
				return;

			patient.LoadPatientCoverages(false);
			eve.AutoActivity_EventInitialSave();
			DumpAutoActivityContext(eve.AutoActivityManager);
		}

		private void butTestEventAutoActivities_Click(object sender, System.EventArgs e)
		{
			AutoActivityManager.AutoActivityEvaluateEnabled = true;
			AutoActivityManager.AutoActivityGenerateEnabled = true;

			Patient patient = null;
			PatientCoverage patCov = null;

			// --------------------- TEST EVENT AUTO ACTIVITIES - PR1 - Problem Initial Save
			patient = new Patient();
			if (!patient.Load(254))
				return;
			patient.LoadPatientCoverages(false);
			patCov = patient.PatientCoverages[0];
			Problem problem = new Problem(patient);
			problem.ProblemDescription = "Auto-activity testing problem.";
			problem.Save(patCov);
			DumpAutoActivityContext(problem.AutoActivityManager);
			return;

			// --------------------- TEST EVENT AUTO ACTIVITIES - PT1 - Patient Initial Save
			patient = Patient.CreateBaby("test baby 1", "for auto-activity", "F");
			Subscriber subs = new Subscriber();
			if (!subs.Load(258072))
				return;
			patCov = new PatientCoverage(true);
			patCov.SORGID = 128;
			patCov.PlanID = 35;
			patCov.SetRelationship(patient, subs);
			patCov.RelationShipID = 1;
			patCov.LatestCoverageData.EffectiveDate = DateTime.Today;
			subs.Save(patient, patCov, true);
			DumpAutoActivityContext(patient.AutoActivityManager);

			
			patient = new Patient();
			if (!patient.Load(254))
				return;

			// --------------------- TEST EVENT AUTO ACTIVITIES - ES1, ER3, ER4
			Note note = new Note(patient, true);
			note.EventID = 62;
			note.NoteTypeID = 2;
			note.Save();
			DumpAutoActivityContext(note.AutoActivityManager);

			
			Referral refe = new Referral();
			if (!refe.Load(359))
				return;

			refe.LoadReferralDetails(false);
			refe.ReferralDetails[0].ReferralAuthorizationDecisionID = 2;
			refe.ReferralDetails[0].MarkDirty();
			refe.SaveReferralDetails();
			DumpAutoActivityContext(refe.AutoActivityManager);

			// --------------------- TEST EVENT AUTO ACTIVITIES - ES1, ER3, ER4

			Event eve = new Event();
			if (!eve.Load(patient, 62))
				return;

			// --------------------- TEST Activity AUTO ACTIVITIES - ED1 - Setting Event Decision Type
			eve.LoadClinicalReviewRequests(false);
			ClinicalReviewRequest req = new ClinicalReviewRequest(true);
			eve.ClinicalReviewRequests.Add(req);
			req.ReqUOMID = 5;
			req.ReqAmount = 100;
			req.LoadClinicalReviewDecisions(false);
			ClinicalReviewDecision dec = new ClinicalReviewDecision(req, true);
			dec.DecUOMID = 5;
			dec.ClinicalReviewDecisionID = 1;
			dec.ClinicalReviewDecisionTypeID = 1;
			req.ClinicalReviewDecisions.Add(dec);
			eve.SaveClinicalReviewRequests();
			DumpAutoActivityContext(eve.AutoActivityManager);

			// --------------------- TEST Activity AUTO ACTIVITIES - ER2 - Physician Review for Event - Initial save
			eve.LoadPRRequests(false);
			PRRequest phyRev = new PRRequest(true);
			phyRev.PhysicianReviewRequestReasonID = 1;
			eve.PRRequests.Add(phyRev);
			eve.SavePRRequests();
			DumpAutoActivityContext(eve.PRRequests.AutoActivityManager);

			// --------------------- TEST Activity AUTO ACTIVITIES - CD1
			
			eve.LoadEventDiagnoses(false);
			DiagnosticSelectCollection dxSel = eve.CreateDiagnosticSelectionCollection();
			dxSel.AddAsNewSelection(new ICD9Code("25.0", "D", "", ""), -1);
			eve.SyncDiagnosticCodes(dxSel);
			DumpAutoActivityContext(eve.AutoActivityManager);

			problem = eve.GetPrimaryProblem();

			// create new event and see ES1
			eve.MarkNew();
			eve.StatusCode = SystemStatus.OPEN;
			
			patient.LoadPatientCoverages(false);
			patCov = patient.PatientCoverages[0];
			eve.Save(patCov, problem);

			DumpAutoActivityContext(eve.AutoActivityManager);
			
			// close the event and see ER3, ER4

			eve.StatusCode = SystemStatus.CLOSED;
			eve.EndDate = DateTime.Today;
			eve.Save();

			DumpAutoActivityContext(eve.AutoActivityManager);

			// --------------------- TEST REFERRAL AUTO ACTIVITIES - RS1

			Referral referral = new Referral();
			if (!referral.Load(359))
				return;

			patCov = referral.PatientSubscriberLog.PatientCoverage;
			problem = referral.GetPrimaryProblem();

			// create new referral and see RS1
			referral.MarkNew();
			
			referral.Save(patCov, problem);

			DumpAutoActivityContext(referral.AutoActivityManager);

			// --------------------- TEST CMS AUTO ACTIVITIES - CM1

			CMS cms = new CMS();
			if (!cms.Load(221247))
				return;

			patCov = cms.PatientSubscriberLog.PatientCoverage;
			problem = cms.GetPrimaryProblem();

			// create new referral and see CM1
			cms.MarkNew();
			cms.Save(patCov, problem);

			
			DumpAutoActivityContext(cms.AutoActivityManager);


			// --------------------- TEST Activity AUTO ACTIVITIES - AC1
			
			Activity activity = new Activity();
			if (!activity.Load(91))		// activity with EventID
				return;

			activity.ActivityCompletionCode = ActivityCompletion.COMP;
			activity.Save();

			DumpAutoActivityContext(activity.AutoActivityManager);
		

		}

		private void btnCreatePatientWithProblems_Click(object sender, System.EventArgs e)
		{
			int numberOfPatients = 100000;
			// -- Get a List numberOfPatients firstname + gender + lastname from DB
			BaseData data = new BaseData();
			SqlConnection conn			= new SqlConnection(NSGlobal.ConnectionString);
			SqlConnection conn2			= new SqlConnection(NSGlobal.ConnectionString);
			SqlCommand    cmd			= new SqlCommand("SELECT TOP " + ((1000 < numberOfPatients) ? "100" : numberOfPatients.ToString()) + " FirstName, Gender FROM Subscriber where firstname is not null and gender is not null order by NewID()",conn);
			SqlCommand    cmd2			= new SqlCommand("SELECT TOP " + ((1000 < numberOfPatients) ? "100" : numberOfPatients.ToString()) + " LastName FROM Subscriber where lastname is not null order by newID()",conn2);
			SqlCommand    cmd3			= new SqlCommand("SELECT TOP " + ((100 < numberOfPatients) ? "100" : numberOfPatients.ToString()) + " OrganizationID FROM Organization INNER JOIN PlanSorg ON (Organization.OrganizationID = PlanSorg.SorgID) INNER JOIN PlanSorgLOG ON (PlanSorg.PlanSorgID = PlanSorgLog.PlanSorgID) WHERE OrganizationLevelID = 3 ORDER BY NewID()",conn2);
			SqlDataAdapter adap			= new SqlDataAdapter(cmd);
			SqlDataAdapter adap2		= new SqlDataAdapter(cmd2);
			SqlDataAdapter adap3		= new SqlDataAdapter(cmd3);
			conn.Open();
			conn2.Open();
			DataSet firstNames			= new DataSet();
			DataSet lastNames			= new DataSet();
			DataSet sorgs				= new DataSet();

			adap.Fill(firstNames);
			adap2.Fill(lastNames);
			adap3.Fill(sorgs);

			// if both Readers have values start creating subscribers.
			if (firstNames.Tables[0] != null && lastNames.Tables[0] != null)
			{
				// loop through the readers numberOfPatients times.
				for (int i=0; i < numberOfPatients && firstNames.Tables[0].Rows.Count == lastNames.Tables[0].Rows.Count; i++)
				{
					Subscriber subscriber = new Subscriber(true);
					subscriber.FirstName  = (string)firstNames.Tables[0].Rows[(i + DateTime.Now.Second + lastNames.Tables[0].Rows.Count) % firstNames.Tables[0].Rows.Count]["FirstName"]; // set FirstName, LastName, Gender
					subscriber.LastName	  = (string)lastNames.Tables[0].Rows[(i - DateTime.Now.Second  + lastNames.Tables[0].Rows.Count)  % lastNames.Tables[0].Rows.Count]["LastName"];
					subscriber.Gender	  = (string)firstNames.Tables[0].Rows[i % firstNames.Tables[0].Rows.Count]["Gender"];
					subscriber.CreatedBy  = 1;
					
					// --- Create Patient according to current counter mod 5. If 1 then self.
					Patient patient				= null;
					if ((i % 5) == 0)
						patient = new Patient(subscriber.FirstName, subscriber.LastName, subscriber.Gender);
					else
						patient = new Patient((string)firstNames.Tables[0].Rows[i % firstNames.Tables[0].Rows.Count]["FirstName"],(string)lastNames.Tables[0].Rows[i % lastNames.Tables[0].Rows.Count]["LastName"],(string)firstNames.Tables[0].Rows[i % firstNames.Tables[0].Rows.Count]["Gender"]);

					// --- Add Coverage ---
					patient.LoadPatientCoverages(false);
					PatientCoverage   coverage	= new PatientCoverage(patient, subscriber);
					coverage.LatestCoverageData.EffectiveDate = DateTime.Now;
					coverage.LatestCoverageData.AsOfDate	  = DateTime.Now;
					coverage.SORGID				= (int)sorgs.Tables[0].Rows[i % sorgs.Tables[0].Rows.Count][0];
					coverage.SORG.LoadPlanSORGs(true);
					coverage.PlanID				= coverage.SORG.PlanSORGs[i % coverage.SORG.PlanSORGs.Count].PlanId;				
					coverage.RelationShipID     = (i % 5) + 1;
					patient.PatientCoverages.AddRecord(coverage);									
					patient.CreatedBy			= (i % 3) + 1;

					// --- Try saving the record ---
					try
					{
						subscriber.Save(patient, coverage, true);			// -- save subscriber.
						this.WriteLine("Patient: " + patient.FirstName + " " + patient.LastName + ", " + patient.PatientId.ToString() + " saved.");
					}
					catch (Exception ex)
					{
						this.WriteLine("An error occurred saving subscriber: " + ex.ToString());
					}
					
				}
				this.WriteLine("Total of: " + numberOfPatients.ToString() + " patients saved.");  // -- write the total result
			}
			// -- Clean up by closing connections and disposing them.
			conn.Close();
			conn.Dispose(); 
			conn2.Close();
			conn2.Dispose();

		}

		private void TestPatient_Closed(object sender, System.EventArgs e)
		{
			
			Grouper.TerminateGrouper();
		}

		private void butInitDRG_Click(object sender, System.EventArgs e)
		{
			GrouperHIPAA grp = Grouper.DrgGrouper;
			WriteLine("Grouper initialized");
		}

		long mem0 = 0;
		long mem = 0;

		private void MemorySnapshot()
		{
			GC.Collect();
			mem = GC.GetTotalMemory(true);
			MemoryDump("Memory", mem0, mem);
			mem0 = mem;
		}

		private void MemoryDump(string title, long mem0, long mem)
		{
			WriteLine( String.Format(title + ": {0}    Delta={1}", mem, mem - mem0) );
		}

		private void butMemUsageTest_Click(object sender, System.EventArgs e)
		{
			GC.Collect();
			mem0 = GC.GetTotalMemory(true);
			
			MemorySnapshot();
			long memBeforePatient = mem;

			WriteLine("Load Patient");

			Patient patient = new Patient();
			if (!patient.Load(2))
				return;

			MemorySnapshot();

			WriteLine("Load Patient Medications");
			patient.LoadPatientMedications(false);

			WriteLine("Patient Medications count=" + patient.PatientMedications.Count);

			MemorySnapshot();

			MemoryDump("Memory dump since patient was loaded", memBeforePatient, mem);

			patient.PatientMedications = null;

			MemorySnapshot();

			long memBeforeEvent = mem;

			WriteLine("Load event");

			Event eve = new Event();
			if (!eve.Load(patient, 22))
				return;

			MemorySnapshot();

			WriteLine("Load Event Referral Diganoses");
			eve.LoadEventReferralDiagnoses(false);
			WriteLine("Event Referral Diganoses count=" + eve.EventReferralDiagnoses.Count);

			MemorySnapshot();

			WriteLine("Load Event Referral Procedures");
			eve.LoadEventReferralProcedures(false);
			WriteLine("Event Referral Procedures count=" + eve.EventReferralProcedures.Count);

			MemorySnapshot();

			WriteLine("Load Clinical Requests");
			eve.LoadClinicalReviewRequests(false);
			WriteLine("Event Clinical Requests count=" + eve.ClinicalReviewRequests.Count);

			MemorySnapshot();

			WriteLine("Load All Clinical Decisions for all Requests");
			foreach (ClinicalReviewRequest req in eve.ClinicalReviewRequests)
			{
				req.LoadClinicalReviewDecisions(false);
				MemorySnapshot();
			}

			MemoryDump("Memory dump since event was loaded", memBeforeEvent, mem);

			WriteLine("Load CMS");

			CMS cms = new CMS();
			if (!cms.Load(1))
				return;

			MemorySnapshot();

			WriteLine("Load Referral");

			Referral refe = new Referral();
			if (!refe.Load(7016))
				return;

			MemorySnapshot();

			WriteLine("Load patient coverages");
			
			patient.LoadPatientCoverages(false);

			WriteLine("Patient coverage count=" + patient.PatientCoverages.Count);
			
			MemorySnapshot();

			/*WriteLine("Load logics");

			LogicCollection logicCol = new LogicCollection();
			logicCol.SearchLogics(-1, 0, new Logic());
	
			WriteLine("Logic count=" + logicCol.Count);
			MemorySnapshot();*/

			WriteLine("Load questions");

			QuestionCollection qcol = new QuestionCollection();
			qcol.LoadQuestionsByContentOwnerIDAssessmentGUID(-1, 1, "FFFD0638AA3A498E9A4A5663461B698D");
	
			WriteLine("Question count=" + qcol.Count);
			MemorySnapshot();

			//AnswerCollection answers = new AnswerCollection();

		}
	}
}

