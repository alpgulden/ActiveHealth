using System;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using NetsoftUSA.DataLayer;
using ActiveAdvice.DataLayer;

namespace TestDataLayer
{
	public class TestPlanComponents : TestDataLayer.BaseTestForm
	{
		private System.Windows.Forms.Button butTestSpecialProcedures;
		private System.Windows.Forms.Button butSpecProcCol;
		private System.Windows.Forms.Button butCreateBenefitSvcs;
		private System.Windows.Forms.Button butCreateInsurancePayors;
		private System.Windows.Forms.Button butCreateManagementSvcs;
		private System.Windows.Forms.Button butCreatePlanHEDISTypes;
		private System.Windows.Forms.Button butPlanTypes;
		private System.Windows.Forms.Button butPlanIncentives;
		private System.Windows.Forms.Button butPlanNoteTypes;
		private System.Windows.Forms.Button butTriggerLists;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button butCreateBenefitServiceTypes;
		private System.Windows.Forms.Button butCreateCoveredTypes;
		private System.Windows.Forms.Button butPlanPayorHedisTypes;
		private System.ComponentModel.IContainer components = null;

		public TestPlanComponents()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.butTestSpecialProcedures = new System.Windows.Forms.Button();
			this.butSpecProcCol = new System.Windows.Forms.Button();
			this.butCreateBenefitSvcs = new System.Windows.Forms.Button();
			this.butCreateInsurancePayors = new System.Windows.Forms.Button();
			this.butCreateManagementSvcs = new System.Windows.Forms.Button();
			this.butCreatePlanHEDISTypes = new System.Windows.Forms.Button();
			this.butPlanTypes = new System.Windows.Forms.Button();
			this.butPlanIncentives = new System.Windows.Forms.Button();
			this.butPlanNoteTypes = new System.Windows.Forms.Button();
			this.butTriggerLists = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.butCreateBenefitServiceTypes = new System.Windows.Forms.Button();
			this.butCreateCoveredTypes = new System.Windows.Forms.Button();
			this.butPlanPayorHedisTypes = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// butTestSpecialProcedures
			// 
			this.butTestSpecialProcedures.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butTestSpecialProcedures.Location = new System.Drawing.Point(8, 288);
			this.butTestSpecialProcedures.Name = "butTestSpecialProcedures";
			this.butTestSpecialProcedures.Size = new System.Drawing.Size(88, 32);
			this.butTestSpecialProcedures.TabIndex = 1;
			this.butTestSpecialProcedures.Text = "Create Special Procedures";
			this.butTestSpecialProcedures.Click += new System.EventHandler(this.butTestSpecialProcedures_Click);
			// 
			// butSpecProcCol
			// 
			this.butSpecProcCol.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butSpecProcCol.Location = new System.Drawing.Point(488, 296);
			this.butSpecProcCol.Name = "butSpecProcCol";
			this.butSpecProcCol.Size = new System.Drawing.Size(176, 23);
			this.butSpecProcCol.TabIndex = 2;
			this.butSpecProcCol.Text = "Load Effective Records";
			this.butSpecProcCol.Click += new System.EventHandler(this.butSpecProcCol_Click);
			// 
			// butCreateBenefitSvcs
			// 
			this.butCreateBenefitSvcs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butCreateBenefitSvcs.Location = new System.Drawing.Point(96, 288);
			this.butCreateBenefitSvcs.Name = "butCreateBenefitSvcs";
			this.butCreateBenefitSvcs.Size = new System.Drawing.Size(88, 32);
			this.butCreateBenefitSvcs.TabIndex = 3;
			this.butCreateBenefitSvcs.Text = "Create Benefit Services";
			this.butCreateBenefitSvcs.Click += new System.EventHandler(this.butCreateBenefitSvcs_Click);
			// 
			// butCreateInsurancePayors
			// 
			this.butCreateInsurancePayors.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butCreateInsurancePayors.Location = new System.Drawing.Point(184, 288);
			this.butCreateInsurancePayors.Name = "butCreateInsurancePayors";
			this.butCreateInsurancePayors.Size = new System.Drawing.Size(104, 32);
			this.butCreateInsurancePayors.TabIndex = 4;
			this.butCreateInsurancePayors.Text = "Create Insurance Payors";
			this.butCreateInsurancePayors.Click += new System.EventHandler(this.butCreateInsurancePayors_Click);
			// 
			// butCreateManagementSvcs
			// 
			this.butCreateManagementSvcs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butCreateManagementSvcs.Location = new System.Drawing.Point(296, 288);
			this.butCreateManagementSvcs.Name = "butCreateManagementSvcs";
			this.butCreateManagementSvcs.Size = new System.Drawing.Size(80, 32);
			this.butCreateManagementSvcs.TabIndex = 5;
			this.butCreateManagementSvcs.Text = "Create Mgmt Svcs";
			this.butCreateManagementSvcs.Click += new System.EventHandler(this.butCreateManagementSvcs_Click);
			// 
			// butCreatePlanHEDISTypes
			// 
			this.butCreatePlanHEDISTypes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butCreatePlanHEDISTypes.Location = new System.Drawing.Point(96, 256);
			this.butCreatePlanHEDISTypes.Name = "butCreatePlanHEDISTypes";
			this.butCreatePlanHEDISTypes.Size = new System.Drawing.Size(88, 32);
			this.butCreatePlanHEDISTypes.TabIndex = 7;
			this.butCreatePlanHEDISTypes.Text = "Create Plan HEDIS Types";
			this.butCreatePlanHEDISTypes.Click += new System.EventHandler(this.butCreatePlanHEDISTypes_Click);
			// 
			// butPlanTypes
			// 
			this.butPlanTypes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butPlanTypes.Location = new System.Drawing.Point(8, 256);
			this.butPlanTypes.Name = "butPlanTypes";
			this.butPlanTypes.Size = new System.Drawing.Size(88, 32);
			this.butPlanTypes.TabIndex = 8;
			this.butPlanTypes.Text = "Create Plan Types";
			this.butPlanTypes.Click += new System.EventHandler(this.butPlanTypes_Click);
			// 
			// butPlanIncentives
			// 
			this.butPlanIncentives.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butPlanIncentives.Location = new System.Drawing.Point(8, 224);
			this.butPlanIncentives.Name = "butPlanIncentives";
			this.butPlanIncentives.Size = new System.Drawing.Size(88, 32);
			this.butPlanIncentives.TabIndex = 9;
			this.butPlanIncentives.Text = "Create Plan Incentives";
			this.butPlanIncentives.Click += new System.EventHandler(this.butPlanIncentives_Click);
			// 
			// butPlanNoteTypes
			// 
			this.butPlanNoteTypes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butPlanNoteTypes.Location = new System.Drawing.Point(96, 224);
			this.butPlanNoteTypes.Name = "butPlanNoteTypes";
			this.butPlanNoteTypes.Size = new System.Drawing.Size(88, 32);
			this.butPlanNoteTypes.TabIndex = 10;
			this.butPlanNoteTypes.Text = "Create Plan Note Types";
			this.butPlanNoteTypes.Click += new System.EventHandler(this.butPlanNoteTypes_Click);
			// 
			// butTriggerLists
			// 
			this.butTriggerLists.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butTriggerLists.Location = new System.Drawing.Point(296, 256);
			this.butTriggerLists.Name = "butTriggerLists";
			this.butTriggerLists.Size = new System.Drawing.Size(104, 32);
			this.butTriggerLists.TabIndex = 11;
			this.butTriggerLists.Text = "Create Trigger Lists";
			this.butTriggerLists.Click += new System.EventHandler(this.butTriggerLists_Click);
			// 
			// button1
			// 
			this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.button1.Location = new System.Drawing.Point(184, 224);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(104, 32);
			this.button1.TabIndex = 12;
			this.button1.Text = "Create Plan Unit of Measures";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// butCreateBenefitServiceTypes
			// 
			this.butCreateBenefitServiceTypes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butCreateBenefitServiceTypes.Location = new System.Drawing.Point(296, 224);
			this.butCreateBenefitServiceTypes.Name = "butCreateBenefitServiceTypes";
			this.butCreateBenefitServiceTypes.Size = new System.Drawing.Size(88, 32);
			this.butCreateBenefitServiceTypes.TabIndex = 13;
			this.butCreateBenefitServiceTypes.Text = "Create Benefit Service Types";
			this.butCreateBenefitServiceTypes.Click += new System.EventHandler(this.butCreateBenefitServiceTypes_Click);
			// 
			// butCreateCoveredTypes
			// 
			this.butCreateCoveredTypes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butCreateCoveredTypes.Location = new System.Drawing.Point(384, 224);
			this.butCreateCoveredTypes.Name = "butCreateCoveredTypes";
			this.butCreateCoveredTypes.Size = new System.Drawing.Size(88, 32);
			this.butCreateCoveredTypes.TabIndex = 14;
			this.butCreateCoveredTypes.Text = "Create Covered Types";
			this.butCreateCoveredTypes.Click += new System.EventHandler(this.butCreateCoveredTypes_Click);
			// 
			// butPlanPayorHedisTypes
			// 
			this.butPlanPayorHedisTypes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butPlanPayorHedisTypes.Location = new System.Drawing.Point(472, 224);
			this.butPlanPayorHedisTypes.Name = "butPlanPayorHedisTypes";
			this.butPlanPayorHedisTypes.Size = new System.Drawing.Size(112, 32);
			this.butPlanPayorHedisTypes.TabIndex = 15;
			this.butPlanPayorHedisTypes.Text = "Create Plan Payor HEDIS Types";
			this.butPlanPayorHedisTypes.Click += new System.EventHandler(this.butPlanPayorHedisTypes_Click);
			// 
			// TestPlanComponents
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 321);
			this.Controls.Add(this.butPlanPayorHedisTypes);
			this.Controls.Add(this.butCreateCoveredTypes);
			this.Controls.Add(this.butCreateBenefitServiceTypes);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.butTriggerLists);
			this.Controls.Add(this.butPlanNoteTypes);
			this.Controls.Add(this.butPlanIncentives);
			this.Controls.Add(this.butPlanTypes);
			this.Controls.Add(this.butCreatePlanHEDISTypes);
			this.Controls.Add(this.butCreateManagementSvcs);
			this.Controls.Add(this.butCreateInsurancePayors);
			this.Controls.Add(this.butCreateBenefitSvcs);
			this.Controls.Add(this.butSpecProcCol);
			this.Controls.Add(this.butTestSpecialProcedures);
			this.Name = "TestPlanComponents";
			this.Text = "DataLayer Test - Plan Components";
			this.Load += new System.EventHandler(this.TestPlanComponents_Load);
			this.Controls.SetChildIndex(this.butTestSpecialProcedures, 0);
			this.Controls.SetChildIndex(this.butSpecProcCol, 0);
			this.Controls.SetChildIndex(this.butCreateBenefitSvcs, 0);
			this.Controls.SetChildIndex(this.butCreateInsurancePayors, 0);
			this.Controls.SetChildIndex(this.butCreateManagementSvcs, 0);
			this.Controls.SetChildIndex(this.butCreatePlanHEDISTypes, 0);
			this.Controls.SetChildIndex(this.butPlanTypes, 0);
			this.Controls.SetChildIndex(this.butPlanIncentives, 0);
			this.Controls.SetChildIndex(this.butPlanNoteTypes, 0);
			this.Controls.SetChildIndex(this.butTriggerLists, 0);
			this.Controls.SetChildIndex(this.button1, 0);
			this.Controls.SetChildIndex(this.butCreateBenefitServiceTypes, 0);
			this.Controls.SetChildIndex(this.butCreateCoveredTypes, 0);
			this.Controls.SetChildIndex(this.butPlanPayorHedisTypes, 0);
			this.ResumeLayout(false);

		}
		#endregion

		private void TestPlanComponents_Load(object sender, System.EventArgs e)
		{
		
		}

		private void butTestSpecialProcedures_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				SpecialProcedure obj = new SpecialProcedure(i, "SPEC-PROC" + i.ToString(), "SPEC-PROC" + i.ToString());  // Use appropriate constructor
				obj.CreatedBy = 2;
				// Do other initializations on the object;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.SpecialProcedureId))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
					
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}	

			WriteLine("select * from SpecialProcedures");
		}

		private void butSpecProcCol_Click(object sender, System.EventArgs e)
		{
			SpecialProcedureCollection specSvcs = new SpecialProcedureCollection();
			specSvcs.LoadEffectiveSpecialProceduresForDate(-1, new DateTime(2004, 11, 20) );
			WriteLine(specSvcs.ToString(true, true));
			specSvcs.LoadEffectiveSpecialProceduresForDate(-1, DateTime.Today);
			WriteLine(specSvcs.ToString(true, true));

			BenefitServiceCollection beneSvcs = new BenefitServiceCollection();
			beneSvcs.LoadEffectiveBenefitServicesForDate(-1, new DateTime(2004, 11, 20) );
			WriteLine(beneSvcs.ToString(true, true));
			beneSvcs.LoadEffectiveBenefitServicesForDate(-1, DateTime.Today);
			WriteLine(beneSvcs.ToString(true, true));

			InsurancePayorCollection insPayors = new InsurancePayorCollection();
			insPayors.LoadEffectiveInsurancePayors(-1, new DateTime(2004, 11, 20) );
			WriteLine(insPayors.ToString(true, true));
			insPayors.LoadEffectiveInsurancePayors(-1, DateTime.Today);
			WriteLine(insPayors.ToString(true, true));
		}

		private void butCreateBenefitSvcs_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				BenefitService obj = new BenefitService(i, "BENE-SVC" + i.ToString(), "BENE-SVC" + i.ToString());  // Use appropriate constructor
				obj.CreatedBy = 2;
				// Do other initializations on the object;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.BenefitServiceId))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
					
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}

			WriteLine("select * from BenefitServices");
		}

		private void butCreateInsurancePayors_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				InsurancePayor obj = new InsurancePayor("INS-PAYOR" + i.ToString(), "INS-PAYOR" + i.ToString());  // Use appropriate constructor
				//obj.CreatedBy = 2;
				// Do other initializations on the object;
				obj.Address.Country = "USA";
				obj.Address.Line1 = "address " + i;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.InsurancePayorId))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
					
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}

			WriteLine("select * from InsurancePayors as a left join Addresses as b on a.AddressID = b.AddressID");
		}


		private void butCreateManagementSvcs_Click(object sender, System.EventArgs e)
		{
			for (int i = 0; i < 10; i++)
			{
				ManagementService obj = new ManagementService(true); //"INS-PAYOR" + i.ToString());  // Use appropriate constructor
				obj.Note = "this is a test note " + i.ToString();
				obj.CreatedBy = 2;
				obj.LoadManagementServiceItems(false);
				obj.ManagementServiceItems.Add(new ManagementServiceItem(1, 1, 1, 1));
				obj.ManagementServiceItems.Add(new ManagementServiceItem(2, 2, 2, 2));
				
				// Do other initializations on the object;
				obj.Save();
				obj.SaveManagementServiceItems();
				Debug.Assert(obj.Load(obj.ManagementServiceId), "Load failed for ManagementService PK="+obj.PKString);
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}	
		}

		private void butCreatePlanHEDISTypes_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				PlanHEDISType obj = new PlanHEDISType(i, "HEDIS" + i.ToString(), "PlanHEDISType " + i.ToString());  // Use appropriate constructor
				//obj.CreatedBy = 2;
				// Do other initializations on the object;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.HEDISTypeId))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
					
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}

			WriteLine("select * from PlanHedisTypes");
		}

		private void butPlanTypes_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				PlanType obj = new PlanType(i, "PlanType " + i.ToString());  // Use appropriate constructor
				//obj.CreatedBy = 2;
				// Do other initializations on the object;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.PlanTypeId))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
					
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}
			WriteLine("select * from PlanTypes");
		}

		private void butPlanIncentives_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				PlanMaternichekIncentive obj = new PlanMaternichekIncentive(i, "PlanMaternicheckIncentive " + i.ToString());  // Use appropriate constructor
				//obj.CreatedBy = 2;
				// Do other initializations on the object;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.IncentiveId))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
					
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}
			WriteLine("select * from PlanIncentives");
		}

		private void butPlanNoteTypes_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				PlanNoteType obj = new PlanNoteType(i, "PNOTEYP" + i.ToString(),  "PlanNoteType " + i.ToString());  // Use appropriate constructor
				//obj.CreatedBy = 2;
				// Do other initializations on the object;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.PlanNoteTypeId))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
					
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}
			WriteLine("select * from PlanNoteTypes");
		}

		private void butTriggerLists_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				TriggerList obj = new TriggerList ("TGRL" + i.ToString(),  "TriggerList " + i.ToString());  // Use appropriate constructor
				obj.CreatedBy = 2;
				// Do other initializations on the object;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.TriggerListId))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
					
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}
			WriteLine("select * from TriggerLists");
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				PlanUnitOfMeasure obj = new PlanUnitOfMeasure(i, "PL-UOM" + i.ToString(),  "PlanUnitOfMeasure " + i.ToString());  // Use appropriate constructor
				//obj.CreatedBy = 2;
				// Do other initializations on the object;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.UnitOfMeasureId))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
					
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}
			WriteLine("select * from PlanUnitOfMeasures");
		}

		private void butCreateBenefitServiceTypes_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				BenefitServiceType obj = new BenefitServiceType(i, "BESVCTY" + i.ToString(),  "BenefitserviceType " + i.ToString());  // Use appropriate constructor
				//obj.CreatedBy = 2;
				// Do other initializations on the object;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.BenefitServiceTypeId))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
					
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}
			WriteLine("select * from BenefitserviceTypes");
		}

		private void butCreateCoveredTypes_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				CoveredType obj = new CoveredType(i, "COVTYP" + i.ToString(),  "CoveredType " + i.ToString());  // Use appropriate constructor
				//obj.CreatedBy = 2;
				// Do other initializations on the object;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.CoveredTypeID))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
					
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}
			WriteLine("select * from CoveredTypes");
		}

		private void butPlanPayorHedisTypes_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				PlanPayorHEDISType obj = new PlanPayorHEDISType("PHEDIS" + i.ToString(), "PlanPayorHEDISType " + i.ToString());  // Use appropriate constructor
				//obj.CreatedBy = 2;
				// Do other initializations on the object;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.HEDISTypeId))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
					
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}

			WriteLine("select * from PlanPayorHedisTypes");		
		}

	}
}

