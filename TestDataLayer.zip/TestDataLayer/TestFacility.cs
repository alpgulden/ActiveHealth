using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using ActiveAdvice.DataLayer;

namespace TestDataLayer
{
	public class TestFacility : TestDataLayer.BaseTestForm
	{
		private System.Windows.Forms.Button btnAdd10F;
		private System.Windows.Forms.TextBox txtFacID;
		private System.Windows.Forms.Button btnAddFacLocSType;
		private System.Windows.Forms.Button btnAddFacility;
		private System.ComponentModel.IContainer components = null;

		public TestFacility()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnAdd10F = new System.Windows.Forms.Button();
			this.txtFacID = new System.Windows.Forms.TextBox();
			this.btnAddFacLocSType = new System.Windows.Forms.Button();
			this.btnAddFacility = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnAdd10F
			// 
			this.btnAdd10F.Location = new System.Drawing.Point(8, 296);
			this.btnAdd10F.Name = "btnAdd10F";
			this.btnAdd10F.Size = new System.Drawing.Size(88, 23);
			this.btnAdd10F.TabIndex = 1;
			this.btnAdd10F.Text = "Add 10FType";
			this.btnAdd10F.Click += new System.EventHandler(this.butTest1_Click);
			// 
			// txtFacID
			// 
			this.txtFacID.Location = new System.Drawing.Point(624, 296);
			this.txtFacID.Name = "txtFacID";
			this.txtFacID.Size = new System.Drawing.Size(40, 20);
			this.txtFacID.TabIndex = 3;
			this.txtFacID.Text = "1";
			// 
			// btnAddFacLocSType
			// 
			this.btnAddFacLocSType.Location = new System.Drawing.Point(104, 296);
			this.btnAddFacLocSType.Name = "btnAddFacLocSType";
			this.btnAddFacLocSType.Size = new System.Drawing.Size(120, 23);
			this.btnAddFacLocSType.TabIndex = 4;
			this.btnAddFacLocSType.Text = "ADD FacLocSType";
			this.btnAddFacLocSType.Click += new System.EventHandler(this.btnAddFacLocSType_Click);
			// 
			// btnAddFacility
			// 
			this.btnAddFacility.Location = new System.Drawing.Point(232, 296);
			this.btnAddFacility.Name = "btnAddFacility";
			this.btnAddFacility.Size = new System.Drawing.Size(96, 23);
			this.btnAddFacility.TabIndex = 5;
			this.btnAddFacility.Text = "Add Facility";
			this.btnAddFacility.Click += new System.EventHandler(this.btnAddFacility_Click);
			// 
			// TestFacility
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 321);
			this.Controls.Add(this.btnAddFacility);
			this.Controls.Add(this.btnAddFacLocSType);
			this.Controls.Add(this.txtFacID);
			this.Controls.Add(this.btnAdd10F);
			this.Name = "TestFacility";
			this.Load += new System.EventHandler(this.TestModuleX_Load);
			this.Controls.SetChildIndex(this.btnAdd10F, 0);
			this.Controls.SetChildIndex(this.txtFacID, 0);
			this.Controls.SetChildIndex(this.btnAddFacLocSType, 0);
			this.Controls.SetChildIndex(this.btnAddFacility, 0);
			this.ResumeLayout(false);

		}
		#endregion

		private void butTest1_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 10; i++)
			{
				FacilityFocusType ftype = new FacilityFocusType();
				
				ftype.New();
				ftype.Code					= "FFOC" + i.ToString();
				ftype.Description			= "Description for facility focus type #: " + i.ToString();
				ftype.Notepad				= "Note for Facility focus type #:" + i.ToString();
				ftype.Save();
				WriteLine("Facility focus Type# : " + i.ToString() + " has been inserted into DB.");
			}

		}



		private void TestModuleX_Load(object sender, System.EventArgs e)
		{
			
		}

		private void btnAddNetwork_Click(object sender, System.EventArgs e)
		{


			for (int i=1; i < 10; i++)
			{
				Network network = null;
				try
				{
					Address addrNew			= new Address();
					addrNew.New();
					
					addrNew.City			= "Hicksville";
					addrNew.County			= "NASSAU";
					addrNew.Country			= "U.S.";
					addrNew.DeliveryMethod	= Address.EnumDeliveryMethod.Email;
					addrNew.Line1			= "46 East John St " + i.ToString();
					addrNew.PhoneNumber1	= "5166723540";
					addrNew.PhoneExt1		= "12";
					addrNew.State			= "NY";
					addrNew.Save();
					network = new Network();
					network.New();
					network.Name			= "Test Network #" + i.ToString();
					network.New();
					network.CreatedBy		= 1;
					network.CreateTime		= DateTime.Now;
					network.AddressID		= addrNew.AddressID;
					network.AlternateID		= "ALT123123" + i.ToString();
					network.EffectiveDate	= DateTime.Now.AddDays(i);
					network.Email			= "testnetwork" + i.ToString() + "@netsoft-usa.com";
					network.Note			= "Note for Test Network #" + i.ToString();
					network.TypeID			= (i % 5) + 1;
					network.Save();
				}
				catch (Exception ex)
				{
					MessageBox.Show("An error occurred while saving Network: " + ex.Message);
					return;
				}
				WriteLine("Network saved; network ID #" + network.NetworkID.ToString());
			}

			
		}

		private void btnAddFacLocSType_Click(object sender, System.EventArgs e)
		{
			for (int i=0; i < 5; i++)
			{
				FacilityLocationServiceType fstype = new FacilityLocationServiceType();
				fstype.New();
				fstype.Active		= true;
				fstype.Notepad			= "Test Fac Loc Service Type #" + i.ToString();
				fstype.Description		= "Service Desc #" + i.ToString();
				fstype.Code	= "SCODE#" + i.ToString();
				WriteLine("Facility Location Service Type ID #" + i.ToString() + " saved to DB");
				fstype.Save();
			}
		}

		private void btnAddFacility_Click(object sender, System.EventArgs e)
		{
		
		}
	}
}

