using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using ActiveAdvice.DataLayer;


namespace TestDataLayer
{
	public class TestCMS : TestDataLayer.BaseTestForm
	{
		private System.Windows.Forms.Button MCheck;
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Button TestDate;

		private Maternichek mc;

		public TestCMS()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.MCheck = new System.Windows.Forms.Button();
			this.TestDate = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// MCheck
			// 
			this.MCheck.Location = new System.Drawing.Point(16, 256);
			this.MCheck.Name = "MCheck";
			this.MCheck.Size = new System.Drawing.Size(112, 32);
			this.MCheck.TabIndex = 1;
			this.MCheck.Text = "EDC set first";
			this.MCheck.Click += new System.EventHandler(this.MCheck_Click);
			// 
			// TestDate
			// 
			this.TestDate.Location = new System.Drawing.Point(16, 192);
			this.TestDate.Name = "TestDate";
			this.TestDate.Size = new System.Drawing.Size(75, 32);
			this.TestDate.TabIndex = 2;
			this.TestDate.Text = "LMP set first";
			this.TestDate.Click += new System.EventHandler(this.TestDate_Click);
			// 
			// TestCMS
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 318);
			this.Controls.Add(this.TestDate);
			this.Controls.Add(this.MCheck);
			this.Name = "TestCMS";
			this.Load += new System.EventHandler(this.TestCMS_Load);
			this.Controls.SetChildIndex(this.MCheck, 0);
			this.Controls.SetChildIndex(this.TestDate, 0);
			this.ResumeLayout(false);

		}
		#endregion


		private void TestCMS_Load(object sender, System.EventArgs e)
		{
			
		}

		private void MCheck_Click(object sender, System.EventArgs e)
		{
			mc = new Maternichek(true);
			mc.EDCdate = DateTime.Now;
			System.Diagnostics.Debug.WriteLine("EDC is Set first");
			DisplayData();
		}

		private void TestDate_Click(object sender, System.EventArgs e)
		{
			mc = new Maternichek(true);
			mc.LMPdate = DateTime.Now;
			System.Diagnostics.Debug.WriteLine("LMP is Set first");
			DisplayData();
		}

		private void DisplayData()
		{	
			mc.CMSId = 10;

			//System.Diagnostics.Debug.WriteLine("hello");
			System.Diagnostics.Debug.WriteLine("LMP Date " + mc.LMPdate.ToShortDateString());
			System.Diagnostics.Debug.WriteLine("EDC Date  " + mc.EDCdate.ToShortDateString());
			System.Diagnostics.Debug.WriteLine("Gestation Date " + mc.GestationAge.ToString());
			System.Diagnostics.Debug.WriteLine("Delivery Date " + mc.DeliveryDate.ToShortDateString());
			//mc.Save();
			
		}
		
	}
}

