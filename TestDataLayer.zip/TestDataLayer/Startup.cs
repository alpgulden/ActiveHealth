using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;
using ActiveAdvice.DataLayer;


namespace TestDataLayer
{
	/// <summary>
	/// Summary description for Startup.
	/// </summary>
	public class Startup
	{
		public Startup()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			AASecurityHelper.GetUserId = 1;
			Application.Run(new BaseTestForm());
		}
	}
}
