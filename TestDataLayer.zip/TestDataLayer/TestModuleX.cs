using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace TestDataLayer
{
	public class NetworkTest : TestDataLayer.BaseTestForm
	{
		private System.Windows.Forms.Button AddNetworkType;
		private System.ComponentModel.IContainer components = null;

		public NetworkTest()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.AddNetworkType = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// AddNetworkType
			// 
			this.AddNetworkType.Location = new System.Drawing.Point(16, 296);
			this.AddNetworkType.Name = "AddNetworkType";
			this.AddNetworkType.Size = new System.Drawing.Size(88, 23);
			this.AddNetworkType.TabIndex = 1;
			this.AddNetworkType.Text = "Add 10 NType";
			this.AddNetworkType.Click += new System.EventHandler(this.butTest1_Click);
			// 
			// NetworkTest
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 321);
			this.Controls.Add(this.AddNetworkType);
			this.Name = "NetworkTest";
			this.Controls.SetChildIndex(this.AddNetworkType, 0);
			this.ResumeLayout(false);

		}
		#endregion

		private void butTest1_Click(object sender, System.EventArgs e)
		{
			WriteLine("hi");

			/*ProviderFocusType focusType = new  ProviderFocusType();
			focusType.New();
			focusType.Note		= "TEST FocusType";
			focusType.Inactive	= false;
			focusType.Focus     = "Test Focus";
			focusType.FocusCode	= "TEST";
			focusType.Save();*/

			//WriteLine(focusType);
			//Country.TestCRUDOperations();
			return;

		}
	}
}

