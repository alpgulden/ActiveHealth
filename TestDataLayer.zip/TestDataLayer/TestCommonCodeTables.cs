using System;
using System.Diagnostics;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using NetsoftUSA.DataLayer;
using ActiveAdvice.DataLayer;

namespace TestDataLayer
{
	public class TestCommonCodeTables : TestDataLayer.BaseTestForm
	{
		private System.Windows.Forms.Button butManagementServiceTypes;
		private System.Windows.Forms.Button butBaseUnitOfMeasures;
		private System.Windows.Forms.Button butManagementServicesRateTypes;
		private System.Windows.Forms.Button butConversionUnitOfMeasure;
		private System.ComponentModel.IContainer components = null;

		public TestCommonCodeTables()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.butManagementServiceTypes = new System.Windows.Forms.Button();
			this.butBaseUnitOfMeasures = new System.Windows.Forms.Button();
			this.butManagementServicesRateTypes = new System.Windows.Forms.Button();
			this.butConversionUnitOfMeasure = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// butManagementServiceTypes
			// 
			this.butManagementServiceTypes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butManagementServiceTypes.Location = new System.Drawing.Point(8, 288);
			this.butManagementServiceTypes.Name = "butManagementServiceTypes";
			this.butManagementServiceTypes.Size = new System.Drawing.Size(88, 32);
			this.butManagementServiceTypes.TabIndex = 1;
			this.butManagementServiceTypes.Text = "ManagementServiceTypes";
			this.butManagementServiceTypes.Click += new System.EventHandler(this.butManagementServiceTypes_Click);
			// 
			// butBaseUnitOfMeasures
			// 
			this.butBaseUnitOfMeasures.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butBaseUnitOfMeasures.Location = new System.Drawing.Point(96, 288);
			this.butBaseUnitOfMeasures.Name = "butBaseUnitOfMeasures";
			this.butBaseUnitOfMeasures.Size = new System.Drawing.Size(75, 32);
			this.butBaseUnitOfMeasures.TabIndex = 2;
			this.butBaseUnitOfMeasures.Text = "BaseUnitOfMeasures";
			this.butBaseUnitOfMeasures.Click += new System.EventHandler(this.butBaseUnitOfMeasures_Click);
			// 
			// butManagementServicesRateTypes
			// 
			this.butManagementServicesRateTypes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butManagementServicesRateTypes.Location = new System.Drawing.Point(168, 288);
			this.butManagementServicesRateTypes.Name = "butManagementServicesRateTypes";
			this.butManagementServicesRateTypes.Size = new System.Drawing.Size(96, 32);
			this.butManagementServicesRateTypes.TabIndex = 3;
			this.butManagementServicesRateTypes.Text = "ManagementServicesRateTypes";
			this.butManagementServicesRateTypes.Click += new System.EventHandler(this.butManagementServicesRateTypes_Click);
			// 
			// butConversionUnitOfMeasure
			// 
			this.butConversionUnitOfMeasure.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butConversionUnitOfMeasure.Location = new System.Drawing.Point(264, 288);
			this.butConversionUnitOfMeasure.Name = "butConversionUnitOfMeasure";
			this.butConversionUnitOfMeasure.Size = new System.Drawing.Size(96, 32);
			this.butConversionUnitOfMeasure.TabIndex = 4;
			this.butConversionUnitOfMeasure.Text = "ConversionUnitOfMeasures";
			this.butConversionUnitOfMeasure.Click += new System.EventHandler(this.butConversionUnitOfMeasure_Click);
			// 
			// TestCommonCodeTables
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 321);
			this.Controls.Add(this.butConversionUnitOfMeasure);
			this.Controls.Add(this.butManagementServicesRateTypes);
			this.Controls.Add(this.butBaseUnitOfMeasures);
			this.Controls.Add(this.butManagementServiceTypes);
			this.Name = "TestCommonCodeTables";
			this.Text = "DataLayer Test - Common Code Tables";
			this.Load += new System.EventHandler(this.TestCommonCodeTables_Load);
			this.Controls.SetChildIndex(this.butManagementServiceTypes, 0);
			this.Controls.SetChildIndex(this.butBaseUnitOfMeasures, 0);
			this.Controls.SetChildIndex(this.butManagementServicesRateTypes, 0);
			this.Controls.SetChildIndex(this.butConversionUnitOfMeasure, 0);
			this.ResumeLayout(false);

		}
		#endregion

		private void TestCommonCodeTables_Load(object sender, System.EventArgs e)
		{
			
		}

		private void butManagementServiceTypes_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				ManagementServiceType obj = new ManagementServiceType(i, "MGMT-SVC" + i.ToString(), "ManagementServiceType " + i.ToString());  // Use appropriate constructor
				//obj.CreatedBy = 2;
				// Do other initializations on the object;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.ManagementServiceTypeId))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
					
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}		
		}

		private void butBaseUnitOfMeasures_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				BaseUnitOfMeasure obj = new BaseUnitOfMeasure(i, "BASE-UOM" + i.ToString(), "BaseUnitOfMeasure " + i.ToString());  // Use appropriate constructor
				//obj.CreatedBy = 2;
				// Do other initializations on the object;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.BaseUnitOfMeasureId))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}
		}

		private void butManagementServicesRateTypes_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				ManagementServicesRateType obj = new ManagementServicesRateType(i, "MGM-SVC-RT" + i.ToString(), "ManagementServicesRateType " + i.ToString());  // Use appropriate constructor
				//obj.CreatedBy = 2;
				// Do other initializations on the object;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.ManagementServicesRateTypeId))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}
		}

		private void butConversionUnitOfMeasure_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 11; i++)
			{
				ConversionUnitOfMeasure obj = new ConversionUnitOfMeasure(i, "CONV-UOM" + i.ToString(), "ConversionUnitOfMeasure " + i.ToString());  // Use appropriate constructor
				//obj.CreatedBy = 2;
				// Do other initializations on the object;
				try 
				{
					obj.Save();
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " saved");
				}
				catch(Exception ex)
				{
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " save failed! " + ex.ToString());
				}
				
				if (!obj.Load(obj.ConversionUnitOfMeasureId))
					WriteLine(obj.GetType().ToString() + " PK=" + obj.PKString + " load failed!");
				// do some change in the properties
				obj.Save();
				//obj.MarkDel();  // Mark for deletion
				//obj.Save();  // Delete it
			}		
		}


	}
}

