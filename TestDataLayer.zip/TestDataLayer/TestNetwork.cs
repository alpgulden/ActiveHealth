using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using ActiveAdvice.DataLayer;

namespace TestDataLayer
{
	public class TestNetwork : TestDataLayer.BaseTestForm
	{
		private System.Windows.Forms.Button btnAdd10T;
		private System.Windows.Forms.Button btnAddNetwork;
		private System.Windows.Forms.TextBox txtNetworkID;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button btnAddGroupPractice;
		private System.Windows.Forms.Button btnAddFacility;
		private System.Windows.Forms.Button btnAddPlan;
		private System.ComponentModel.IContainer components = null;

		public TestNetwork()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnAdd10T = new System.Windows.Forms.Button();
			this.btnAddNetwork = new System.Windows.Forms.Button();
			this.txtNetworkID = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.btnAddGroupPractice = new System.Windows.Forms.Button();
			this.btnAddFacility = new System.Windows.Forms.Button();
			this.btnAddPlan = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnAdd10T
			// 
			this.btnAdd10T.Location = new System.Drawing.Point(8, 296);
			this.btnAdd10T.Name = "btnAdd10T";
			this.btnAdd10T.Size = new System.Drawing.Size(88, 23);
			this.btnAdd10T.TabIndex = 1;
			this.btnAdd10T.Text = "Add 10NType";
			this.btnAdd10T.Click += new System.EventHandler(this.butTest1_Click);
			// 
			// btnAddNetwork
			// 
			this.btnAddNetwork.Location = new System.Drawing.Point(104, 296);
			this.btnAddNetwork.Name = "btnAddNetwork";
			this.btnAddNetwork.Size = new System.Drawing.Size(80, 23);
			this.btnAddNetwork.TabIndex = 2;
			this.btnAddNetwork.Text = "Add Network";
			this.btnAddNetwork.Click += new System.EventHandler(this.btnAddNetwork_Click);
			// 
			// txtNetworkID
			// 
			this.txtNetworkID.Location = new System.Drawing.Point(624, 296);
			this.txtNetworkID.Name = "txtNetworkID";
			this.txtNetworkID.Size = new System.Drawing.Size(40, 20);
			this.txtNetworkID.TabIndex = 3;
			this.txtNetworkID.Text = "1";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(192, 296);
			this.button1.Name = "button1";
			this.button1.TabIndex = 4;
			this.button1.Text = "Add Prov";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// btnAddGroupPractice
			// 
			this.btnAddGroupPractice.Location = new System.Drawing.Point(272, 296);
			this.btnAddGroupPractice.Name = "btnAddGroupPractice";
			this.btnAddGroupPractice.TabIndex = 5;
			this.btnAddGroupPractice.Text = "Add GP";
			this.btnAddGroupPractice.Click += new System.EventHandler(this.btnAddGroupPractice_Click);
			// 
			// btnAddFacility
			// 
			this.btnAddFacility.Location = new System.Drawing.Point(352, 296);
			this.btnAddFacility.Name = "btnAddFacility";
			this.btnAddFacility.TabIndex = 6;
			this.btnAddFacility.Text = "Add Fac";
			this.btnAddFacility.Click += new System.EventHandler(this.btnAddFacility_Click);
			// 
			// btnAddPlan
			// 
			this.btnAddPlan.Location = new System.Drawing.Point(440, 296);
			this.btnAddPlan.Name = "btnAddPlan";
			this.btnAddPlan.TabIndex = 7;
			this.btnAddPlan.Text = "Add Plan?";
			// 
			// TestNetwork
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 321);
			this.Controls.Add(this.btnAddPlan);
			this.Controls.Add(this.btnAddFacility);
			this.Controls.Add(this.btnAddGroupPractice);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.txtNetworkID);
			this.Controls.Add(this.btnAddNetwork);
			this.Controls.Add(this.btnAdd10T);
			this.Name = "TestNetwork";
			this.Load += new System.EventHandler(this.TestModuleX_Load);
			this.Controls.SetChildIndex(this.btnAdd10T, 0);
			this.Controls.SetChildIndex(this.btnAddNetwork, 0);
			this.Controls.SetChildIndex(this.txtNetworkID, 0);
			this.Controls.SetChildIndex(this.button1, 0);
			this.Controls.SetChildIndex(this.btnAddGroupPractice, 0);
			this.Controls.SetChildIndex(this.btnAddFacility, 0);
			this.Controls.SetChildIndex(this.btnAddPlan, 0);
			this.ResumeLayout(false);

		}
		#endregion

		private void butTest1_Click(object sender, System.EventArgs e)
		{
			for (int i = 1; i < 10; i++)
			{
				NetworkType ntype = new NetworkType();
				ntype.New();
				ntype.Code						= "NET" + i.ToString();
				ntype.Description				= "Description for network type #: " + i.ToString();
				ntype.Notepad					= "Note for Network type #:" + i.ToString();
				ntype.Save();
				WriteLine("Network Type# : " + i.ToString() + " has been inserted into DB.");
			}

		}



		private void TestModuleX_Load(object sender, System.EventArgs e)
		{
		
		}

		private void btnAddNetwork_Click(object sender, System.EventArgs e)
		{


			for (int i=1; i < 10; i++)
			{
				Network network = null;
				try
				{
					Address addrNew			= new Address();
					addrNew.New();
					
					addrNew.City			= "Hicksville";
					addrNew.County			= "NASSAU";
					addrNew.Country			= "U.S.";
					addrNew.DeliveryMethod	= Address.EnumDeliveryMethod.Email;
					addrNew.Line1			= "46 East John St " + i.ToString();
					addrNew.PhoneNumber1	= "5166723540";
					addrNew.PhoneExt1		= "12";
					addrNew.State			= "NY";
					addrNew.Save();
					network = new Network();
					network.New();
					network.Name			= "Test Network #" + i.ToString();
					network.New();
					network.CreatedBy		= 1;
					network.CreateTime		= DateTime.Now;
					network.AddressID		= addrNew.AddressID;
					network.AlternateID		= "ALT123123" + i.ToString();
					network.EffectiveDate	= DateTime.Now.AddDays(i);
					network.Email			= "testnetwork" + i.ToString() + "@netsoft-usa.com";
					network.Note			= "Note for Test Network #" + i.ToString();
					network.TypeID			= (i % 5) + 1;
					network.Save();
				}
				catch (Exception ex)
				{
					MessageBox.Show("An error occurred while saving Network: " + ex.Message);
					return;
				}
				WriteLine("Network saved; network ID #" + network.NetworkID.ToString());
			}

			
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			
			try
			{
				Network nw = new Network();
				nw.Load(int.Parse(txtNetworkID.Text));
				nw.LoadProviderNetworkLinks(true);
				if (nw.ProviderNetworkLinks == null)
				{
					nw.ProviderNetworkLinks = new ProviderLocationNetworkLinkCollection();
				}
				for (int i=1; i < 4; i++)
				{
					ProviderLocationNetworkLink pvlink = new ProviderLocationNetworkLink();
					pvlink.New();
					pvlink.ProviderLocationID		   = i;
					pvlink.NetworkID				   = int.Parse(txtNetworkID.Text);
					pvlink.EffectiveDate 			   = DateTime.Now;
					pvlink.TerminationDate 			   = DateTime.Now.AddDays(20);
					WriteLine("ProviderLink added to collection");
					nw.ProviderNetworkLinks.Add(pvlink);
				}
				nw.ProviderNetworkLinks.Save();
				//WriteLine("Providers Saved");
				nw.Save();
			}
			catch(Exception ex)
			{
				MessageBox.Show("An error occured while loading network, please check ID and try again." + ex.Message);
				return;
			}
		}

		private void btnAddGroupPractice_Click(object sender, System.EventArgs e)
		{
			try
			{
				Network nw = new Network();
				nw.Load(int.Parse(txtNetworkID.Text));
				nw.LoadGroupPracticeNetworkLinks(true);
				if (nw.GroupPracticeNetworkLinks == null)
					nw.GroupPracticeNetworkLinks = new GroupPracticeLocationNetworkLinkCollection();
				for (int i = 1; i < 4; i++)
				{
					GroupPracticeLocationNetworkLink gplink = new GroupPracticeLocationNetworkLink();
					gplink.New();
					gplink.GroupPracticeLocationID	= (i % 2) + 1 ;
					gplink.NetworkID				= int.Parse(txtNetworkID.Text);
					gplink.EffectiveDate 			= DateTime.Now;
					gplink.TerminationDate			= DateTime.Now.AddDays(30);
					nw.GroupPracticeNetworkLinks.Add(gplink);
					WriteLine("GroupPracticeLocation Link added to Collection");
				}
				nw.GroupPracticeNetworkLinks.Save();
				nw.Save();
				WriteLine("Network Saved");
			}
			catch (Exception ex)
			{
				MessageBox.Show("An error occured while updating Network: " + ex.Message);
			}

		}

		private void btnAddFacility_Click(object sender, System.EventArgs e)
		{
			Network nw = new Network();
			try
			{
				nw.Load(int.Parse(txtNetworkID.Text));
			}
			catch
			{
				MessageBox.Show("An error occurred while loading specified network, please try again");
				return;
			
			}
			nw.LoadFacilityNetworkLinks(true);
			if (nw.FacilityNetworkLinks == null)
				nw.FacilityNetworkLinks = new FacilityLocationNetworkLinkCollection();

			for (int i=0; i < 3; i++)
			{
				FacilityLocationNetworkLink flink = new FacilityLocationNetworkLink();
				flink.New();
				
				flink.Active				= true;
				flink.AsOfDate				= DateTime.Now;
				flink.TerminationDate 		= DateTime.Now.AddDays(20);
				flink.FacilityLocationID	= (i % 3) + 1;
				flink.NetworkID				= int.Parse(txtNetworkID.Text);
				flink.EffectiveDate 		= DateTime.Now;
				
				WriteLine("FacilityLocationLink added to collection");
				nw.FacilityNetworkLinks.Add(flink);
			}
			nw.Save();
			WriteLine("Collection saved");
		}
	}
}

