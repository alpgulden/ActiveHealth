using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using NetsoftUSA.DataLayer;
using ActiveAdvice.DataLayer;

namespace TestDataLayer
{
	public class TestOrganizations : TestDataLayer.BaseTestForm
	{
		private System.Windows.Forms.Button butTestORGCrud;
		private System.Windows.Forms.Button butTestSORGSynonyms;
		private System.Windows.Forms.Button butTestOrgFocusses;
		private System.Windows.Forms.Button butCreateMORGORGSORG;
		private System.ComponentModel.IContainer components = null;

		Organization aMorg;
		Organization anOrg;
		private System.Windows.Forms.Button butTestEncodedOrgID;
		private System.Windows.Forms.Button butPlanSORGs;
		private System.Windows.Forms.Button butOrganizationPath;
		Organization aSorg;

		public TestOrganizations()
		{
			// This call is required by the Windows Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.butTestORGCrud = new System.Windows.Forms.Button();
			this.butTestSORGSynonyms = new System.Windows.Forms.Button();
			this.butTestOrgFocusses = new System.Windows.Forms.Button();
			this.butCreateMORGORGSORG = new System.Windows.Forms.Button();
			this.butTestEncodedOrgID = new System.Windows.Forms.Button();
			this.butPlanSORGs = new System.Windows.Forms.Button();
			this.butOrganizationPath = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// butTestORGCrud
			// 
			this.butTestORGCrud.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butTestORGCrud.Location = new System.Drawing.Point(8, 296);
			this.butTestORGCrud.Name = "butTestORGCrud";
			this.butTestORGCrud.TabIndex = 1;
			this.butTestORGCrud.Text = "Test CRUD";
			this.butTestORGCrud.Click += new System.EventHandler(this.butTestORGCrud_Click);
			// 
			// butTestSORGSynonyms
			// 
			this.butTestSORGSynonyms.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butTestSORGSynonyms.Location = new System.Drawing.Point(240, 296);
			this.butTestSORGSynonyms.Name = "butTestSORGSynonyms";
			this.butTestSORGSynonyms.Size = new System.Drawing.Size(128, 23);
			this.butTestSORGSynonyms.TabIndex = 2;
			this.butTestSORGSynonyms.Text = "Test SORG Synonyms";
			this.butTestSORGSynonyms.Click += new System.EventHandler(this.butTestSORGSynonyms_Click);
			// 
			// butTestOrgFocusses
			// 
			this.butTestOrgFocusses.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butTestOrgFocusses.Location = new System.Drawing.Point(368, 296);
			this.butTestOrgFocusses.Name = "butTestOrgFocusses";
			this.butTestOrgFocusses.Size = new System.Drawing.Size(128, 23);
			this.butTestOrgFocusses.TabIndex = 3;
			this.butTestOrgFocusses.Text = "Organization Focusses";
			this.butTestOrgFocusses.Click += new System.EventHandler(this.butTestOrgFocusses_Click);
			// 
			// butCreateMORGORGSORG
			// 
			this.butCreateMORGORGSORG.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butCreateMORGORGSORG.Location = new System.Drawing.Point(80, 296);
			this.butCreateMORGORGSORG.Name = "butCreateMORGORGSORG";
			this.butCreateMORGORGSORG.Size = new System.Drawing.Size(160, 23);
			this.butCreateMORGORGSORG.TabIndex = 4;
			this.butCreateMORGORGSORG.Text = "Create MORG/ORG/SORG";
			this.butCreateMORGORGSORG.Click += new System.EventHandler(this.butCreateMORGORGSORG_Click);
			// 
			// butTestEncodedOrgID
			// 
			this.butTestEncodedOrgID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butTestEncodedOrgID.Location = new System.Drawing.Point(8, 232);
			this.butTestEncodedOrgID.Name = "butTestEncodedOrgID";
			this.butTestEncodedOrgID.Size = new System.Drawing.Size(144, 23);
			this.butTestEncodedOrgID.TabIndex = 5;
			this.butTestEncodedOrgID.Text = "Test Encoded Org ID";
			this.butTestEncodedOrgID.Click += new System.EventHandler(this.butTestEncodedOrgID_Click);
			// 
			// butPlanSORGs
			// 
			this.butPlanSORGs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butPlanSORGs.Location = new System.Drawing.Point(496, 296);
			this.butPlanSORGs.Name = "butPlanSORGs";
			this.butPlanSORGs.TabIndex = 6;
			this.butPlanSORGs.Text = "Plan SORGs";
			this.butPlanSORGs.Click += new System.EventHandler(this.butPlanSORGs_Click);
			// 
			// butOrganizationPath
			// 
			this.butOrganizationPath.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.butOrganizationPath.Location = new System.Drawing.Point(400, 272);
			this.butOrganizationPath.Name = "butOrganizationPath";
			this.butOrganizationPath.Size = new System.Drawing.Size(168, 23);
			this.butOrganizationPath.TabIndex = 7;
			this.butOrganizationPath.Text = "OrganizationPath";
			this.butOrganizationPath.Click += new System.EventHandler(this.butOrganizationPath_Click);
			// 
			// TestOrganizations
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 321);
			this.Controls.Add(this.butOrganizationPath);
			this.Controls.Add(this.butPlanSORGs);
			this.Controls.Add(this.butTestEncodedOrgID);
			this.Controls.Add(this.butCreateMORGORGSORG);
			this.Controls.Add(this.butTestOrgFocusses);
			this.Controls.Add(this.butTestSORGSynonyms);
			this.Controls.Add(this.butTestORGCrud);
			this.Name = "TestOrganizations";
			this.Text = "DataLayer Test - Organization";
			this.Load += new System.EventHandler(this.TestOrganizations_Load);
			this.Closed += new System.EventHandler(this.TestOrganizations_Closed);
			this.Controls.SetChildIndex(this.butTestORGCrud, 0);
			this.Controls.SetChildIndex(this.butTestSORGSynonyms, 0);
			this.Controls.SetChildIndex(this.butTestOrgFocusses, 0);
			this.Controls.SetChildIndex(this.butCreateMORGORGSORG, 0);
			this.Controls.SetChildIndex(this.butTestEncodedOrgID, 0);
			this.Controls.SetChildIndex(this.butPlanSORGs, 0);
			this.Controls.SetChildIndex(this.butOrganizationPath, 0);
			this.ResumeLayout(false);

		}
		#endregion

		private void butTestORGCrud_Click(object sender, System.EventArgs e)
		{
			//Organization.TestCRUDOperations();
		}

		private void butTestSORGSynonyms_Click(object sender, System.EventArgs e)
		{
			try
			{
				Organization sorg = new Organization("My Organization", anOrg);
				sorg.LoadOrgSynonyms(false);
				sorg.OrgSynonyms.Add(new OrgSynonym("MyOrg1") );
				sorg.OrgSynonyms.Add(new OrgSynonym("Org1") );
				sorg.OrgSynonyms.Add(new OrgSynonym("Orgy1") );
				sorg.Save();
				sorg.SaveOrgSynonyms();
			}
			catch(Exception ex)
			{
				WriteLine(ex.ToString());
			}

			OrganizationCollection orgCol = new OrganizationCollection();
			orgCol.ElementType = typeof(Organization);
			//orgCol.LoadBySynonym("Org1", true, false);
			WriteLine(orgCol.ToString());
		}

		private void TestOrganizations_Load(object sender, System.EventArgs e)
		{
			
		}

		private void butTestOrgFocusses_Click(object sender, System.EventArgs e)
		{
			Organization sorg = new Organization("My Organization", anOrg);
			sorg.LoadOrganizationFocuses(false);
			sorg.OrganizationFocuses.Add(new OrganizationFocus(1));
			sorg.OrganizationFocuses.Add(new OrganizationFocus(2));
			sorg.OrganizationFocuses.Add(new OrganizationFocus(3));
			sorg.Save();
			sorg.SaveOrganizationFocuses();
		}

		private void butCreateMORGORGSORG_Click(object sender, System.EventArgs e)
		{
			// create a master organization
			aMorg = new Organization("Master Organization A", null);
			aMorg.OrganizationTypeID = 1;
			//aMorg.CreatedBy = 1;
			aMorg.Save();
			WriteLine("Created: " + aMorg);

			// create an organization under this master organization
			anOrg = new Organization("Organization A", aMorg);
			anOrg.OrganizationTypeID = 2;
			anOrg.Save();
			WriteLine("Created: " + anOrg);

			// create an organization under this master organization
			aSorg = new Organization("Sub-Organization A", anOrg);
			aSorg.OrganizationTypeID = 3;
			aSorg.Save();
			WriteLine("Created: " + aSorg);
		}

		private void TestOrganizations_Closed(object sender, System.EventArgs e)
		{
			if (aSorg != null)
			{
				aSorg.MarkDel();
				aSorg.Save();
			}
			
			if (anOrg != null)
			{
				anOrg.MarkDel();
				anOrg.Save();
			}

			if (aMorg != null)
			{
				aMorg.MarkDel();
				aMorg.Save();
			}
		}

		private void butTestEncodedOrgID_Click(object sender, System.EventArgs e)
		{
			TestOrgID o = null;
			DateTime t1 = DateTime.Now;
			for (int i = 1; i < 100; i++)
			{
				o = new TestOrgID(i, null, "Master Org " + i.ToString());
				o.Save();
				for (int j = 1; j < 100; j++)
				{
					o = new TestOrgID(j, new int[] { i }, "Org " + j.ToString() + " of Master Org " + i.ToString());
					o.Save();
					for (int k = 1; k < 100; k++)
					{
						o = new TestOrgID(k, new int[] { i, j }, "Sub Org " + k.ToString() + " of Master Org " + i.ToString() + " Org " + j.ToString());
						o.Save();
					}
				}
			}

			DateTime t2 = DateTime.Now;

			WriteLine("Elapsed Time: {0}", t2 - t1);
		}

		private void butPlanSORGs_Click(object sender, System.EventArgs e)
		{
			Organization sorg = new Organization();
			if (sorg.Load(108))
			{
				//sorg.LoadPlanSORGs(false);
				Plan plan = new Plan();
				plan.Load(2);
				PlanSORG planSORG = new PlanSORG(sorg, plan);
				planSORG.LOSRegion = 1;
				planSORG.DRGType = 1;
				planSORG.GuidelineSourceSet = 1;
				planSORG.PayorGroupID = 1;
				planSORG.LOSRegion = 2;
				sorg.LoadPlanSORGs(false);
				sorg.PlanSORGs.Add(planSORG);
				sorg.SavePlanSORGs();
				//WriteLine(planSORG);
			}
			else
				WriteLine("Can't find sorg");

		}

		private void butOrganizationPath_Click(object sender, System.EventArgs e)
		{
			Organization morg = new Organization();
			if (morg.Load(106))
			{
				WriteLine( morg.OrganizationFullPath );
				WriteLine( morg.OrganizationFullPath );
			}

			Organization org = new Organization();
			if (org.Load(229))
			{
				WriteLine( org.OrganizationFullPath );
				WriteLine( org.OrganizationFullPath );
			}

			Organization sorg = new Organization();
			if (sorg.Load(230))
			{
				WriteLine( sorg.OrganizationFullPath );
				WriteLine( sorg.OrganizationFullPath );
			}


		}
	}
}

