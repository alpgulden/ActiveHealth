using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;
using NetsoftUSA.DataLayer;
using ActiveAdvice.DataLayer;

namespace TestDataLayer
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class BaseTestForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox tb;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem mnuTestORGCRUD;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem mnuProvider;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem mnuTestSubscriber;
		private System.Windows.Forms.MenuItem mnuTestPatient;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuPlanComponents;
		private System.Windows.Forms.MenuItem menuTestPlan;
		private System.Windows.Forms.MenuItem menuItem11;
		private System.Windows.Forms.MenuItem menuCommonCodeTables;
		private System.Windows.Forms.MenuItem menuItem12;
		private System.Windows.Forms.MenuItem menuItem13;
		private System.Windows.Forms.MenuItem menuItem14;
		private System.Windows.Forms.MenuItem mnuTestCMS;
		private System.Windows.Forms.MenuItem menuItem15;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public BaseTestForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}


		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tb = new System.Windows.Forms.TextBox();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem11 = new System.Windows.Forms.MenuItem();
			this.menuCommonCodeTables = new System.Windows.Forms.MenuItem();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.mnuTestORGCRUD = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.menuPlanComponents = new System.Windows.Forms.MenuItem();
			this.menuTestPlan = new System.Windows.Forms.MenuItem();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.mnuTestSubscriber = new System.Windows.Forms.MenuItem();
			this.mnuTestPatient = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem15 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.mnuProvider = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.menuItem12 = new System.Windows.Forms.MenuItem();
			this.menuItem13 = new System.Windows.Forms.MenuItem();
			this.menuItem14 = new System.Windows.Forms.MenuItem();
			this.mnuTestCMS = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			// 
			// tb
			// 
			this.tb.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tb.Location = new System.Drawing.Point(8, 8);
			this.tb.Multiline = true;
			this.tb.Name = "tb";
			this.tb.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.tb.Size = new System.Drawing.Size(656, 139);
			this.tb.TabIndex = 0;
			this.tb.Text = "";
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem11,
																					  this.menuItem1,
																					  this.menuItem10,
																					  this.menuItem8,
																					  this.menuItem2,
																					  this.menuItem3,
																					  this.menuItem4,
																					  this.menuItem5,
																					  this.menuItem7,
																					  this.menuItem9,
																					  this.menuItem12,
																					  this.menuItem13,
																					  this.menuItem14});
			// 
			// menuItem11
			// 
			this.menuItem11.Index = 0;
			this.menuItem11.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.menuCommonCodeTables});
			this.menuItem11.Text = "Common";
			// 
			// menuCommonCodeTables
			// 
			this.menuCommonCodeTables.Index = 0;
			this.menuCommonCodeTables.Text = "Common Code Tables";
			this.menuCommonCodeTables.Click += new System.EventHandler(this.menuCommonCodeTables_Click);
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 1;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuTestORGCRUD});
			this.menuItem1.Text = "Organizations";
			// 
			// mnuTestORGCRUD
			// 
			this.mnuTestORGCRUD.Index = 0;
			this.mnuTestORGCRUD.Text = "Test ORG, MORG, SORG CRUD";
			this.mnuTestORGCRUD.Click += new System.EventHandler(this.mnuTestORGCRUD_Click);
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 2;
			this.menuItem10.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.menuPlanComponents,
																					   this.menuTestPlan});
			this.menuItem10.Text = "Plans";
			// 
			// menuPlanComponents
			// 
			this.menuPlanComponents.Index = 0;
			this.menuPlanComponents.Text = "Test Plan Components";
			this.menuPlanComponents.Click += new System.EventHandler(this.menuPlanComponents_Click);
			// 
			// menuTestPlan
			// 
			this.menuTestPlan.Index = 1;
			this.menuTestPlan.Text = "Test Plan";
			this.menuTestPlan.Click += new System.EventHandler(this.menuTestPlan_Click);
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 3;
			this.menuItem8.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuTestSubscriber,
																					  this.mnuTestPatient});
			this.menuItem8.Text = "Subscribers";
			// 
			// mnuTestSubscriber
			// 
			this.mnuTestSubscriber.Index = 0;
			this.mnuTestSubscriber.Text = "Test Subscriber";
			this.mnuTestSubscriber.Click += new System.EventHandler(this.mnuTestSubscriber_Click);
			// 
			// mnuTestPatient
			// 
			this.mnuTestPatient.Index = 1;
			this.mnuTestPatient.Text = "Test Patient";
			this.mnuTestPatient.Click += new System.EventHandler(this.mnuTestPatient_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 4;
			this.menuItem2.Text = "Events";
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 5;
			this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem15});
			this.menuItem3.Text = "Assessments";
			// 
			// menuItem15
			// 
			this.menuItem15.Index = 0;
			this.menuItem15.Text = "Question";
			this.menuItem15.Click += new System.EventHandler(this.menuItem15_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 6;
			this.menuItem4.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuProvider});
			this.menuItem4.Text = "Providers";
			// 
			// mnuProvider
			// 
			this.mnuProvider.Index = 0;
			this.mnuProvider.Text = "Provider";
			this.mnuProvider.Click += new System.EventHandler(this.mnuProvider_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 7;
			this.menuItem5.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem6});
			this.menuItem5.Text = "GroupPractice";
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 0;
			this.menuItem6.Text = "Test GP";
			this.menuItem6.Click += new System.EventHandler(this.menuItem6_Click);
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 8;
			this.menuItem7.Text = "Networks";
			this.menuItem7.Click += new System.EventHandler(this.menuItem7_Click);
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 9;
			this.menuItem9.Text = "Facility";
			this.menuItem9.Click += new System.EventHandler(this.menuItem9_Click);
			// 
			// menuItem12
			// 
			this.menuItem12.Index = 10;
			this.menuItem12.Text = "Referral";
			this.menuItem12.Click += new System.EventHandler(this.menuItem12_Click);
			// 
			// menuItem13
			// 
			this.menuItem13.Index = 11;
			this.menuItem13.Text = "C";
			// 
			// menuItem14
			// 
			this.menuItem14.Index = 12;
			this.menuItem14.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.mnuTestCMS});
			this.menuItem14.Text = "CMS";
			// 
			// mnuTestCMS
			// 
			this.mnuTestCMS.Index = 0;
			this.mnuTestCMS.Text = "Test CMS";
			this.mnuTestCMS.Click += new System.EventHandler(this.mnuTestCMS_Click);
			// 
			// BaseTestForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(672, 225);
			this.Controls.Add(this.tb);
			this.Menu = this.mainMenu1;
			this.Name = "BaseTestForm";
			this.Text = "DataLayer Test - Model X";
			this.Load += new System.EventHandler(this.BaseTestForm_Load);
			this.ResumeLayout(false);

		}
		#endregion

		public void Write(string msg)
		{
			tb.Text += msg;
			Debug.Write(msg);
		}

		public void WriteLine(string msg)
		{
			tb.Text += msg + "\r\n";
			Debug.WriteLine(msg);
		}

		private void menuItem15_Click(object sender, System.EventArgs e)
		{
			TestAssessment testAssessment = new TestAssessment();
			testAssessment.Show();
		}

		private void mnuTestCMS_Click(object sender, System.EventArgs e)
		{
			TestCMS testCMS = new TestCMS();
			testCMS.Show();
		}

		private void menuItem12_Click(object sender, System.EventArgs e)
		{
			TestReferral testRef = new TestReferral();
			testRef.Show();
		}

		private void menuCommonCodeTables_Click(object sender, System.EventArgs e)
		{
			TestCommonCodeTables test = new TestCommonCodeTables();
			test.Show();
		}

		private void menuTestPlan_Click(object sender, System.EventArgs e)
		{
			TestPlan testPlan = new TestPlan();
			testPlan.Show();
		}

		private void menuPlanComponents_Click(object sender, System.EventArgs e)
		{
			TestPlanComponents testPlanComponents = new TestPlanComponents();
			testPlanComponents.Show();
		}

		private void menuItem9_Click(object sender, System.EventArgs e)
		{
			TestFacility testfac = new TestFacility();
			testfac.Show();
		}

		private void mnuTestPatient_Click(object sender, System.EventArgs e)
		{
			TestPatient test = new TestPatient();
			test.Show();
		}

		private void mnuTestSubscriber_Click(object sender, System.EventArgs e)
		{
			TestSubscribers test = new TestSubscribers();
			test.Show();
		}

		private void menuItem7_Click(object sender, System.EventArgs e)
		{
			TestNetwork netw = new TestNetwork();
			netw.Show();
		}

		private void menuItem6_Click(object sender, System.EventArgs e)
		{
			TestGroupPractice gpForm = new TestGroupPractice();
			gpForm.Show();
		}

		private void BaseTestForm_Load(object sender, System.EventArgs e)
		{
			NSGlobal.ConnectionString = @"data source=NS1DEV005;initial catalog=ActiveAdviceAHMData;uid=AA_user;pwd=AA_user;packet size=4096;pooling=false;max pool size=500;connection lifetime=5;Persist Security Info=True";

			//AuthorizationExport ae = new AuthorizationExport();
			//ae.ReadAuthorizations();
		}

		private void mnuProvider_Click(object sender, System.EventArgs e)
		{
			TestProvider test = new TestProvider();
			test.Show();
		}

		private void mnuTestORGCRUD_Click(object sender, System.EventArgs e)
		{
			TestOrganizations test = new TestOrganizations();
			test.Show();
		}

		public void WriteLine(string msg, params object[] args)
		{
			WriteLine(String.Format(msg, args));
		}

		public void WriteLine(string[] msg)
		{
			for (int i = 0; i < msg.Length; i++)
				WriteLine(msg[i]);
		}

		public void WriteLine(string[] msg, params object[] args)
		{
			for (int i = 0; i < msg.Length; i++)
				WriteLine(msg[i], args);
		}
	}
}
