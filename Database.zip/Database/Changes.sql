/*
Author: Burag C.
Date:   02/04/05
Desc: 	Adds the missing NetworkPlanHistory table to keep track of NetworkPlan history */

USE ACTIVEADVICE
GO
DROP TABLE NetworkPlanHistory
CREATE TABLE NetworkPlanHistory (
NetworkPlanHistoryID INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
NetworkPlanID	     INT NOT NULL CONSTRAINT FK_NetworkPlan_NetworkPlanHistory FOREIGN KEY  REFERENCES NetworkPlan(NetworkPlanID),
StartDate 	     DateTime NOT NULL,
EndDate		     DateTime,
AsOfDate	     DateTime NOT NULL
)