INSERT INTO [ActiveAdvice].[dbo].[CMSType]([Code], [Description], [Active])
VALUES('CMC1', 'Disease Management', 1)

INSERT INTO [ActiveAdvice].[dbo].[CMSType]([Code], [Description], [Active])
VALUES('CMC2', 'Case Management', 1)

INSERT INTO [ActiveAdvice].[dbo].[CMSType]([Code], [Description], [Active])
VALUES('CMC3', 'Maternicheck', 1)
GO


INSERT INTO [ActiveAdvice].[dbo].[CMSPhase]([PhaseId], [Code], [Description], [Active])
VALUES(1, 'CPC1', 'Assessment', 1)

INSERT INTO [ActiveAdvice].[dbo].[CMSPhase]([PhaseId], [Code], [Description], [Active])
VALUES(2, 'CPC2', 'Final', 1)

INSERT INTO [ActiveAdvice].[dbo].[CMSPhase]([PhaseId], [Code], [Description], [Active])
VALUES(3, 'CPC3', 'Follow-up', 1)
GO

INSERT INTO [ActiveAdvice].[dbo].[CMSAcuity]([AcuityId], [Code], [Description], [Active])
VALUES(1, 'CAC1', 'Mild', 1)

INSERT INTO [ActiveAdvice].[dbo].[CMSAcuity]([AcuityId], [Code], [Description], [Active])
VALUES(2, 'CAC2', 'Severe', 1)

INSERT INTO [ActiveAdvice].[dbo].[CMSAcuity]([AcuityId], [Code], [Description], [Active])
VALUES(3, 'CAC3', 'Moderate', 1)

INSERT INTO [ActiveAdvice].[dbo].[CMSAcuity]([AcuityId], [Code], [Description], [Active])
VALUES(4, 'CAC4', 'Stable', 1)
GO

INSERT INTO [ActiveAdvice].[dbo].[CMSIntensity]([IntensityId], [Code], [Description], [Active])
VALUES(1, 'CIC1', 'CM Assessment', 1)

INSERT INTO [ActiveAdvice].[dbo].[CMSIntensity]([IntensityId], [Code], [Description], [Active])
VALUES(2, 'CIC2', 'Catastrophic CM', 1)

INSERT INTO [ActiveAdvice].[dbo].[CMSIntensity]([IntensityId], [Code], [Description], [Active])
VALUES(3, 'CIC3', 'Routine Discharge', 1)

INSERT INTO [ActiveAdvice].[dbo].[CMSIntensity]([IntensityId], [Code], [Description], [Active])
VALUES(4, 'CIC4', 'Benefit Management', 1)
GO

INSERT INTO [ActiveAdvice].[dbo].[CMSStatusType]([StatusTypeId], [Code], [Description], [Active])
VALUES(1, 'CMSSC1', 'Cancelled', 1)

INSERT INTO [ActiveAdvice].[dbo].[CMSStatusType]([StatusTypeId], [Code], [Description], [Active])
VALUES(2, 'CMSSC2', 'Closed', 1)

INSERT INTO [ActiveAdvice].[dbo].[CMSStatusType]([StatusTypeId], [Code], [Description], [Active])
VALUES(3, 'CMSSC3', 'Declined', 1)
GO

INSERT INTO [ActiveAdvice].[dbo].[CMSRisk]([CMSRiskId], [Code], [Description], [Active])
VALUES(1, 'CMSRC1', 'High', 1)

INSERT INTO [ActiveAdvice].[dbo].[CMSRisk]([CMSRiskId], [Code], [Description], [Active])
VALUES(2, 'CMSRC2', 'Medium', 1)

INSERT INTO [ActiveAdvice].[dbo].[CMSRisk]([CMSRiskId], [Code], [Description], [Active])
VALUES(3, 'CMSRC3', 'Low', 1)
GO

INSERT INTO [ActiveAdvice].[dbo].[CaseOpenReason]([CaseOpenReasonId], [Code], [Description], [Active], [NotePad], [ReadOnly], [CreatedBy], [CreateTime])
VALUES(1, 'CORC01', 'Client Request', 1, 'test NotePad', 0, 1, getdate())

INSERT INTO [ActiveAdvice].[dbo].[CaseOpenReason]([CaseOpenReasonId], [Code], [Description], [Active], [NotePad], [ReadOnly], [CreatedBy], [CreateTime])
VALUES(2, 'CORC02', 'Identified through scroring application', 1, 'test NotePad', 0, 1, getdate())

INSERT INTO [ActiveAdvice].[dbo].[CaseOpenReason]([CaseOpenReasonId], [Code], [Description], [Active], [NotePad], [ReadOnly], [CreatedBy], [CreateTime])
VALUES(3, 'CORC03', 'Discharge Planning needs', 1, 'test NotePad', 0, 1, getdate())
GO

INSERT INTO [ActiveAdvice].[dbo].[CaseContinuedReason]([CaseContinuedReasonId], [Code], [Description], [Active], [NotePad], [ReadOnly], [CreatedBy], [CreateTime])
VALUES(1, 'CCRC01', 'Complex care needs continue', 1, 'NotePad', 0, 1, getdate())

INSERT INTO [ActiveAdvice].[dbo].[CaseContinuedReason]([CaseContinuedReasonId], [Code], [Description], [Active], [NotePad], [ReadOnly], [CreatedBy], [CreateTime])
VALUES(2, 'CCRC02', 'Maternicheck', 1, 'NotePad', 0, 1, getdate())

INSERT INTO [ActiveAdvice].[dbo].[CaseContinuedReason]([CaseContinuedReasonId], [Code], [Description], [Active], [NotePad], [ReadOnly], [CreatedBy], [CreateTime])
VALUES(3, 'CCRC03', 'Inforced Care Management Program', 1, 'NotePad', 0, 1, getdate())
GO

INSERT INTO [ActiveAdvice].[dbo].[CaseClosedReason]([CaseClosedReasonId], [Code], [Description], [Active], [NotePad], [ReadOnly], [CreatedBy], [CreateTime])
VALUES(1, 'CCLRC01', 'Patient Expired', 1, 'Read Only', 1, 1, getdate())

INSERT INTO [ActiveAdvice].[dbo].[CaseClosedReason]([CaseClosedReasonId], [Code], [Description], [Active], [NotePad], [ReadOnly], [CreatedBy], [CreateTime])
VALUES(2, 'CCLRC02', 'Benefits Exhausted', 1, 'Read Only', 1, 1, getdate())

INSERT INTO [ActiveAdvice].[dbo].[CaseClosedReason]([CaseClosedReasonId], [Code], [Description], [Active], [NotePad], [ReadOnly], [CreatedBy], [CreateTime])
VALUES(3, 'CCLRC03', 'CM Not Required', 1, 'Read Only', 1, 1, getdate())
GO

INSERT INTO [ActiveAdvice].[dbo].[CaseSource]([CaseSourceID], [Code], [Description], [Active], [NotePad], [ReadOnly], [CreatedBy])
VALUES(1, 'CSCO01', 'Client', 1, 'NotePad', 1, 1)

INSERT INTO [ActiveAdvice].[dbo].[CaseSource]([CaseSourceID], [Code], [Description], [Active], [NotePad], [ReadOnly], [CreatedBy])
VALUES(2, 'CSCO02', 'Family', 1, 'NotePad', 1, 1)

INSERT INTO [ActiveAdvice].[dbo].[CaseSource]([CaseSourceID], [Code], [Description], [Active], [NotePad], [ReadOnly], [CreatedBy])
VALUES(3, 'CSCO03', 'Patient', 1, 'NotePad', 1, 1)
GO

INSERT INTO [ActiveAdvice].[dbo].[SystemStatus]([Code], [Description], [Active], [NotePad], [ReadOnly], [CreatedBy], [CreateTime])
VALUES('SSC1', 'System Status 01', 1, 'NotePad', 1, 1, getdate())

INSERT INTO [ActiveAdvice].[dbo].[SystemStatus]([Code], [Description], [Active], [NotePad], [ReadOnly], [CreatedBy], [CreateTime])
VALUES('SSC2', 'System Status 02', 1, 'NotePad', 1, 1, getdate())

INSERT INTO [ActiveAdvice].[dbo].[SystemStatus]([Code], [Description], [Active], [NotePad], [ReadOnly], [CreatedBy], [CreateTime])
VALUES('SSC3', 'System Status 03', 1, 'NotePad', 1, 1, getdate())
GO