use ActiveAdvice
go

-- First we need to create the DRG types
-- Since there's a constraint we have to play around...

-- Step #1 Create a User account "DRG_user"
if not exists(select * from AAUser where LoginName = 'DRG_user')
begin
    -- We don't have a DRG_user account, so create it...
    -- There's no initial user, so DRG_user will be that user
    -- first I'll drop the constraint so I can put it in...
    if exists(select * from sysobjects where name = 'FK_Users_Users_FK1' and type = 'F')
        ALTER TABLE AAUser DROP CONSTRAINT FK_Users_Users_FK1
    if exists(select * from sysobjects where name = 'FK_Users_Users_CreatedBy' and type = 'F')
        ALTER TABLE AAUser DROP CONSTRAINT FK_Users_Users_CreatedBy
    insert into AAUser (LoginName, Password, FailedLogins, Status, CreatedBy) VALUES('DRG_user', 'drguser', 0, 1, 1)
    declare @userid int
    select @userid = UserId from AAUser where LoginName = 'DRG_user'
    update AAUser set CreatedBy = @userid where LoginName = 'DRG_user'
    ALTER TABLE AAUser ADD CONSTRAINT FK_Users_Users_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES AAUser(UserID)
end
go

-- Clean out the DRG tables...
if exists(select * from sysobjects where name = 'FK_DRGTypes_DRGCodes' and type = 'F')
    ALTER TABLE DRGCode DROP CONSTRAINT FK_DRGTypes_DRGCodes
if exists(select * from sysobjects where name = 'FK_DRGType_DRGCode' and type = 'F')
    ALTER TABLE DRGCode DROP CONSTRAINT FK_DRGType_DRGCode
if exists(select * from sysobjects where name = 'FK_DRGTypes_Referrals_DrgType' and type = 'F')
    ALTER TABLE Referral DROP CONSTRAINT FK_DRGTypes_Referrals_DrgType
if exists(select * from sysobjects where name = 'FK_DRGType_Referral' and type = 'F')
    ALTER TABLE Referral DROP CONSTRAINT FK_DRGType_Referral
if exists(select * from sysobjects where name = 'FK_DRGTypes_Events_DrgType' and type = 'F')
    ALTER TABLE Event DROP CONSTRAINT FK_DRGTypes_Events_DrgType
if exists(select * from sysobjects where name = 'FK_DRGType_Event' and type = 'F')
    ALTER TABLE Event DROP CONSTRAINT FK_DRGType_Event
if exists(select * from sysobjects where name = 'FK_DRGMDC_DRGCodes' and type = 'F')
    ALTER TABLE DRGCode DROP CONSTRAINT FK_DRGMDC_DRGCodes
if exists(select * from sysobjects where name = 'FK_DRGMDC_DRGCode' and type = 'F')
    ALTER TABLE DRGCode DROP CONSTRAINT FK_DRGMDC_DRGCode
if exists(select * from sysobjects where name = 'FK_DRGServiceClass_DRGCodes' and type = 'F')
    ALTER TABLE DRGCode DROP CONSTRAINT FK_DRGServiceClass_DRGCodes
if exists(select * from sysobjects where name = 'FK_DRGServiceClass_DRGCode' and type = 'F')
    ALTER TABLE DRGCode DROP CONSTRAINT FK_DRGServiceClass_DRGCode
if exists(select * from sysobjects where name = 'DRGCodes_PlanSORGs_FK1' and type = 'F')
    ALTER TABLE PlanSORG DROP CONSTRAINT DRGCodes_PlanSORGs_FK1
if exists(select * from sysobjects where name = 'FK_DRGType_PlanSORG' and type = 'F')
    ALTER TABLE PlanSORG DROP CONSTRAINT FK_DRGType_PlanSORG


truncate table DRGCode
truncate table DRGType
truncate table DRGMDC
truncate table DRGserviceclass

ALTER TABLE DRGCode  ADD CONSTRAINT FK_DRGType_DRGCode  FOREIGN KEY (DRGType)  REFERENCES DRGType(Code)
ALTER TABLE Referral ADD CONSTRAINT FK_DRGType_Referral FOREIGN KEY (DRG_Type) REFERENCES DRGType(Code)
ALTER TABLE Event    ADD CONSTRAINT FK_DRGType_Event    FOREIGN KEY (DRGType)  REFERENCES DRGType(Code)
ALTER TABLE DRGCode  ADD CONSTRAINT FK_DRGMDC_DRGCode   FOREIGN KEY (MDC)      REFERENCES DRGMDC(Code)
ALTER TABLE DRGCode  ADD CONSTRAINT FK_DRGServiceClass_DRGCodes FOREIGN KEY (DRGserviceclass) REFERENCES DRGServiceClass(Code)
ALTER TABLE PlanSORG WITH NOCHECK ADD CONSTRAINT FK_DRGType_PlanSORG FOREIGN KEY (DRGType) REFERENCES DRGType(CodeID)
go

declare @DRGuserid int
select @DRGuserid = UserID from AAUser where LoginName = 'DRG_User'

print 'DRGuserid = ' + convert(varchar(10), @DRGuserid)
select * from AAUser

-- Now we can insert our DRGType
insert into ActiveAdvice.dbo.DRGType (Code, Description, NotePad, GroupType, Active, CreatedBy) VALUES('HCFA','HCFA DRG Grouper','','NA', 1, @DRGuserid)
insert into ActiveAdvice.dbo.DRGType (Code, Description, NotePad, GroupType, Active, CreatedBy) VALUES('NYMD','NY Medicaid Grouper','','NA', 1, @DRGuserid)


-- Now fill up the MDC table
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('','','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('00','DUMMY*DUMMY','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('10','Endocrine,nutritional, & metabolic diseases','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('11','Diseases/Disorders - kidney & urinary tract','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('15','Newborns, neonates w/conditions originating  ','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('12','Diseases/Disorders - male reproductive syst','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('13','Diseases/Disorders - female reproductive sy','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('14','Pregnancy,childbirth and puerperium','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('16','Diseases/Disorders - blood & blood frm orga','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('17','Myeloproliferative diseases/disorders','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('18','Infections & parasitic diseases ','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('19','Mental diseases & disorders','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('20','Alcohol/drug use & alcohol/drug induced organ','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('21','Injuries, poisonings, & toxic effects of drug','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('22','Burns','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('23','Factors influencing health status','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('24','Multiple significant trauma','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('25','Human immunodficiency virus infections','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('01','Diseases/Disorders - nervous system','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('02','Diseases/Disorders - eye','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('03','Diseases/Disorders - ear,nose,mouth,throat','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('05','Diseases/Disorders - circulatory system','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('08','Diseases/Disorders - musculoskelatal/connec','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('04','Diseases/Disorders - respiratory system','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('06','Diseases/Disorders - digestive system','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('07','Diseases/Disorders - hepatobiliary/pancreas','', @DRGuserid)
insert into DRGMDC (Code, Description, NotePad, CreatedBy) VALUES('09','Diseases/Disorders - skin,subcutaneous tiss','', @DRGuserid)


--
-- Insert our Service class data
--
insert into DRGserviceclass (Code, Description, CreatedBy) VALUES('', '', @DRGuserid) 
insert into DRGserviceclass (Code, Description, CreatedBy) VALUES('01','Medical',@DRGuserid)
insert into DRGserviceclass (Code, Description, CreatedBy) VALUES('02','Surgical',@DRGuserid)
insert into DRGserviceclass (Code, Description, CreatedBy) VALUES('03','OB Normal',@DRGuserid)
insert into DRGserviceclass (Code, Description, CreatedBy) VALUES('04','OB C-Section',@DRGuserid)
insert into DRGserviceclass (Code, Description, CreatedBy) VALUES('05','Gynecology',@DRGuserid)
insert into DRGserviceclass (Code, Description, CreatedBy) VALUES('06','Pediatrics',@DRGuserid)
insert into DRGserviceclass (Code, Description, CreatedBy) VALUES('07','Psych', @DRGuserid)
insert into DRGserviceclass (Code, Description, CreatedBy) VALUES('08','SubstAbuse', @DRGuserid)
insert into DRGserviceclass (Code, Description, CreatedBy) VALUES('09','Rehab',@DRGuserid)


--
-- Now dump in the DRGCode data
--
insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('001', '01', 'CRANIOTOMY AGE >17 EXCEPT FOR TRAUMA', 3, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('002', '01', 'CRANIOTOMY FOR TRAUMA AGE >17', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('003', '01', 'CRANIOTOMY AGE 0-17', 2, 13, '', '2', '06', 0, 999, 13, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('004', '01', 'SPINAL PROCEDURES', 2, 6, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('005', '01', 'EXTRACRANIAL VASCULAR PROCEDURES', 2, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('006', '01', 'CARPAL TUNNEL RELEASE', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('007', '01', 'PERIPH&CRAN NERV&OTH NERV SYS PROC W CC', 2, 7, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('008', '01', 'PERIPH&CRAN NERV&OTH NERV SYS PROC WO CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('009', '01', 'SPINAL DISORDERS & INJURIES', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('010', '01', 'NERVOUS SYSTEM NEOPLASMS W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('011', '01', 'NERVOUS SYSTEM NEOPLASMS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('012', '01', 'DEGENERATIVE NERVOUS SYSTEM DISORDERS', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('013', '01', 'MULTIPLE SCLEROSIS & CEREBELLAR ATAXIA', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('014', '01', 'SPECIFIC CEREBROVASC DISORDERS EXC TIA', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('015', '01', 'TIA AND PRECEREBRAL OCCLUSIONS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('016', '01', 'NONSPECIFIC CEREBROVASC DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('017', '01', 'NONSPECIFIC CEREBROVASC DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('018', '01', 'CRANIAL & PERIPH NERVE DISORDERS W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('019', '01', 'CRANIAL & PERIPH NERVE DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('020', '01', 'NERV SYSTEM INFECT EXC VIRAL MENINGITIS', 3, 8, '', '1', '01', 0, 999, 11, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('021', '01', 'VIRAL MENINGITIS', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('022', '01', 'HYPERTENSIVE ENCEPHALOPATHY', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('023', '01', 'NONTRAUMATIC STUPOR & COMA', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('024', '01', 'SEIZURE & HEADACHE AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('025', '01', 'SEIZURE & HEADACHE AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('026', '01', 'SEIZURE & HEADACHE AGE 0-17', 1, 4, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('027', '01', 'TRAUMATIC STUPOR & COMA,COMA >1 HR', 1, 3, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('028', '01', 'TRAUM STUPOR&COMA,COMA<1 HR,AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('029', '01', 'TRAUM STUPOR&COMA,COMA<1HR,AGE>17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('030', '01', 'TRAUM STUPOR & COMA,COMA <1 HR,AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('031', '01', 'CONCUSSION AGE >17 WITH CC', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('032', '01', 'CONCUSSION AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('033', '01', 'CONCUSSION AGE 0-17', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('034', '01', 'OTHER DISORDERS OF NERVOUS SYSTEM W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('035', '01', 'OTHER DISORDERS OF NERVOUS SYSTEM W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('036', '02', 'RETINAL PROCEDURES', 1, 1, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('037', '02', 'ORBITAL PROCEDURES', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('038', '02', 'PRIMARY IRIS PROCEDURES', 0, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('039', '02', 'LENS PROCEDURES WITH OR W/O VITRECTOMY', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('040', '02', 'EXTRAOCULAR PROCS EXCEPT ORBIT AGE >17', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('041', '02', 'EXTRAOCULAR PROCS EXCEPT ORBIT AGE 0-17', 0, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('042', '02', 'INTRAOCULAR PROCS EXC RETINA,IRIS & LENS', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('043', '02', 'HYPHEMA', 0, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('044', '02', 'ACUTE MAJOR EYE INFECTIONS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('045', '02', 'NEUROLOGICAL EYE DISORDERS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('046', '02', 'OTHER DISORDERS OF THE EYE AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('047', '02', 'OTHER DISORDERS OF THE EYE AGE>17 W/O CC', 0, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('048', '02', 'OTHER DISORDERS OF THE EYE AGE 0-17', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('049', '03', 'MAJOR HEAD & NECK PROCEDURES', 2, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('050', '03', 'SIALOADENECTOMY', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('051', '03', 'SALIVARY GLAND PROCS EXC SIALOADENECTOMY', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('052', '03', 'CLEFT LIP & PALATE REPAIR', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('053', '03', 'SINUS & MASTOID PROCEDURES AGE >17', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('054', '03', 'SINUS & MASTOID PROCEDURES AGE 0-17', 0, 3, '', '2', '06', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('055', '03', 'MISC EAR,NOSE,MOUTH & THROAT PROCEDURES', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('056', '03', 'RHINOPLASTY', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('057', '03', 'T&A PROC,EX TONSLCT/ADNDCT ONLY AGE >17', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('058', '03', 'T&A PROC,EX TONSLCT/ADNDCT ONLY AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('059', '03', 'TONSILLECT &/OR ADENOIDECT ONLY AGE >17', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('060', '03', 'TONSILLECT &/OR ADENOIDECT ONLY AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('061', '03', 'MYRINGOTOMY W TUBE INSERTION AGE >17', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('062', '03', 'MYRINGOTOMY W TUBE INSERTION AGE 0-17', 0, 1, '', '2', '06', 0, 999, 1, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('063', '03', 'OTHER EAR,NOSE,MOUTH & THROAT O.R. PROCS', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('064', '03', 'EAR, NOSE, MOUTH & THROAT MALIGNANCY', 1, 4, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('065', '03', 'DYSEQUILIBRIUM', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('066', '03', 'EPISTAXIS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('067', '03', 'EPIGLOTTITIS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('068', '03', 'OTITIS MEDIA & URI AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('069', '03', 'OTITIS MEDIA & URI AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('070', '03', 'OTITIS MEDIA & URI AGE 0-17', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('071', '03', 'LARYNGOTRACHEITIS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('072', '03', 'NASAL TRAUMA & DEFORMITY', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('073', '03', 'OTH EAR,NOSE,MOUTH & THROAT DX AGE >17', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('074', '03', 'OTH EAR,NOSE,MOUTH & THROAT DX AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('075', '04', 'MAJOR CHEST PROCEDURES', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('076', '04', 'OTHER RESP SYSTEM O.R. PROCEDURES W CC', 3, 9, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('077', '04', 'OTHER RESP SYSTEM O.R. PROCEDURES W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('078', '04', 'PULMONARY EMBOLISM', 1, 7, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('079', '04', 'RESP INFECT & INFLAM AGE >17 W CC', 2, 7, '', '1', '01', 0, 999, 9, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('080', '04', 'RESP INFECT & INFLAM AGE >17 W/O CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('081', '04', 'RESP INFECT & INFLAM AGE 0-17', 2, 6, '', '1', '06', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('082', '04', 'RESPIRATORY NEOPLASMS', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('083', '04', 'MAJOR CHEST TRAUMA W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('084', '04', 'MAJOR CHEST TRAUMA W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('085', '04', 'PLEURAL EFFUSION W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('086', '04', 'PLEURAL EFFUSION W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('087', '04', 'PULMONARY EDEMA & RESPIRATORY FAILURE', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('088', '04', 'CHRONIC OBSTRUCTIVE PULMONARY DISEASE', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('089', '04', 'SIMPLE PNEUMONIA & PLEURISY AGE >17 W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('090', '04', 'SIMPLE PNEUMONIA&PLEURISY AGE >17 W/O CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('091', '04', 'SIMPLE PNEUMONIA & PLEURISY AGE 0-17', 1, 4, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('092', '04', 'INTERSTITIAL LUNG DISEASE W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('093', '04', 'INTERSTITIAL LUNG DISEASE W/O CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('094', '04', 'PNEUMOTHORAX WITH CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('095', '04', 'PNEUMOTHORAX W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('096', '04', 'BRONCHITIS & ASTHMA AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('097', '04', 'BRONCHITIS & ASTHMA AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('098', '04', 'BRONCHITIS & ASTHMA AGE 0-17', 1, 2, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('099', '04', 'RESPIRATORY SIGNS & SYMPTOMS W CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('100', '04', 'RESPIRATORY SIGNS & SYMPTOMS W/O CC', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('101', '04', 'OTHER RESP SYSTEM DIAGNOSES W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('102', '04', 'OTHER RESP SYSTEM DIAGNOSES W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('103', '05', 'HEART TRANSPLANT', 17, 32, '', '2', '02', 0, 999, 48, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('104', '05', 'CARDIAC VALVE PROC WITH CARDIAC CATH', 7, 11, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('105', '05', 'CARDIAC VALVE PROC W/O CARDIAC CATH', 6, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('106', '05', 'CORONARY BYPASS WITH CARDIAC CATH', 6, 10, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('107', '05', 'CORONARY BYPASS W/O CARDIAC CATH', 4, 7, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('108', '05', 'OTHER CARDIOTHORACIC PROCEDURES', 6, 9, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('110', '05', 'MAJOR CARDIOVASCULAR PROCS WITH CC', 4, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('111', '05', 'MAJOR CARDIOVASCULAR PROCS W/O CC', 2, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('112', '05', 'PERCUTANEOUS CARDIOVASCULAR PROCEDURES', 2, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('113', '05', 'AMPUT FOR CIRC DISOR EXC UPPR LIMB & TOE', 3, 10, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('114', '05', 'UPPR LIMB & TOE AMPUT FOR CIRC DISOR', 2, 6, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('115', '05', 'PERM PACEMKR IMPL W AMI,HEART FAIL,SHCK', 4, 7, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('116', '05', 'OTH PERM CARD PACEMKR IMPL,AICD,GEN PROC', 3, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('117', '05', 'CARD PACEMKR REVISION EXC DEVICE REPLACE', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('118', '05', 'CARDIAC PACEMAKER DEVICE REPLACEMENT', 2, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('119', '05', 'VEIN LIGATION & STRIPPING', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('120', '05', 'OTHER CIRCULATORY SYSTEM O.R. PROCEDURES', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('121', '05', 'CIRC DISOR W AMI & CV COMP DISCH ALIVE', 2, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('122', '05', 'CIRC DISOR W AMI W/O CV COMP DISCH ALIVE', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('123', '05', 'CIRC DISOR W AMI, EXPIRED', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('124', '05', 'CIRC DIS EX AMI W CARD CATH & COMPLX DX', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('125', '05', 'CIRC DIS EX AMI W CARD CATH WO COMPLX DX', 1, 2, '', '1', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('126', '05', 'ACUTE & SUBACUTE ENDOCARDITIS', 2, 10, '', '1', '01', 0, 999, 13, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('127', '05', 'HEART FAILURE & SHOCK', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('128', '05', 'DEEP VEIN THROMBOPHLEBITIS', 1, 6, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('129', '05', 'CARDIAC ARREST, UNEXPLAINED', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('130', '05', 'PERIPHERAL VASCULAR DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('131', '05', 'PERIPHERAL VASCULAR DISORDERS W/O CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('132', '05', 'ATHEROSCLEROSIS W CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('133', '05', 'ATHEROSCLEROSIS W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('134', '05', 'HYPERTENSION', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('135', '05', 'CARD CONGEN & VALV DISOR AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('136', '05', 'CARD CONGEN & VALV DISOR AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('137', '05', 'CARD CONGEN & VALV DISOR AGE 0-17', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('138', '05', 'CARD ARRHYTHMIA & CONDUCTN DISOR W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('139', '05', 'CARD ARRHYTHMIA & CONDUCTN DISOR W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('140', '05', 'ANGINA PECTORIS', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('141', '05', 'SYNCOPE & COLLAPSE W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('142', '05', 'SYNCOPE & COLLAPSE W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('143', '05', 'CHEST PAIN', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('144', '05', 'OTH CIRCULATORY SYSTEM DIAGNOSES W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('145', '05', 'OTH CIRCULATORY SYSTEM DIAGNOSES W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('146', '06', 'RECTAL RESECTION W CC', 3, 9, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('147', '06', 'RECTAL RESECTION W/O CC', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('148', '06', 'MAJOR SMALL & LARGE BOWEL PROCS W CC', 3, 11, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('149', '06', 'MAJOR SMALL & LARGE BOWEL PROCS W/O CC', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('150', '06', 'PERITONEAL ADHESIOLYSIS W CC', 3, 9, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('151', '06', 'PERITONEAL ADHESIOLYSIS W/O CC', 1, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('152', '06', 'MINOR SMALL & LARGE BOWEL PROCS W CC', 2, 7, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('153', '06', 'MINOR SMALL & LARGE BOWEL PROCS W/O CC', 1, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('154', '06', 'STOMACH,ESOPH & DUOD PROC AGE >17 W CC', 4, 11, '', '2', '02', 0, 999, 14, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('155', '06', 'STOMACH,ESOPH & DUOD PROC AGE >17 W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('156', '06', 'STOMACH,ESOPH & DUOD PROC AGE 0-17', 1, 6, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('157', '06', 'ANAL & STOMAL PROCEDURES W CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('158', '06', 'ANAL & STOMAL PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('159', '06', 'HERNIA PROC EXC ING,FEMOR AGE >17 W CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('160', '06', 'HERNIA PROC EXC ING,FEMOR AGE >17 W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('161', '06', 'ING & FEMORAL HERNIA PROC AGE >17 W CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('162', '06', 'ING & FEMORAL HERNIA PROC AGE >17 W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('163', '06', 'HERNIA PROCEDURES AGE 0-17', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('164', '06', 'APPENDECTOMY W COMPLIC PRINC DX W CC', 2, 8, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('165', '06', 'APPENDECTOMY W COMPLIC PRINC DX W/O CC', 1, 5, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('166', '06', 'APPENDECTOMY W/O COMPLIC PRINC DX W CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('167', '06', 'APPENDECTOMY W/O COMPLIC PRINC DX W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('168', '03', 'MOUTH PROCEDURES W CC', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('169', '03', 'MOUTH PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('170', '06', 'OTHER DIGESTIVE SYSTEM O.R. PROCS W CC', 3, 8, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('171', '06', 'OTHER DIGESTIVE SYSTEM O.R. PROCS W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('172', '06', 'DIGESTIVE MALIGNANCY W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('173', '06', 'DIGESTIVE MALIGNANCY W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('174', '06', 'G.I. HEMORRHAGE W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('175', '06', 'G.I. HEMORRHAGE W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('176', '06', 'COMPLICATED PEPTIC ULCER', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('177', '06', 'UNCOMPLICATED PEPTIC ULCER W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('178', '06', 'UNCOMPLICATED PEPTIC ULCER W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('179', '06', 'INFLAMMATORY BOWEL DISEASE', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('180', '06', 'G.I. OBSTRUCTION W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('181', '06', 'G.I. OBSTRUCTION W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('182', '06', 'ESPHGITIS,GE,MISC DIG DIS AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('183', '06', 'ESPHGITIS,GE,MISC DIG DIS AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('184', '06', 'ESPHGITIS,GE,MISC DIG DIS AGE 0-17', 1, 3, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('185', '03', 'DENT,ORAL DIS EX EXTRACT,RESTOR AGE >17', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('186', '03', 'DENT,ORAL DIS EX EXTRACT,RESTOR AGE 0-17', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('187', '03', 'DENTAL EXTRACTIONS & RESTORATIONS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('188', '06', 'OTHER DIGESTIVE SYSTEM DX AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('189', '06', 'OTHER DIGESTIVE SYSTEM DX AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('190', '06', 'OTHER DIGESTIVE SYSTEM DX AGE 0-17', 1, 3, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('191', '07', 'PANCREAS,LIVER & SHUNT PROCEDURES W CC', 4, 11, '', '2', '02', 0, 999, 15, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('192', '07', 'PANCREAS,LIVER & SHUNT PROCEDURES W/O CC', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('193', '07', 'BIL PROC W CC, EX ONLY CHOLCYST W/WO CDE', 3, 11, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('194', '07', 'BIL PROC WO CC,EX ONLY CHOLCYST W/WO CDE', 2, 6, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('195', '07', 'CHOLECYSTECTOMY W C.D.E. W CC', 3, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('196', '07', 'CHOLECYSTECTOMY W C.D.E. W/O CC', 2, 6, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('197', '07', 'CHOLECYSTMY,EX LAPSCPC W/O C.D.E. W CC', 2, 7, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('198', '07', 'CHOLECYSTMY,EX LAPSCPC W/O C.D.E. W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('199', '07', 'HEPATOBIL DIAGNOSTIC PROC FOR MALIGNANCY', 2, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('200', '07', 'HEPATOBIL DIAGNOSTIC PROC FOR NON-MALIG', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('201', '07', 'OTHER HEPATOBIL OR PANCREAS O.R. PROC', 3, 11, '', '2', '02', 0, 999, 15, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('202', '07', 'CIRRHOSIS & ALCOHOLIC HEPATITIS', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('203', '07', 'MALIGNANCY OF HEPATOBIL SYST OR PANCREAS', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('204', '07', 'DISORDERS OF PANCREAS EXCEPT MALIGNANCY', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('205', '07', 'DISOR LIVER, EX MALIG,CIRR,ALC HEPA W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('206', '07', 'DISOR LIVER,EX MALIG,CIRR,ALC HEPA WO CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('207', '07', 'DISORDERS OF THE BILIARY TRACT W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('208', '07', 'DISORDERS OF THE BILIARY TRACT W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('209', '08', 'MAJ JOINT/LIMB REATTACH PROC, LOW EXTREM', 2, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('210', '08', 'HIP&FEMUR PROC,EX MAJ JNT,AGE >17 W CC', 2, 6, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('211', '08', 'HIP&FEMUR PROC,EX MAJ JNT,AGE >17 W/O CC', 1, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('212', '08', 'HIP&FEMUR PROC,EX MAJ JNT,AGE 0-17', 1, 4, '', '2', '06', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('213', '08', 'AMPUT FOR MUSCSKL SYST & CONN TISS DISOR', 2, 6, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('216', '08', 'BIOPSIES OF MUSCSKL SYST & CONN TISSUE', 2, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('217', '08', 'WND DBRD,SK GRFT EX HAND,MUSSKL,CONN TIS', 3, 9, '', '2', '02', 0, 999, 14, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('218', '08', 'LW EXT&HUM PROC,EX HIP,FT,FEM >17 W CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('219', '08', 'LW EXT&HUM PROC,EX HIP,FT,FEM >17 W/O CC', 1, 3, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('220', '08', 'LW EXT&HUM PROC,EX HIP,FT,FEM 0-17', 1, 5, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('223', '08', 'MAJ SHLDR/ELBOW,OTH UPPR EXTR PROC W CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('224', '08', 'SHLDR,ELBW,FOREARM PROC,EX MAJ JNT WO CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('225', '08', 'FOOT PROCEDURES', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('226', '08', 'SOFT TISSUE PROCEDURES W CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('227', '08', 'SOFT TISSUE PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('228', '08', 'MAJ THUMB/JOINT/OTH HAND/WRIST PROC W CC', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('229', '08', 'HAND/WRIST PROC,EXC MAJ JNT PROC,W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('230', '08', 'LOC EXCIS,REMOV INT FIX DEV HIP,FEMUR', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('231', '08', 'LOC EXCIS,REMOV INT FIX DEV EX HIP,FEMUR', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('232', '08', 'ARTHROSCOPY', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('233', '08', 'OTH MUSCSKL & CONN TISS O.R. PROC W CC', 2, 6, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('234', '08', 'OTH MUSCSKL & CONN TISS O.R. PROC W/O CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('235', '08', 'FRACTURES OF FEMUR', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('236', '08', 'FRACTURES OF HIP & PELVIS', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('237', '08', 'SPRAIN,STRAIN,DISLOC OF HIP,PELVIS,THIGH', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('238', '08', 'OSTEOMYELITIS', 1, 7, '', '1', '01', 0, 999, 10, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('239', '08', 'PATH FX & MUSCSKL & CONNECT TISSUE MALIG', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('240', '08', 'CONNECTIVE TISSUE DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('241', '08', 'CONNECTIVE TISSUE DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('242', '08', 'SEPTIC ARTHRITIS', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('243', '08', 'MEDICAL BACK PROBLEMS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('244', '08', 'BONE DIS & SPECIFIC ARTHROPATHIES W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('245', '08', 'BONE DIS & SPECIFIC ARTHROPATHIES W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('246', '08', 'NON-SPECIFIC ARTHROPATHIES', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('247', '08', 'SIGNS&SYMPTOMS OF MUSCSKL SYST&CONN TISS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('248', '08', 'TENDONITIS, MYOSITIS & BURSITIS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('249', '08', 'AFTERCARE, MUSCSKL SYST & CONN TISSUE', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('250', '08', 'FX,SPR,STR,DSL FRARM,HAND,FT >17 W CC', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('251', '08', 'FX,SPR,STR,DSL FRARM,HAND,FT >17 W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('252', '08', 'FX,SPR,STR,DSL FRARM,HAND,FT 0-17', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('253', '08', 'FX,SPR,STR,DSL UARM,LWLG EX FT >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('254', '08', 'FX,SPR,STR,DSL UARM,LWLG EX FT >17 WO CC', 0, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('255', '08', 'FX,SPR,STR,DSL UARM,LWLG EX FT 0-17', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('256', '08', 'OTHER MUSCSKL SYST & CONN TISS DIAGNOSES', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('257', '09', 'TOTAL MASTECTOMY FOR MALIGNANCY W CC', 1, 3, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('258', '09', 'TOTAL MASTECTOMY FOR MALIGNANCY W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('259', '09', 'SUBTOT MASTECTOMY FOR MALIGNANCY W CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('260', '09', 'SUBTOT MASTECTOMY FOR MALIGNANCY W/O CC', 1, 1, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('261', '09', 'BREAST PROC NON-MALIG,EX BIOP&LOC EXCIS', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('262', '09', 'BREAST BIOPSY & LOC EXCIS FOR NON-MALIG', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('263', '09', 'SKN GRFT/DEBRID,SKN ULCR,CELLULIT W CC', 2, 9, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('264', '09', 'SKN GRFT/DEBRID,SKN ULCR,CELLULIT W/O CC', 1, 5, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('265', '09', 'SKN GRFT/DEBRID,EX SKN ULCR,CELLUL W CC', 2, 5, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('266', '09', 'SKN GRFT/DEBRID,EX SKN ULCR,CELLUL WO CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('267', '09', 'PERIANAL & PILONIDAL PROCEDURES', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('268', '09', 'SKIN,SUBCUT TISSUE&BREAST PLASTIC PROC', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('269', '09', 'OTH SKIN,SUBCUT TISS&BREAST PROC W CC', 2, 6, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('270', '09', 'OTH SKIN,SUBCUT TISS&BREAST PROC W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('271', '09', 'SKIN ULCERS', 1, 6, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('272', '09', 'MAJOR SKIN DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('273', '09', 'MAJOR SKIN DISORDERS W/O CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('274', '09', 'MALIGNANT BREAST DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('275', '09', 'MALIGNANT BREAST DISORDERS W/O CC', 1, 2, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('276', '09', 'NON-MALIGNANT BREAST DISORDERS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('277', '09', 'CELLULITIS AGE >17 W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('278', '09', 'CELLULITIS AGE >17 W/O CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('279', '09', 'CELLULITIS AGE 0-17', 1, 4, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('280', '09', 'TRAUMA SKN,SUBCUT TIS&BREAST AGE>17 W CC', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('281', '09', 'TRAUMA SKN,SUBCU TIS&BREAST AGE>17 WO CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('282', '09', 'TRAUMA SKN,SUBCUT TISS&BREAST AGE 0-17', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('283', '09', 'MINOR SKIN DISORDERS W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('284', '09', 'MINOR SKIN DISORDERS W/O CC', 0, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('285', '10', 'AMPUT LOWR LIMB ENDOCR,NUTR,METAB DISOR', 2, 9, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('286', '10', 'ADRENAL & PITUITARY PROCEDURES', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('287', '10', 'SKN GRFT,WND DBRD ENDOC,NUTR,METAB DISOR', 2, 9, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('288', '10', 'O.R. PROCEDURES FOR OBESITY', 2, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('289', '10', 'PARATHYROID PROCEDURES', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('290', '10', 'THYROID PROCEDURES', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('291', '10', 'THYROGLOSSAL PROCEDURES', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('292', '10', 'OTH ENDOCR,NUTRIT,METAB O.R. PROC W CC', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('293', '10', 'OTH ENDOCR,NUTRIT,METAB O.R. PROC W/O CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('294', '10', 'DIABETES AGE >35', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('295', '10', 'DIABETES AGE 0-35', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('296', '10', 'NUTRIT & MISC METAB DISOR AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('297', '10', 'NUTRIT & MISC METAB DISOR AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('298', '10', 'NUTRIT & MISC METAB DISOR AGE 0-17', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('299', '10', 'INBORN ERRORS OF METABOLISM', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('300', '10', 'ENDOCRINE DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('301', '10', 'ENDOCRINE DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('302', '11', 'KIDNEY TRANSPLANT', 4, 9, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('303', '11', 'KIDNEY,URETR & MAJ BLADDR PROC FOR NEOPL', 3, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('304', '11', 'KIDNY,URETR&MAJ BLADDR PROC NONNEO W CC', 2, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('305', '11', 'KIDNY,URETR&MAJ BLADDR PROC NONNEO WO CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('306', '11', 'PROSTATECTOMY W CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('307', '11', 'PROSTATECTOMY W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('308', '11', 'MINOR BLADDER PROCEDURES W CC', 2, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('309', '11', 'MINOR BLADDER PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('310', '11', 'TRANSURETHRAL PROCEDURES W CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('311', '11', 'TRANSURETHRAL PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('312', '11', 'URETHRAL PROCEDURES, AGE >17 W CC', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('313', '11', 'URETHRAL PROCEDURES, AGE >17 W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('314', '11', 'URETHRAL PROCEDURES, AGE 0-17', 0, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('315', '11', 'OTHER KIDNEY & URINARY TRACT O.R. PROCS', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('316', '11', 'RENAL FAILURE', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('317', '11', 'ADMIT FOR RENAL DIALYSIS', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('318', '11', 'KIDNEY & URINARY TRACT NEOPLASMS W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('319', '11', 'KIDNEY & URINARY TRACT NEOPLASMS W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('320', '11', 'KIDNEY,URIN TRACT INFECT AGE >17 W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('321', '11', 'KIDNEY,URIN TRACT INFECT AGE >17 W/O CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('322', '11', 'KIDNEY,URIN TRACT INFECT AGE 0-17', 1, 3, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('323', '11', 'URINARY STONES W CC,&/OR ESW LITHOTRIPSY', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('324', '11', 'URINARY STONES W/O CC', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('325', '11', 'KIDNY,URIN TRACT SIGN,SYMP AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('326', '11', 'KIDNY,URIN TRACT SIGN,SYMP AGE >17 WO CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('327', '11', 'KIDNY,URIN TRACT SIGN,SYMP AGE 0-17', 0, 2, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('328', '11', 'URETHRAL STRICTURE AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('329', '11', 'URETHRAL STRICTURE AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('330', '11', 'URETHRAL STRICTURE AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('331', '11', 'OTH KIDNEY & URIN TRACT DX AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('332', '11', 'OTH KIDNEY & URIN TRACT DX AGE >17 WO CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('333', '11', 'OTH KIDNEY & URIN TRACT DX AGE 0-17', 1, 4, '', '1', '06', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('334', '12', 'MAJOR MALE PELVIC PROCEDURES W CC', 2, 5, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('335', '12', 'MAJOR MALE PELVIC PROCEDURES W/O CC', 1, 4, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('336', '12', 'TRANSURETHRAL PROSTATECTOMY W CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('337', '12', 'TRANSURETHRAL PROSTATECTOMY W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('338', '12', 'TESTES PROCEDURES, FOR MALIGNANCY', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('339', '12', 'TESTES PROCEDURES, NON-MALIG AGE >17', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('340', '12', 'TESTES PROCEDURES, NON-MALIG AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('341', '12', 'PENIS PROCEDURES', 1, 2, '', '2', '06', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('342', '12', 'CIRCUMCISION AGE >17', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('343', '12', 'CIRCUMCISION AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('344', '12', 'OTH MALE REPRO SYST O.R. PROCS FOR MALIG', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('345', '12', 'OTH MALE REPRO SYST O.R. PROCS EX MALIG', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('346', '12', 'MALIGNANCY, MALE REPRO SYSTEM, W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('347', '12', 'MALIGNANCY, MALE REPRO SYSTEM, W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('348', '12', 'BENIGN PROSTATIC HYPERTROPHY W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('349', '12', 'BENIGN PROSTATIC HYPERTROPHY W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('350', '12', 'INFLAMMATION OF THE MALE REPRO SYSTEM', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('351', '12', 'STERILIZATION, MALE', 0, 1, '', '1', '02', 0, 999, 1, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('352', '12', 'OTHER MALE REPRODUCTIVE SYSTEM DIAGNOSES', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('353', '13', 'PELVIC EVISC,RAD HYSTERECT & RAD VULVECT', 2, 6, '', '2', '05', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('354', '13', 'UTER,ADNEX PROC NON-OV/ADNEX MALIG W CC', 1, 5, '', '2', '05', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('355', '13', 'UTER,ADNEX PROC NON-OV/ADNEX MALIG WO CC', 1, 3, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('356', '13', 'FEMALE REPRO SYSTEM RECONSTRUCTIVE PROCS', 1, 2, '', '2', '05', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('357', '13', 'UTER&ADNEX PROC FOR OVAR,ADNEXAL MALIG', 2, 8, '', '2', '05', 0, 999, 9, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('358', '13', 'UTER&ADNEX PROC FOR NON-MALIG W CC', 1, 4, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('359', '13', 'UTER&ADNEX PROC FOR NON-MALIG W/O CC', 1, 3, '', '2', '05', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('360', '13', 'VAGINA, CERVIX & VULVA PROCEDURES', 1, 3, '', '2', '05', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('361', '13', 'LAPAROSCOPY & INCISIONAL TUBAL INTERRUPT', 1, 3, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('362', '13', 'ENDOSCOPIC TUBAL INTERRUPTION', 0, 1, '', '2', '05', 0, 999, 1, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('363', '13', 'D&C,CONIZATION&RADIO-IMPLANT, FOR MALIG', 1, 3, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('364', '13', 'D&C,CONIZATION EXCEPT FOR MALIGNANCY', 1, 2, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('365', '13', 'OTHER FEMALE REPRO SYSTEM O.R. PROC', 2, 5, '', '2', '05', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('366', '13', 'MALIGNANCY, FEMALE REPRO SYSTEM W CC', 1, 5, '', '1', '05', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('367', '13', 'MALIGNANCY, FEMALE REPRO SYSTEM W/O CC', 1, 2, '', '1', '05', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('368', '13', 'INFECTIONS, FEMALE REPRODUCTIVE SYSTEM', 1, 5, '', '1', '05', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('369', '13', 'MENSTRUAL&OTHER FEMALE REPRO SYST DISOR', 1, 2, '', '1', '05', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('370', '14', 'CESAREAN SECTION W CC', 1, 4, '', '2', '04', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('371', '14', 'CESAREAN SECTION W/O CC', 1, 3, '', '2', '04', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('372', '14', 'VAGINAL DELIVERY W COMPLIC DIAGNOSES', 1, 2, '', '1', '03', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('373', '14', 'VAGINAL DELIVERY W/O COMPLIC DIAGNOSES', 0, 2, '', '1', '03', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('374', '14', 'VAGINAL DELIVERY W STERIL &/OR D&C', 1, 2, '', '2', '03', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('375', '14', 'VAG DELIV W O.R. PROC EX STERIL &/OR D&C', 1, 4, '', '2', '03', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('376', '14', 'POSTPART & POST ABORT DX W/O O.R. PROC', 0, 2, '', '1', '03', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('377', '14', 'POSTPART & POST ABORT DX W O.R. PROC', 1, 2, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('378', '14', 'ECTOPIC PREGNANCY', 1, 2, '', '1', '05', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('379', '14', 'THREATENED ABORTION', 0, 2, '', '1', '05', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('380', '14', 'ABORTION W/O D&C', 0, 2, '', '1', '05', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('381', '14', 'ABORTION W D&C,ASPIR CURETT,HYSTEROTOMY', 0, 2, '', '2', '05', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('382', '14', 'FALSE LABOR', 0, 1, '', '1', '05', 0, 999, 1, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('383', '14', 'OTH ANTEPARTUM DX W MEDICAL COMPLIC', 0, 3, '', '1', '05', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('384', '14', 'OTH ANTEPARTUM DX W/O MEDICAL COMPLIC', 0, 2, '', '1', '05', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('385', '15', 'NEONATES,DIED OR TRANS ACUTE CARE FACIL', 1, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('386', '15', 'EXTREME IMMATUR,RESP DIST SYND,NEONATE', 5, 18, '', '1', '06', 0, 999, 18, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('387', '15', 'PREMATURITY W MAJOR PROBLEMS', 3, 13, '', '1', '06', 0, 999, 13, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('388', '15', 'PREMATURITY W/O MAJOR PROBLEMS', 2, 9, '', '1', '06', 0, 999, 9, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('389', '15', 'FULL TERM NEONATE W MAJOR PROBLEMS', 1, 5, '', '1', '06', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('390', '15', 'NEONATE W OTHER SIGNIFICANT PROBLEMS', 1, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('391', '15', 'NORMAL NEWBORN', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('392', '16', 'SPLENECTOMY AGE >17', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('393', '16', 'SPLENECTOMY AGE 0-17', 1, 9, '', '2', '06', 0, 999, 9, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('394', '16', 'OTH O.R PROC OF BLOOD&BLOOD FORM ORGANS', 2, 4, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('395', '16', 'RED BLOOD CELL DISORDERS AGE >17', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('396', '16', 'RED BLOOD CELL DISORDERS AGE 0-17', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('397', '16', 'COAGULATION DISORDERS', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('398', '16', 'RETICULOENDOTHELIAL & IMMUN DISOR W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('399', '16', 'RETICULOENDOTHELIAL & IMMUN DISOR W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('400', '17', 'LYMPHOMA & LEUKEMIA W MAJOR O.R. PROC', 3, 6, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('401', '17', 'LYMPHOMA&NONACU LEUK OTH O.R PROC W CC', 3, 8, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('402', '17', 'LYMPHOMA&NONACU LEUK OTH O.R PROC WO CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('403', '17', 'LYMPHOMA & NON-ACUTE LEUKEMIA W CC', 2, 6, '', '1', '01', 0, 999, 9, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('404', '17', 'LYMPHOMA & NON-ACUTE LEUKEMIA W/O CC', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('405', '17', 'ACUTE LEUKEMIA W/O MAJ O.R PROC AGE 0-17', 2, 5, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('406', '17', 'MYEL DIS/PRLY DIF NEO&MAJ O.R.PROC W CC', 3, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('407', '17', 'MYEL DIS,PRLY DIF NEO&MAJ O.R.PROC WO CC', 1, 4, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('408', '17', 'MYEL DIS,PRLY DIF NEO&OTH O.R.PROC', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('409', '17', 'RADIOTHERAPY', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('410', '17', 'CHEMOTHERAPY W/O ACUTE LUKEMIA AS SEC DX', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('411', '17', 'HISTORY OF MALIGNANCY W/O ENDOSCOPY', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('412', '17', 'HISTORY OF MALIGNANCY W ENDOSCOPY', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('413', '17', 'OTH MYEL DIS/POORLY DIFF NEOPL DX W CC', 1, 6, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('414', '17', 'OTH MYEL DIS/POORLY DIFF NEOPL DX WO CC', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('415', '18', 'O.R. PROC FOR INFECTIOUS & PARASITIC DIS', 4, 11, '', '2', '02', 0, 999, 15, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('416', '18', 'SEPTICEMIA AGE >17', 1, 6, '', '1', '06', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('417', '18', 'SEPTICEMIA AGE 0-17', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('418', '18', 'POSTOPERATIVE & POST-TRAUMATIC INFECTION', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('419', '18', 'FEVER OF UNKNOWN ORIGIN AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('420', '18', 'FEVER OF UNKNOWN ORIGIN AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('421', '18', 'VIRAL ILLNESS AGE >17', 1, 3, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('422', '18', 'VIRAL ILL&FEVER OF UNKNWN ORIG AGE 0-17', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('423', '18', 'OTH INFECTIOUS & PARASITIC DIS DIAGNOSES', 2, 6, '', '1', '02', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('424', '19', 'O.R PROC W PRINC DX OF MENTAL ILLNESS', 2, 10, '', '2', '07', 0, 999, 17, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('425', '19', 'ACU ADJ REACT&DISTURB PSYCHOSOCIAL DYSF', 1, 3, '', '1', '07', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('426', '19', 'DEPRESSIVE NEUROSES', 1, 4, '', '1', '07', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('427', '19', 'NEUROSES EXCEPT DEPRESSIVE', 1, 4, '', '1', '07', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('428', '19', 'DISORDERS OF PERSONALITY&IMPULSE CONTROL', 1, 5, '', '1', '07', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('429', '19', 'ORGANIC DISTURBANCES&MENTAL RETARDATION', 1, 5, '', '1', '07', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('430', '19', 'PSYCHOSES', 1, 6, '', '1', '07', 0, 999, 9, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('431', '19', 'CHILDHOOD MENTAL DISORDERS', 1, 6, '', '1', '07', 0, 999, 9, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('432', '19', 'OTHER MENTAL DISORDER DIAGNOSES', 1, 4, '', '1', '07', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('433', '20', 'ALCOHOL/DRUG ABUSE, DEPENDENCE, LEFT AMA', 0, 2, '', '1', '08', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('434', '20', 'ALC/DRG ABUSE,DEP, DETOX,OTH TREAT W CC', 1, 4, '', '1', '08', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('435', '20', 'ALC/DRG ABUSE,DEP, DETOX,OTH TREAT WO CC', 0, 4, '', '1', '08', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('436', '20', 'ALC/DRUG DEPENDENCE W REHAB THERAPY', 1, 12, '', '1', '08', 0, 999, 14, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('437', '20', 'ALC/DRUG DEP, COMB REHAB & DETOX THERAPY', 1, 8, '', '1', '08', 0, 999, 10, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('439', '21', 'SKIN GRAFTS FOR INJURIES', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('440', '21', 'WOUND DEBRIDEMENTS FOR INJURIES', 2, 6, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('441', '21', 'HAND PROCEDURES FOR INJURIES', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('442', '21', 'OTHER O.R PROCEDURES FOR INJURIES W CC', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('443', '21', 'OTHER O.R PROCEDURES FOR INJURIES W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('444', '21', 'TRAUMATIC INJURY AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('445', '21', 'TRAUMATIC INJURY AGE >17 W/O CC', 0, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('446', '21', 'TRAUMATIC INJURY AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('447', '21', 'ALLERGIC REACTIONS AGE >17', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('448', '21', 'ALLERGIC REACTIONS AGE 0-17', 0, 1, '', '1', '06', 0, 999, 1, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('449', '21', 'POISON&TOXIC EFFECTS DRUGS AGE >17 W CC', 1, 3, '', '1', '08', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('450', '21', 'POISON&TOXIC EFFECTS DRUGS AGE >17 WO CC', 0, 2, '', '1', '08', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('451', '21', 'POISON&TOXIC EFFECTS DRUGS AGE 0-17', 0, 2, '', '1', '08', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('452', '21', 'COMPLICATIONS OF TREATMENT W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('453', '21', 'COMPLICATIONS OF TREATMENT W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('454', '21', 'OTH INJURY,POISON&TOXIC EFFECT DX W CC', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('455', '21', 'OTH INJURY,POISON&TOXIC EFFECT DX W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('456', '22', 'BURNS,TRANS TO ANOTHER ACUTE CARE FACIL', 2, 4, '', '1', '09', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('457', '22', 'EXTENSIVE BURNS W/O O.R. PROCEDURE', 2, 2, '', '1', '09', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('458', '22', 'NON-EXTENSIVE BURNS W SKIN GRAFT', 4, 11, '', '2', '02', 0, 999, 16, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('459', '22', 'NON-EXT BURNS W WND DEBRID/OTH O.R PROC', 2, 6, '', '2', '09', 0, 999, 9, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('460', '22', 'NON-EXTENSIVE BURNS W/O O.R. PROCEDURE', 1, 4, '', '1', '09', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('461', '23', 'O.R. PROC W DX OTH CONTACT W HEALTH SERV', 1, 2, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('462', '23', 'REHABILITATION', 1, 10, '', '1', '09', 0, 999, 13, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('463', '23', 'SIGNS & SYMPTOMS W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('464', '23', 'SIGNS & SYMPTOMS W/O CC', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('465', '23', 'AFTERCARE W HIST MALIG AS SECONDARY DX', 1, 2, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('466', '23', 'AFTERCARE W/O HIST MALIG AS SECONDARY DX', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('467', '23', 'OTHER FACTORS INFLUENCING HEALTH STATUS', 0, 2, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('468', '00', 'EXTENS O.R. PROC UNRELATED TO PRINC DX', 4, 10, '', '0', '02', 0, 999, 14, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('469', '00', 'PRINC DX INVALID AS DISCHARGE DIAGNOSIS', 0, 0, '', '0', '01', 0, 999, 0, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('470', '00', 'UNGROUPABLE', 0, 0, '', '0', '', 0, 999, 0, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('471', '08', 'BILAT OR MULT MAJ JOINT PROC, LOW EXTREM', 3, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('472', '22', 'EXTENSIVE BURNS W O.R. PROCEDURE', 10, 12, '', '2', '09', 0, 999, 24, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('473', '17', 'ACU LEUKEMIA W/O MAJOR O.R PROC AGE >17', 3, 8, '', '1', '01', 0, 999, 14, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('475', '04', 'RESP SYSTEM DX WITH VENTILATOR SUPPORT', 4, 8, '', '1', '01', 0, 999, 12, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('476', '00', 'PROSTATIC O.R PROC UNRELATED TO PRINC DX', 2, 10, '', '0', '02', 0, 999, 13, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('477', '00', 'NON-EXTEN O.R PROC UNRELATED TO PRINC DX', 2, 6, '', '0', '02', 0, 999, 9, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('478', '05', 'OTHER VASCULAR PROCEDURES W CC', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('479', '05', 'OTHER VASCULAR PROCEDURES W/O CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('480', '00', 'LIVER TRANSPLANT', 11, 19, '', '2', '02', 0, 999, 25, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('481', '00', 'BONE MARROW TRANSPLANT', 11, 26, '', '2', '02', 0, 999, 30, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('482', '00', 'TRACHMY FOR FACE,MOUTH AND NECK DIAG', 4, 10, '', '2', '02', 0, 999, 14, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('483', '00', 'TRACHMY EX FACE,MOUTH AND NECK DIAG', 16, 34, '', '2', '02', 0, 999, 44, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('484', '24', 'CRANIOTOMY, MULTIPLE SIGNIFICANT TRAUMA', 6, 11, '', '2', '02', 0, 999, 15, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('485', '24', 'LIMB REATTACH,HIP&FEMUR,MULT SIGN TRAUMA', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('486', '24', 'OTHER O.R. PROC FOR MULTI SIGN TRAUMA', 5, 9, '', '2', '02', 0, 999, 14, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('487', '24', 'OTHER MULTIPLE SIGNIFICANT TRAUMA', 2, 6, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('488', '25', 'HIV W EXTENSIVE O.R. PROCEDURE', 5, 12, '', '2', '02', 0, 999, 18, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('489', '25', 'HIV W MAJOR RELATED CONDITION', 2, 7, '', '1', '01', 0, 999, 10, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('490', '25', 'HIV W OR W/O OTHER RELATED CONDITION', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('491', '08', 'MAJ JOINT/LIMB REATTACH PROC, UPP EXTREM', 2, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('492', '17', 'CHEMOTHERAPY W ACUTE LUKEMIA AS SEC DX', 5, 12, '', '1', '01', 0, 999, 18, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('493', '07', 'LAPAROSCOPIC CHOLECYSTECT W/O CDE W CC', 2, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('494', '07', 'LAPAROSCOPIC CHOLECYSTECT W/O CDE W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('495', '00', 'LUNG TRANSPLANT', 10, 15, '', '2', '02', 0, 999, 18, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('496', '08', 'COMB ANTERIOR/POSTERIOR SPINAL FUSION', 6, 9, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('497', '08', 'SPINAL FUSION W CC', 3, 5, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('498', '08', 'SPINAL FUSION W/O CC', 2, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('499', '08', 'BACK & NECK PROC EXC SPINAL FUSION W CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('500', '08', 'BACK & NECK PROC EXC SPINAL FUSION WO CC', 1, 3, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('501', '08', 'KNEE PROC W PDX OF INFECTION W CC', 3, 9, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('502', '08', 'KNEE PROC W PDX OF INFECTION W/O CC', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('503', '08', 'KNEE PROCEDURES W/O PDX OF INFECTION', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'F')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('001', '01', 'CRANIOTOMY AGE >17 EXCEPT FOR TRAUMA', 3, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('002', '01', 'CRANIOTOMY FOR TRAUMA AGE >17', 3, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('003', '01', 'CRANIOTOMY AGE 0-17', 2, 13, '', '2', '06', 0, 999, 13, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('004', '01', 'SPINAL PROCEDURES', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('005', '01', 'EXTRACRANIAL VASCULAR PROCEDURES', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('006', '01', 'CARPAL TUNNEL RELEASE', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('007', '01', 'PERIPH&CRAN NERV&OTH NERV SYS PROC W CC', 2, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('008', '01', 'PERIPH&CRAN NERV&OTH NERV SYS PROC WO CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('009', '01', 'SPINAL DISORDERS & INJURIES', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('010', '01', 'NERVOUS SYSTEM NEOPLASMS W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('011', '01', 'NERVOUS SYSTEM NEOPLASMS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('012', '01', 'DEGENERATIVE NERVOUS SYSTEM DISORDERS', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('013', '01', 'MULTIPLE SCLEROSIS & CEREBELLAR ATAXIA', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('014', '01', 'SPECIFIC CEREBROVASC DISORDERS EXC TIA', 1, 5, '', '1', '01', 0, 999, 6, '1', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('015', '01', 'TIA AND PRECEREBRAL OCCLUSIONS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('016', '01', 'NONSPECIFIC CEREBROVASC DISORDERS W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('017', '01', 'NONSPECIFIC CEREBROVASC DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('018', '01', 'CRANIAL & PERIPH NERVE DISORDERS W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('019', '01', 'CRANIAL & PERIPH NERVE DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('020', '01', 'NERV SYSTEM INFECT EXC VIRAL MENINGITIS', 3, 8, '', '1', '01', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('021', '01', 'VIRAL MENINGITIS', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('022', '01', 'HYPERTENSIVE ENCEPHALOPATHY', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('023', '01', 'NONTRAUMATIC STUPOR & COMA', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('024', '01', 'SEIZURE & HEADACHE AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('025', '01', 'SEIZURE & HEADACHE AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('026', '01', 'SEIZURE & HEADACHE AGE 0-17', 1, 2, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('027', '01', 'TRAUMATIC STUPOR & COMA,COMA >1 HR', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('028', '01', 'TRAUM STUPOR&COMA,COMA<1 HR,AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('029', '01', 'TRAUM STUPOR&COMA,COMA<1HR,AGE>17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('030', '01', 'TRAUM STUPOR & COMA,COMA <1 HR,AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('031', '01', 'CONCUSSION AGE >17 WITH CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('032', '01', 'CONCUSSION AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('033', '01', 'CONCUSSION AGE 0-17', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('034', '01', 'OTHER DISORDERS OF NERVOUS SYSTEM W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('035', '01', 'OTHER DISORDERS OF NERVOUS SYSTEM W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('036', '02', 'RETINAL PROCEDURES', 1, 1, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('037', '02', 'ORBITAL PROCEDURES', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('038', '02', 'PRIMARY IRIS PROCEDURES', 0, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('039', '02', 'LENS PROCEDURES WITH OR W/O VITRECTOMY', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('040', '02', 'EXTRAOCULAR PROCS EXCEPT ORBIT AGE >17', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('041', '02', 'EXTRAOCULAR PROCS EXCEPT ORBIT AGE 0-17', 0, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('042', '02', 'INTRAOCULAR PROCS EXC RETINA,IRIS & LENS', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('043', '02', 'HYPHEMA', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('044', '02', 'ACUTE MAJOR EYE INFECTIONS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('045', '02', 'NEUROLOGICAL EYE DISORDERS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('046', '02', 'OTHER DISORDERS OF THE EYE AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('047', '02', 'OTHER DISORDERS OF THE EYE AGE>17 W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('048', '02', 'OTHER DISORDERS OF THE EYE AGE 0-17', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('049', '03', 'MAJOR HEAD & NECK PROCEDURES', 2, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('050', '03', 'SIALOADENECTOMY', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('051', '03', 'SALIVARY GLAND PROCS EXC SIALOADENECTOMY', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('052', '03', 'CLEFT LIP & PALATE REPAIR', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('053', '03', 'SINUS & MASTOID PROCEDURES AGE >17', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('054', '03', 'SINUS & MASTOID PROCEDURES AGE 0-17', 0, 3, '', '2', '06', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('055', '03', 'MISC EAR,NOSE,MOUTH & THROAT PROCEDURES', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('056', '03', 'RHINOPLASTY', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('057', '03', 'T&A PROC,EX TONSLCT/ADNDCT ONLY AGE >17', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('058', '03', 'T&A PROC,EX TONSLCT/ADNDCT ONLY AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('059', '03', 'TONSILLECT &/OR ADENOIDECT ONLY AGE >17', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('060', '03', 'TONSILLECT &/OR ADENOIDECT ONLY AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('061', '03', 'MYRINGOTOMY W TUBE INSERTION AGE >17', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('062', '03', 'MYRINGOTOMY W TUBE INSERTION AGE 0-17', 0, 1, '', '2', '06', 0, 999, 1, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('063', '03', 'OTHER EAR,NOSE,MOUTH & THROAT O.R. PROCS', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('064', '03', 'EAR, NOSE, MOUTH & THROAT MALIGNANCY', 1, 4, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('065', '03', 'DYSEQUILIBRIUM', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('066', '03', 'EPISTAXIS', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('067', '03', 'EPIGLOTTITIS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('068', '03', 'OTITIS MEDIA & URI AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('069', '03', 'OTITIS MEDIA & URI AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('070', '03', 'OTITIS MEDIA & URI AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('071', '03', 'LARYNGOTRACHEITIS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('072', '03', 'NASAL TRAUMA & DEFORMITY', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('073', '03', 'OTH EAR,NOSE,MOUTH & THROAT DX AGE >17', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('074', '03', 'OTH EAR,NOSE,MOUTH & THROAT DX AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('075', '04', 'MAJOR CHEST PROCEDURES', 3, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('076', '04', 'OTHER RESP SYSTEM O.R. PROCEDURES W CC', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('077', '04', 'OTHER RESP SYSTEM O.R. PROCEDURES W/O CC', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('078', '04', 'PULMONARY EMBOLISM', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('079', '04', 'RESP INFECT & INFLAM AGE >17 W CC', 2, 7, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('080', '04', 'RESP INFECT & INFLAM AGE >17 W/O CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('081', '04', 'RESP INFECT & INFLAM AGE 0-17', 2, 6, '', '1', '06', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('082', '04', 'RESPIRATORY NEOPLASMS', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('083', '04', 'MAJOR CHEST TRAUMA W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('084', '04', 'MAJOR CHEST TRAUMA W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('085', '04', 'PLEURAL EFFUSION W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('086', '04', 'PLEURAL EFFUSION W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('087', '04', 'PULMONARY EDEMA & RESPIRATORY FAILURE', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('088', '04', 'CHRONIC OBSTRUCTIVE PULMONARY DISEASE', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('089', '04', 'SIMPLE PNEUMONIA & PLEURISY AGE >17 W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('090', '04', 'SIMPLE PNEUMONIA&PLEURISY AGE >17 W/O CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('091', '04', 'SIMPLE PNEUMONIA & PLEURISY AGE 0-17', 1, 3, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('092', '04', 'INTERSTITIAL LUNG DISEASE W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('093', '04', 'INTERSTITIAL LUNG DISEASE W/O CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('094', '04', 'PNEUMOTHORAX WITH CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('095', '04', 'PNEUMOTHORAX W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('096', '04', 'BRONCHITIS & ASTHMA AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('097', '04', 'BRONCHITIS & ASTHMA AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('098', '04', 'BRONCHITIS & ASTHMA AGE 0-17', 1, 4, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('099', '04', 'RESPIRATORY SIGNS & SYMPTOMS W CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('100', '04', 'RESPIRATORY SIGNS & SYMPTOMS W/O CC', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('101', '04', 'OTHER RESP SYSTEM DIAGNOSES W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('102', '04', 'OTHER RESP SYSTEM DIAGNOSES W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('103', '05', 'HEART TRANSPLANT', 18, 32, '', '2', '02', 0, 999, 50, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('104', '05', 'CARD VALVE OTH MAJ CARDTHOR PROC W CATH', 7, 10, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('105', '05', 'CARD VALVE OTH MAJ CARDTHOR PROC WO CATH', 6, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('106', '05', 'CORONARY BYPASS WITH PTCA', 7, 9, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('107', '05', 'CORONARY BYPASS W CARDIAC CATH', 6, 10, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('108', '05', 'OTHER CARDIOTHORACIC PROCEDURES', 6, 9, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('109', '05', 'CORONARY BYPASS W/O CARDIAC CATH', 4, 7, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('110', '05', 'MAJOR CARDIOVASCULAR PROCS WITH CC', 4, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('111', '05', 'MAJOR CARDIOVASCULAR PROCS W/O CC', 2, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('112', '05', 'PERCUTANEOUS CARDIOVASCULAR PROCEDURES', 2, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('113', '05', 'AMPUT FOR CIRC DISOR EXC UPPR LIMB & TOE', 3, 10, '', '2', '02', 0, 999, 13, '1', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('114', '05', 'UPPR LIMB & TOE AMPUT FOR CIRC DISOR', 2, 6, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('115', '05', 'PERM PACE IMP W AMI,HEART FAIL,SHCK,AICD', 4, 6, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('116', '05', 'OTH PERM CARD PACEMKR IMPL,PTCA W STENT', 2, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('117', '05', 'CARD PACEMKR REVISION EXC DEVICE REPLACE', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('118', '05', 'CARDIAC PACEMAKER DEVICE REPLACEMENT', 2, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('119', '05', 'VEIN LIGATION & STRIPPING', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('120', '05', 'OTHER CIRCULATORY SYSTEM O.R. PROCEDURES', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('121', '05', 'CIRC DISOR W AMI & MAJ COMP DISCH ALIVE', 2, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('122', '05', 'CIRC DISOR W AMI WO MAJ COMP DISCH ALIVE', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('123', '05', 'CIRC DISOR W AMI, EXPIRED', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('124', '05', 'CIRC DIS EX AMI W CARD CATH & COMPLX DX', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('125', '05', 'CIRC DIS EX AMI W CARD CATH WO COMPLX DX', 1, 2, '', '1', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('126', '05', 'ACUTE & SUBACUTE ENDOCARDITIS', 3, 10, '', '1', '01', 0, 999, 13, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('127', '05', 'HEART FAILURE & SHOCK', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('128', '05', 'DEEP VEIN THROMBOPHLEBITIS', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('129', '05', 'CARDIAC ARREST, UNEXPLAINED', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('130', '05', 'PERIPHERAL VASCULAR DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('131', '05', 'PERIPHERAL VASCULAR DISORDERS W/O CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('132', '05', 'ATHEROSCLEROSIS W CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('133', '05', 'ATHEROSCLEROSIS W/O CC', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('134', '05', 'HYPERTENSION', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('135', '05', 'CARD CONGEN & VALV DISOR AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('136', '05', 'CARD CONGEN & VALV DISOR AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('137', '05', 'CARD CONGEN & VALV DISOR AGE 0-17', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('138', '05', 'CARD ARRHYTHMIA & CONDUCTN DISOR W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('139', '05', 'CARD ARRHYTHMIA & CONDUCTN DISOR W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('140', '05', 'ANGINA PECTORIS', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('141', '05', 'SYNCOPE & COLLAPSE W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('142', '05', 'SYNCOPE & COLLAPSE W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('143', '05', 'CHEST PAIN', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('144', '05', 'OTH CIRCULATORY SYSTEM DIAGNOSES W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('145', '05', 'OTH CIRCULATORY SYSTEM DIAGNOSES W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('146', '06', 'RECTAL RESECTION W CC', 3, 9, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('147', '06', 'RECTAL RESECTION W/O CC', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('148', '06', 'MAJOR SMALL & LARGE BOWEL PROCS W CC', 3, 10, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('149', '06', 'MAJOR SMALL & LARGE BOWEL PROCS W/O CC', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('150', '06', 'PERITONEAL ADHESIOLYSIS W CC', 3, 9, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('151', '06', 'PERITONEAL ADHESIOLYSIS W/O CC', 1, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('152', '06', 'MINOR SMALL & LARGE BOWEL PROCS W CC', 2, 7, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('153', '06', 'MINOR SMALL & LARGE BOWEL PROCS W/O CC', 1, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('154', '06', 'STOMACH,ESOPH & DUOD PROC AGE >17 W CC', 4, 10, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('155', '06', 'STOMACH,ESOPH & DUOD PROC AGE >17 W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('156', '06', 'STOMACH,ESOPH & DUOD PROC AGE 0-17', 1, 6, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('157', '06', 'ANAL & STOMAL PROCEDURES W CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('158', '06', 'ANAL & STOMAL PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('159', '06', 'HERNIA PROC EXC ING,FEMOR AGE >17 W CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('160', '06', 'HERNIA PROC EXC ING,FEMOR AGE >17 W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('161', '06', 'ING & FEMORAL HERNIA PROC AGE >17 W CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('162', '06', 'ING & FEMORAL HERNIA PROC AGE >17 W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('163', '06', 'HERNIA PROCEDURES AGE 0-17', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('164', '06', 'APPENDECTOMY W COMPLIC PRINC DX W CC', 2, 7, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('165', '06', 'APPENDECTOMY W COMPLIC PRINC DX W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('166', '06', 'APPENDECTOMY W/O COMPLIC PRINC DX W CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('167', '06', 'APPENDECTOMY W/O COMPLIC PRINC DX W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('168', '03', 'MOUTH PROCEDURES W CC', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('169', '03', 'MOUTH PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('170', '06', 'OTHER DIGESTIVE SYSTEM O.R. PROCS W CC', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('171', '06', 'OTHER DIGESTIVE SYSTEM O.R. PROCS W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('172', '06', 'DIGESTIVE MALIGNANCY W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('173', '06', 'DIGESTIVE MALIGNANCY W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('174', '06', 'G.I. HEMORRHAGE W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('175', '06', 'G.I. HEMORRHAGE W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('176', '06', 'COMPLICATED PEPTIC ULCER', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('177', '06', 'UNCOMPLICATED PEPTIC ULCER W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('178', '06', 'UNCOMPLICATED PEPTIC ULCER W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('179', '06', 'INFLAMMATORY BOWEL DISEASE', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('180', '06', 'G.I. OBSTRUCTION W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('181', '06', 'G.I. OBSTRUCTION W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('182', '06', 'ESPHGITIS,GE,MISC DIG DIS AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('183', '06', 'ESPHGITIS,GE,MISC DIG DIS AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('184', '06', 'ESPHGITIS,GE,MISC DIG DIS AGE 0-17', 1, 2, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('185', '03', 'DENT,ORAL DIS EX EXTRACT,RESTOR AGE >17', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('186', '03', 'DENT,ORAL DIS EX EXTRACT,RESTOR AGE 0-17', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('187', '03', 'DENTAL EXTRACTIONS & RESTORATIONS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('188', '06', 'OTHER DIGESTIVE SYSTEM DX AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('189', '06', 'OTHER DIGESTIVE SYSTEM DX AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('190', '06', 'OTHER DIGESTIVE SYSTEM DX AGE 0-17', 1, 4, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('191', '07', 'PANCREAS,LIVER & SHUNT PROCEDURES W CC', 4, 11, '', '2', '02', 0, 999, 15, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('192', '07', 'PANCREAS,LIVER & SHUNT PROCEDURES W/O CC', 2, 5, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('193', '07', 'BIL PROC W CC, EX ONLY CHOLCYST W/WO CDE', 3, 10, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('194', '07', 'BIL PROC WO CC,EX ONLY CHOLCYST W/WO CDE', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('195', '07', 'CHOLECYSTECTOMY W C.D.E. W CC', 3, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('196', '07', 'CHOLECYSTECTOMY W C.D.E. W/O CC', 2, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('197', '07', 'CHOLECYSTMY,EX LAPSCPC W/O C.D.E. W CC', 2, 7, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('198', '07', 'CHOLECYSTMY,EX LAPSCPC W/O C.D.E. W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('199', '07', 'HEPATOBIL DIAGNOSTIC PROC FOR MALIGNANCY', 2, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('200', '07', 'HEPATOBIL DIAGNOSTIC PROC FOR NON-MALIG', 3, 7, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('201', '07', 'OTHER HEPATOBIL OR PANCREAS O.R. PROC', 4, 10, '', '2', '02', 0, 999, 14, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('202', '07', 'CIRRHOSIS & ALCOHOLIC HEPATITIS', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('203', '07', 'MALIGNANCY OF HEPATOBIL SYST OR PANCREAS', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('204', '07', 'DISORDERS OF PANCREAS EXCEPT MALIGNANCY', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('205', '07', 'DISOR LIVER, EX MALIG,CIRR,ALC HEPA W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('206', '07', 'DISOR LIVER,EX MALIG,CIRR,ALC HEPA WO CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('207', '07', 'DISORDERS OF THE BILIARY TRACT W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('208', '07', 'DISORDERS OF THE BILIARY TRACT W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('209', '08', 'MAJ JOINT/LIMB REATTACH PROC, LOW EXTREM', 2, 5, '', '2', '02', 0, 999, 6, '2', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('210', '08', 'HIP&FEMUR PROC,EX MAJ JNT,AGE >17 W CC', 2, 6, '', '2', '02', 0, 999, 7, '2', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('211', '08', 'HIP&FEMUR PROC,EX MAJ JNT,AGE >17 W/O CC', 1, 5, '', '2', '02', 0, 999, 5, '2', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('212', '08', 'HIP&FEMUR PROC,EX MAJ JNT,AGE 0-17', 1, 3, '', '2', '06', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('213', '08', 'AMPUT FOR MUSCSKL SYST & CONN TISS DISOR', 2, 6, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('216', '08', 'BIOPSIES OF MUSCSKL SYST & CONN TISSUE', 2, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('217', '08', 'WND DBRD,SK GRFT EX HAND,MUSSKL,CONN TIS', 3, 9, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('218', '08', 'LW EXT&HUM PROC,EX HIP,FT,FEM >17 W CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('219', '08', 'LW EXT&HUM PROC,EX HIP,FT,FEM >17 W/O CC', 1, 3, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('220', '08', 'LW EXT&HUM PROC,EX HIP,FT,FEM 0-17', 1, 5, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('223', '08', 'MAJ SHLDR/ELBOW,OTH UPPR EXTR PROC W CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('224', '08', 'SHLDR,ELBW,FOREARM PROC,EX MAJ JNT WO CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('225', '08', 'FOOT PROCEDURES', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('226', '08', 'SOFT TISSUE PROCEDURES W CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('227', '08', 'SOFT TISSUE PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('228', '08', 'MAJ THUMB/JOINT/OTH HAND/WRIST PROC W CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('229', '08', 'HAND/WRIST PROC,EXC MAJ JNT PROC,W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('230', '08', 'LOC EXCIS,REMOV INT FIX DEV HIP,FEMUR', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('231', '08', 'LOC EXCIS,REMOV INT FIX DEV EX HIP,FEMUR', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('232', '08', 'ARTHROSCOPY', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('233', '08', 'OTH MUSCSKL & CONN TISS O.R. PROC W CC', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('234', '08', 'OTH MUSCSKL & CONN TISS O.R. PROC W/O CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('235', '08', 'FRACTURES OF FEMUR', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('236', '08', 'FRACTURES OF HIP & PELVIS', 1, 4, '', '1', '01', 0, 999, 5, '1', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('237', '08', 'SPRAIN,STRAIN,DISLOC OF HIP,PELVIS,THIGH', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('238', '08', 'OSTEOMYELITIS', 1, 7, '', '1', '01', 0, 999, 9, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('239', '08', 'PATH FX & MUSCSKL & CONNECT TISSUE MALIG', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('240', '08', 'CONNECTIVE TISSUE DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('241', '08', 'CONNECTIVE TISSUE DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('242', '08', 'SEPTIC ARTHRITIS', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('243', '08', 'MEDICAL BACK PROBLEMS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('244', '08', 'BONE DIS & SPECIFIC ARTHROPATHIES W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('245', '08', 'BONE DIS & SPECIFIC ARTHROPATHIES W/O CC', 0, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('246', '08', 'NON-SPECIFIC ARTHROPATHIES', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('247', '08', 'SIGNS&SYMPTOMS OF MUSCSKL SYST&CONN TISS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('248', '08', 'TENDONITIS, MYOSITIS & BURSITIS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('249', '08', 'AFTERCARE, MUSCSKL SYST & CONN TISSUE', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('250', '08', 'FX,SPR,STR,DSL FRARM,HAND,FT >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('251', '08', 'FX,SPR,STR,DSL FRARM,HAND,FT >17 W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('252', '08', 'FX,SPR,STR,DSL FRARM,HAND,FT 0-17', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('253', '08', 'FX,SPR,STR,DSL UARM,LWLG EX FT >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('254', '08', 'FX,SPR,STR,DSL UARM,LWLG EX FT >17 WO CC', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('255', '08', 'FX,SPR,STR,DSL UARM,LWLG EX FT 0-17', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('256', '08', 'OTHER MUSCSKL SYST & CONN TISS DIAGNOSES', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('257', '09', 'TOTAL MASTECTOMY FOR MALIGNANCY W CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('258', '09', 'TOTAL MASTECTOMY FOR MALIGNANCY W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('259', '09', 'SUBTOT MASTECTOMY FOR MALIGNANCY W CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('260', '09', 'SUBTOT MASTECTOMY FOR MALIGNANCY W/O CC', 1, 1, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('261', '09', 'BREAST PROC NON-MALIG,EX BIOP&LOC EXCIS', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('262', '09', 'BREAST BIOPSY & LOC EXCIS FOR NON-MALIG', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('263', '09', 'SKN GRFT/DEBRID,SKN ULCR,CELLULIT W CC', 2, 9, '', '2', '02', 0, 999, 12, '1', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('264', '09', 'SKN GRFT/DEBRID,SKN ULCR,CELLULIT W/O CC', 1, 5, '', '2', '02', 0, 999, 7, '1', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('265', '09', 'SKN GRFT/DEBRID,EX SKN ULCR,CELLUL W CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('266', '09', 'SKN GRFT/DEBRID,EX SKN ULCR,CELLUL WO CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('267', '09', 'PERIANAL & PILONIDAL PROCEDURES', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('268', '09', 'SKIN,SUBCUT TISSUE&BREAST PLASTIC PROC', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('269', '09', 'OTH SKIN,SUBCUT TISS&BREAST PROC W CC', 2, 6, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('270', '09', 'OTH SKIN,SUBCUT TISS&BREAST PROC W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('271', '09', 'SKIN ULCERS', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('272', '09', 'MAJOR SKIN DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('273', '09', 'MAJOR SKIN DISORDERS W/O CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('274', '09', 'MALIGNANT BREAST DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('275', '09', 'MALIGNANT BREAST DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('276', '09', 'NON-MALIGNANT BREAST DISORDERS', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('277', '09', 'CELLULITIS AGE >17 W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('278', '09', 'CELLULITIS AGE >17 W/O CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('279', '09', 'CELLULITIS AGE 0-17', 1, 4, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('280', '09', 'TRAUMA SKN,SUBCUT TIS&BREAST AGE>17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('281', '09', 'TRAUMA SKN,SUBCU TIS&BREAST AGE>17 WO CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('282', '09', 'TRAUMA SKN,SUBCUT TISS&BREAST AGE 0-17', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('283', '09', 'MINOR SKIN DISORDERS W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('284', '09', 'MINOR SKIN DISORDERS W/O CC', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('285', '10', 'AMPUT LOWR LIMB ENDOCR,NUTR,METAB DISOR', 2, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('286', '10', 'ADRENAL & PITUITARY PROCEDURES', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('287', '10', 'SKN GRFT,WND DBRD ENDOC,NUTR,METAB DISOR', 2, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('288', '10', 'O.R. PROCEDURES FOR OBESITY', 2, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('289', '10', 'PARATHYROID PROCEDURES', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('290', '10', 'THYROID PROCEDURES', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('291', '10', 'THYROGLOSSAL PROCEDURES', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('292', '10', 'OTH ENDOCR,NUTRIT,METAB O.R. PROC W CC', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('293', '10', 'OTH ENDOCR,NUTRIT,METAB O.R. PROC W/O CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('294', '10', 'DIABETES AGE >35', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('295', '10', 'DIABETES AGE 0-35', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('296', '10', 'NUTRIT & MISC METAB DISOR AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('297', '10', 'NUTRIT & MISC METAB DISOR AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('298', '10', 'NUTRIT & MISC METAB DISOR AGE 0-17', 1, 2, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('299', '10', 'INBORN ERRORS OF METABOLISM', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('300', '10', 'ENDOCRINE DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('301', '10', 'ENDOCRINE DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('302', '11', 'KIDNEY TRANSPLANT', 4, 9, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('303', '11', 'KIDNEY,URETR & MAJ BLADDR PROC FOR NEOPL', 3, 8, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('304', '11', 'KIDNY,URETR&MAJ BLADDR PROC NONNEO W CC', 2, 6, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('305', '11', 'KIDNY,URETR&MAJ BLADDR PROC NONNEO WO CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('306', '11', 'PROSTATECTOMY W CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('307', '11', 'PROSTATECTOMY W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('308', '11', 'MINOR BLADDER PROCEDURES W CC', 2, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('309', '11', 'MINOR BLADDER PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('310', '11', 'TRANSURETHRAL PROCEDURES W CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('311', '11', 'TRANSURETHRAL PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('312', '11', 'URETHRAL PROCEDURES, AGE >17 W CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('313', '11', 'URETHRAL PROCEDURES, AGE >17 W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('314', '11', 'URETHRAL PROCEDURES, AGE 0-17', 0, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('315', '11', 'OTHER KIDNEY & URINARY TRACT O.R. PROCS', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('316', '11', 'RENAL FAILURE', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('317', '11', 'ADMIT FOR RENAL DIALYSIS', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('318', '11', 'KIDNEY & URINARY TRACT NEOPLASMS W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('319', '11', 'KIDNEY & URINARY TRACT NEOPLASMS W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('320', '11', 'KIDNEY,URIN TRACT INFECT AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('321', '11', 'KIDNEY,URIN TRACT INFECT AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('322', '11', 'KIDNEY,URIN TRACT INFECT AGE 0-17', 1, 3, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('323', '11', 'URINARY STONES W CC,&/OR ESW LITHOTRIPSY', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('324', '11', 'URINARY STONES W/O CC', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('325', '11', 'KIDNY,URIN TRACT SIGN,SYMP AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('326', '11', 'KIDNY,URIN TRACT SIGN,SYMP AGE >17 WO CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('327', '11', 'KIDNY,URIN TRACT SIGN,SYMP AGE 0-17', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('328', '11', 'URETHRAL STRICTURE AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('329', '11', 'URETHRAL STRICTURE AGE >17 W/O CC', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('330', '11', 'URETHRAL STRICTURE AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('331', '11', 'OTH KIDNEY & URIN TRACT DX AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('332', '11', 'OTH KIDNEY & URIN TRACT DX AGE >17 WO CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('333', '11', 'OTH KIDNEY & URIN TRACT DX AGE 0-17', 1, 4, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('334', '12', 'MAJOR MALE PELVIC PROCEDURES W CC', 2, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('335', '12', 'MAJOR MALE PELVIC PROCEDURES W/O CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('336', '12', 'TRANSURETHRAL PROSTATECTOMY W CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('337', '12', 'TRANSURETHRAL PROSTATECTOMY W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('338', '12', 'TESTES PROCEDURES, FOR MALIGNANCY', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('339', '12', 'TESTES PROCEDURES, NON-MALIG AGE >17', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('340', '12', 'TESTES PROCEDURES, NON-MALIG AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('341', '12', 'PENIS PROCEDURES', 1, 2, '', '2', '06', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('342', '12', 'CIRCUMCISION AGE >17', 1, 3, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('343', '12', 'CIRCUMCISION AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('344', '12', 'OTH MALE REPRO SYST O.R. PROCS FOR MALIG', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('345', '12', 'OTH MALE REPRO SYST O.R. PROCS EX MALIG', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('346', '12', 'MALIGNANCY, MALE REPRO SYSTEM, W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('347', '12', 'MALIGNANCY, MALE REPRO SYSTEM, W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('348', '12', 'BENIGN PROSTATIC HYPERTROPHY W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('349', '12', 'BENIGN PROSTATIC HYPERTROPHY W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('350', '12', 'INFLAMMATION OF THE MALE REPRO SYSTEM', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('351', '12', 'STERILIZATION, MALE', 0, 1, '', '1', '02', 0, 999, 1, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('352', '12', 'OTHER MALE REPRODUCTIVE SYSTEM DIAGNOSES', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('353', '13', 'PELVIC EVISC,RAD HYSTERECT & RAD VULVECT', 2, 6, '', '2', '05', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('354', '13', 'UTER,ADNEX PROC NON-OV/ADNEX MALIG W CC', 1, 5, '', '2', '05', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('355', '13', 'UTER,ADNEX PROC NON-OV/ADNEX MALIG WO CC', 1, 3, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('356', '13', 'FEMALE REPRO SYSTEM RECONSTRUCTIVE PROCS', 1, 2, '', '2', '05', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('357', '13', 'UTER&ADNEX PROC FOR OVAR,ADNEXAL MALIG', 2, 7, '', '2', '05', 0, 999, 9, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('358', '13', 'UTER&ADNEX PROC FOR NON-MALIG W CC', 1, 4, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('359', '13', 'UTER&ADNEX PROC FOR NON-MALIG W/O CC', 1, 3, '', '2', '05', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('360', '13', 'VAGINA, CERVIX & VULVA PROCEDURES', 1, 3, '', '2', '05', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('361', '13', 'LAPAROSCOPY & INCISIONAL TUBAL INTERRUPT', 1, 2, '', '2', '05', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('362', '13', 'ENDOSCOPIC TUBAL INTERRUPTION', 0, 1, '', '2', '05', 0, 999, 1, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('363', '13', 'D&C,CONIZATION&RADIO-IMPLANT, FOR MALIG', 1, 2, '', '2', '05', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('364', '13', 'D&C,CONIZATION EXCEPT FOR MALIGNANCY', 1, 3, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('365', '13', 'OTHER FEMALE REPRO SYSTEM O.R. PROC', 2, 5, '', '2', '05', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('366', '13', 'MALIGNANCY, FEMALE REPRO SYSTEM W CC', 1, 5, '', '1', '05', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('367', '13', 'MALIGNANCY, FEMALE REPRO SYSTEM W/O CC', 1, 2, '', '1', '05', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('368', '13', 'INFECTIONS, FEMALE REPRODUCTIVE SYSTEM', 1, 5, '', '1', '05', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('369', '13', 'MENSTRUAL&OTHER FEMALE REPRO SYST DISOR', 1, 2, '', '1', '05', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('370', '14', 'CESAREAN SECTION W CC', 1, 4, '', '2', '04', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('371', '14', 'CESAREAN SECTION W/O CC', 1, 3, '', '2', '04', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('372', '14', 'VAGINAL DELIVERY W COMPLIC DIAGNOSES', 1, 2, '', '1', '03', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('373', '14', 'VAGINAL DELIVERY W/O COMPLIC DIAGNOSES', 0, 2, '', '1', '03', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('374', '14', 'VAGINAL DELIVERY W STERIL &/OR D&C', 1, 2, '', '2', '03', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('375', '14', 'VAG DELIV W O.R. PROC EX STERIL &/OR D&C', 1, 4, '', '2', '03', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('376', '14', 'POSTPART & POST ABORT DX W/O O.R. PROC', 0, 2, '', '1', '03', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('377', '14', 'POSTPART & POST ABORT DX W O.R. PROC', 1, 3, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('378', '14', 'ECTOPIC PREGNANCY', 1, 2, '', '1', '05', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('379', '14', 'THREATENED ABORTION', 0, 2, '', '1', '05', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('380', '14', 'ABORTION W/O D&C', 0, 2, '', '1', '05', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('381', '14', 'ABORTION W D&C,ASPIR CURETT,HYSTEROTOMY', 1, 2, '', '2', '05', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('382', '14', 'FALSE LABOR', 0, 1, '', '1', '05', 0, 999, 1, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('383', '14', 'OTH ANTEPARTUM DX W MEDICAL COMPLIC', 0, 3, '', '1', '05', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('384', '14', 'OTH ANTEPARTUM DX W/O MEDICAL COMPLIC', 0, 2, '', '1', '05', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('385', '15', 'NEONATES,DIED OR TRANS ACUTE CARE FACIL', 1, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('386', '15', 'EXTREME IMMATUR,RESP DIST SYND,NEONATE', 5, 18, '', '1', '06', 0, 999, 18, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('387', '15', 'PREMATURITY W MAJOR PROBLEMS', 3, 13, '', '1', '06', 0, 999, 13, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('388', '15', 'PREMATURITY W/O MAJOR PROBLEMS', 2, 9, '', '1', '06', 0, 999, 9, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('389', '15', 'FULL TERM NEONATE W MAJOR PROBLEMS', 2, 8, '', '1', '06', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('390', '15', 'NEONATE W OTHER SIGNIFICANT PROBLEMS', 2, 4, '', '1', '06', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('391', '15', 'NORMAL NEWBORN', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('392', '16', 'SPLENECTOMY AGE >17', 3, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('393', '16', 'SPLENECTOMY AGE 0-17', 1, 9, '', '2', '06', 0, 999, 9, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('394', '16', 'OTH O.R PROC OF BLOOD&BLOOD FORM ORGANS', 2, 4, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('395', '16', 'RED BLOOD CELL DISORDERS AGE >17', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('396', '16', 'RED BLOOD CELL DISORDERS AGE 0-17', 2, 5, '', '1', '01', 0, 999, 18, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('397', '16', 'COAGULATION DISORDERS', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('398', '16', 'RETICULOENDOTHELIAL & IMMUN DISOR W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('399', '16', 'RETICULOENDOTHELIAL & IMMUN DISOR W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('400', '17', 'LYMPHOMA & LEUKEMIA W MAJOR O.R. PROC', 3, 6, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('401', '17', 'LYMPHOMA&NONACU LEUK OTH O.R PROC W CC', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('402', '17', 'LYMPHOMA&NONACU LEUK OTH O.R PROC WO CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('403', '17', 'LYMPHOMA & NON-ACUTE LEUKEMIA W CC', 2, 6, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('404', '17', 'LYMPHOMA & NON-ACUTE LEUKEMIA W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('405', '17', 'ACUTE LEUKEMIA W/O MAJ O.R PROC AGE 0-17', 2, 5, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('406', '17', 'MYEL DIS/PRLY DIF NEO&MAJ O.R.PROC W CC', 3, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('407', '17', 'MYEL DIS,PRLY DIF NEO&MAJ O.R.PROC WO CC', 1, 4, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('408', '17', 'MYEL DIS,PRLY DIF NEO&OTH O.R.PROC', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('409', '17', 'RADIOTHERAPY', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('410', '17', 'CHEMOTHERAPY W/O ACUTE LUKEMIA AS SEC DX', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('411', '17', 'HISTORY OF MALIGNANCY W/O ENDOSCOPY', 0, 2, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('412', '17', 'HISTORY OF MALIGNANCY W ENDOSCOPY', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('413', '17', 'OTH MYEL DIS/POORLY DIFF NEOPL DX W CC', 1, 5, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('414', '17', 'OTH MYEL DIS/POORLY DIFF NEOPL DX WO CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('415', '18', 'O.R. PROC FOR INFECTIOUS & PARASITIC DIS', 4, 10, '', '2', '02', 0, 999, 14, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('416', '18', 'SEPTICEMIA AGE >17', 1, 6, '', '1', '06', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('417', '18', 'SEPTICEMIA AGE 0-17', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('418', '18', 'POSTOPERATIVE & POST-TRAUMATIC INFECTION', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('419', '18', 'FEVER OF UNKNOWN ORIGIN AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('420', '18', 'FEVER OF UNKNOWN ORIGIN AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('421', '18', 'VIRAL ILLNESS AGE >17', 1, 3, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('422', '18', 'VIRAL ILL&FEVER OF UNKNWN ORIG AGE 0-17', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('423', '18', 'OTH INFECTIOUS & PARASITIC DIS DIAGNOSES', 2, 6, '', '1', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('424', '19', 'O.R PROC W PRINC DX OF MENTAL ILLNESS', 2, 9, '', '2', '07', 0, 999, 14, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('425', '19', 'ACU ADJ REACT&DISTURB PSYCHOSOCIAL DYSF', 1, 3, '', '1', '07', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('426', '19', 'DEPRESSIVE NEUROSES', 1, 4, '', '1', '07', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('427', '19', 'NEUROSES EXCEPT DEPRESSIVE', 1, 3, '', '1', '07', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('428', '19', 'DISORDERS OF PERSONALITY&IMPULSE CONTROL', 1, 4, '', '1', '07', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('429', '19', 'ORGANIC DISTURBANCES&MENTAL RETARDATION', 1, 5, '', '1', '07', 0, 999, 7, '1', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('430', '19', 'PSYCHOSES', 1, 6, '', '1', '07', 0, 999, 9, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('431', '19', 'CHILDHOOD MENTAL DISORDERS', 1, 5, '', '1', '07', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('432', '19', 'OTHER MENTAL DISORDER DIAGNOSES', 1, 3, '', '1', '07', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('433', '20', 'ALCOHOL/DRUG ABUSE, DEPENDENCE, LEFT AMA', 0, 2, '', '1', '08', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('434', '20', 'ALC/DRG ABUSE,DEP, DETOX,OTH TREAT W CC', 1, 4, '', '1', '08', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('435', '20', 'ALC/DRG ABUSE,DEP, DETOX,OTH TREAT WO CC', 0, 4, '', '1', '08', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('436', '20', 'ALC/DRUG DEPENDENCE W REHAB THERAPY', 1, 11, '', '1', '08', 0, 999, 14, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('437', '20', 'ALC/DRUG DEP, COMB REHAB & DETOX THERAPY', 1, 8, '', '1', '08', 0, 999, 9, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('439', '21', 'SKIN GRAFTS FOR INJURIES', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('440', '21', 'WOUND DEBRIDEMENTS FOR INJURIES', 2, 6, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('441', '21', 'HAND PROCEDURES FOR INJURIES', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('442', '21', 'OTHER O.R PROCEDURES FOR INJURIES W CC', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('443', '21', 'OTHER O.R PROCEDURES FOR INJURIES W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('444', '21', 'TRAUMATIC INJURY AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('445', '21', 'TRAUMATIC INJURY AGE >17 W/O CC', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('446', '21', 'TRAUMATIC INJURY AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('447', '21', 'ALLERGIC REACTIONS AGE >17', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('448', '21', 'ALLERGIC REACTIONS AGE 0-17', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('449', '21', 'POISON&TOXIC EFFECTS DRUGS AGE >17 W CC', 1, 3, '', '1', '08', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('450', '21', 'POISON&TOXIC EFFECTS DRUGS AGE >17 WO CC', 0, 2, '', '1', '08', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('451', '21', 'POISON&TOXIC EFFECTS DRUGS AGE 0-17', 0, 2, '', '1', '08', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('452', '21', 'COMPLICATIONS OF TREATMENT W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('453', '21', 'COMPLICATIONS OF TREATMENT W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('454', '21', 'OTH INJURY,POISON&TOXIC EFFECT DX W CC', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('455', '21', 'OTH INJURY,POISON&TOXIC EFFECT DX W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('461', '23', 'O.R. PROC W DX OTH CONTACT W HEALTH SERV', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('462', '23', 'REHABILITATION', 1, 10, '', '1', '09', 0, 999, 13, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('463', '23', 'SIGNS & SYMPTOMS W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('464', '23', 'SIGNS & SYMPTOMS W/O CC', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('465', '23', 'AFTERCARE W HIST MALIG AS SECONDARY DX', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('466', '23', 'AFTERCARE W/O HIST MALIG AS SECONDARY DX', 1, 2, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('467', '23', 'OTHER FACTORS INFLUENCING HEALTH STATUS', 0, 2, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('468', '00', 'EXTENS O.R. PROC UNRELATED TO PRINC DX', 4, 10, '', '0', '02', 0, 999, 14, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('469', '00', 'PRINC DX INVALID AS DISCHARGE DIAGNOSIS', 0, 0, '', '0', '01', 0, 999, 0, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('470', '00', 'UNGROUPABLE', 0, 0, '', '0', '', 0, 999, 0, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('471', '08', 'BILAT OR MULT MAJ JOINT PROC, LOW EXTREM', 3, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('473', '17', 'ACU LEUKEMIA W/O MAJOR O.R PROC AGE >17', 3, 8, '', '1', '01', 0, 999, 13, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('475', '04', 'RESP SYSTEM DX WITH VENTILATOR SUPPORT', 4, 8, '', '1', '01', 0, 999, 11, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('476', '00', 'PROSTATIC O.R PROC UNRELATED TO PRINC DX', 2, 9, '', '0', '02', 0, 999, 12, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('477', '00', 'NON-EXTEN O.R PROC UNRELATED TO PRINC DX', 2, 5, '', '0', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('478', '05', 'OTHER VASCULAR PROCEDURES W CC', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('479', '05', 'OTHER VASCULAR PROCEDURES W/O CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('480', '00', 'LIVER TRANSPLANT', 11, 19, '', '2', '02', 0, 999, 27, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('481', '00', 'BONE MARROW TRANSPLANT', 10, 25, '', '2', '02', 0, 999, 28, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('482', '00', 'TRACHMY FOR FACE,MOUTH AND NECK DIAG', 4, 10, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('483', '00', 'TRACHMY EX FACE,MOUTH AND NECK DIAG', 16, 34, '', '2', '02', 0, 999, 42, '1', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('484', '24', 'CRANIOTOMY, MULTIPLE SIGNIFICANT TRAUMA', 5, 10, '', '2', '02', 0, 999, 15, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('485', '24', 'LIMB REATTACH,HIP&FEMUR,MULT SIGN TRAUMA', 3, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('486', '24', 'OTHER O.R. PROC FOR MULTI SIGN TRAUMA', 5, 8, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('487', '24', 'OTHER MULTIPLE SIGNIFICANT TRAUMA', 2, 6, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('488', '25', 'HIV W EXTENSIVE O.R. PROCEDURE', 5, 12, '', '2', '02', 0, 999, 17, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('489', '25', 'HIV W MAJOR RELATED CONDITION', 2, 6, '', '1', '01', 0, 999, 9, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('490', '25', 'HIV W OR W/O OTHER RELATED CONDITION', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('491', '08', 'MAJ JOINT/LIMB REATTACH PROC, UPP EXTREM', 2, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('492', '17', 'CHEMOTHERAPY W ACUTE LUKEMIA AS SEC DX', 5, 11, '', '1', '01', 0, 999, 17, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('493', '07', 'LAPAROSCOPIC CHOLECYSTECT W/O CDE W CC', 2, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('494', '07', 'LAPAROSCOPIC CHOLECYSTECT W/O CDE W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('495', '00', 'LUNG TRANSPLANT', 9, 14, '', '2', '02', 0, 999, 17, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('496', '08', 'COMB ANTERIOR/POSTERIOR SPINAL FUSION', 5, 9, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('497', '08', 'SPINAL FUSION W CC', 3, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('498', '08', 'SPINAL FUSION W/O CC', 2, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('499', '08', 'BACK & NECK PROC EXC SPINAL FUSION W CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('500', '08', 'BACK & NECK PROC EXC SPINAL FUSION WO CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('501', '08', 'KNEE PROC W PDX OF INFECTION W CC', 3, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('502', '08', 'KNEE PROC W PDX OF INFECTION W/O CC', 2, 5, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('503', '08', 'KNEE PROCEDURES W/O PDX OF INFECTION', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('504', '22', 'EXTENSIVE 3RD DEGREE BURN W SKIN GRAFT', 14, 24, '', '2', '02', 0, 999, 32, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('505', '22', 'EXTENSIVE 3RD DEGREE BURN W/O SKIN GRAFT', 2, 2, '', '0', '01', 0, 999, 6, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('506', '22', 'FUL TH BRN W GRFT INHAL W CC OR SIG TR', 4, 12, '', '0', '02', 0, 999, 17, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('507', '22', 'FUL TH BRN W GRFT INHAL WO CC OR SIG TR', 2, 7, '', '0', '02', 0, 999, 9, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('508', '22', 'FUL TH BRN WO GRFT INHAL W CC OR SIG TR', 1, 5, '', '0', '01', 0, 999, 8, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('509', '22', 'FUL TH BRN WO GRFT INHAL WO CC OR SIG TR', 1, 3, '', '0', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('510', '22', 'NON-EXTENS BURNS W CC OR SIGNIF TRAUMA', 1, 5, '', '0', '01', 0, 999, 7, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('511', '22', 'NON-EXTENS BURNS W/O CC OR SIGNIF TRAUMA', 1, 4, '', '0', '01', 0, 999, 5, '0', 'HCFA', 'G')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('193', '07', 'BIL PROC W CC, EX ONLY CHOLCYST W/WO CDE', 3, 10, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('194', '07', 'BIL PROC WO CC,EX ONLY CHOLCYST W/WO CDE', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('195', '07', 'CHOLECYSTECTOMY W C.D.E. W CC', 3, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('196', '07', 'CHOLECYSTECTOMY W C.D.E. W/O CC', 2, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('197', '07', 'CHOLECYSTMY,EX LAPSCPC W/O C.D.E. W CC', 2, 7, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('198', '07', 'CHOLECYSTMY,EX LAPSCPC W/O C.D.E. W/O CC', 1, 4, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('199', '07', 'HEPATOBIL DIAGNOSTIC PROC FOR MALIGNANCY', 2, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('200', '07', 'HEPATOBIL DIAGNOSTIC PROC FOR NON-MALIG', 3, 7, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('201', '07', 'OTHER HEPATOBIL OR PANCREAS O.R. PROC', 3, 10, '', '2', '02', 0, 999, 14, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('202', '07', 'CIRRHOSIS & ALCOHOLIC HEPATITIS', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('203', '07', 'MALIGNANCY OF HEPATOBIL SYST OR PANCREAS', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('204', '07', 'DISORDERS OF PANCREAS EXCEPT MALIGNANCY', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('205', '07', 'DISOR LIVER, EX MALIG,CIRR,ALC HEPA W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('206', '07', 'DISOR LIVER,EX MALIG,CIRR,ALC HEPA WO CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('207', '07', 'DISORDERS OF THE BILIARY TRACT W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('208', '07', 'DISORDERS OF THE BILIARY TRACT W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('209', '08', 'MAJ JOINT/LIMB REATTACH PROC, LOW EXTREM', 2, 5, '', '2', '02', 0, 999, 5, '2', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('210', '08', 'HIP&FEMUR PROC,EX MAJ JNT,AGE >17 W CC', 2, 6, '', '2', '02', 0, 999, 7, '2', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('211', '08', 'HIP&FEMUR PROC,EX MAJ JNT,AGE >17 W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '2', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('212', '08', 'HIP&FEMUR PROC,EX MAJ JNT,AGE 0-17', 1, 11, '', '2', '06', 0, 999, 11, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('213', '08', 'AMPUT FOR MUSCSKL SYST & CONN TISS DISOR', 2, 6, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('216', '08', 'BIOPSIES OF MUSCSKL SYST & CONN TISSUE', 2, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('217', '08', 'WND DBRD,SK GRFT EX HAND,MUSSKL,CONN TIS', 3, 9, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('218', '08', 'LW EXT&HUM PROC,EX HIP,FT,FEM >17 W CC', 2, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('219', '08', 'LW EXT&HUM PROC,EX HIP,FT,FEM >17 W/O CC', 1, 3, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('220', '08', 'LW EXT&HUM PROC,EX HIP,FT,FEM 0-17', 1, 5, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('223', '08', 'MAJ SHLDR/ELBOW,OTH UPPR EXTR PROC W CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('224', '08', 'SHLDR,ELBW,FOREARM PROC,EX MAJ JNT WO CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('225', '08', 'FOOT PROCEDURES', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('226', '08', 'SOFT TISSUE PROCEDURES W CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('227', '08', 'SOFT TISSUE PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('228', '08', 'MAJ THUMB/JOINT/OTH HAND/WRIST PROC W CC', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('229', '08', 'HAND/WRIST PROC,EXC MAJ JNT PROC,W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('230', '08', 'LOC EXCIS,REMOV INT FIX DEV HIP,FEMUR', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('231', '08', 'LOC EXCIS,REMOV INT FIX DEV EX HIP,FEMUR', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('232', '08', 'ARTHROSCOPY', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('233', '08', 'OTH MUSCSKL & CONN TISS O.R. PROC W CC', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('234', '08', 'OTH MUSCSKL & CONN TISS O.R. PROC W/O CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('235', '08', 'FRACTURES OF FEMUR', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('236', '08', 'FRACTURES OF HIP & PELVIS', 1, 4, '', '1', '01', 0, 999, 5, '1', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('237', '08', 'SPRAIN,STRAIN,DISLOC OF HIP,PELVIS,THIGH', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('238', '08', 'OSTEOMYELITIS', 1, 6, '', '1', '01', 0, 999, 9, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('239', '08', 'PATH FX & MUSCSKL & CONNECT TISSUE MALIG', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('240', '08', 'CONNECTIVE TISSUE DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('241', '08', 'CONNECTIVE TISSUE DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('242', '08', 'SEPTIC ARTHRITIS', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('243', '08', 'MEDICAL BACK PROBLEMS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('244', '08', 'BONE DIS & SPECIFIC ARTHROPATHIES W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('245', '08', 'BONE DIS & SPECIFIC ARTHROPATHIES W/O CC', 0, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('246', '08', 'NON-SPECIFIC ARTHROPATHIES', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('247', '08', 'SIGNS&SYMPTOMS OF MUSCSKL SYST&CONN TISS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('248', '08', 'TENDONITIS, MYOSITIS & BURSITIS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('249', '08', 'AFTERCARE, MUSCSKL SYST & CONN TISSUE', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('250', '08', 'FX,SPR,STR,DSL FRARM,HAND,FT >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('251', '08', 'FX,SPR,STR,DSL FRARM,HAND,FT >17 W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('252', '08', 'FX,SPR,STR,DSL FRARM,HAND,FT 0-17', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('253', '08', 'FX,SPR,STR,DSL UARM,LWLG EX FT >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('254', '08', 'FX,SPR,STR,DSL UARM,LWLG EX FT >17 WO CC', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('255', '08', 'FX,SPR,STR,DSL UARM,LWLG EX FT 0-17', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('256', '08', 'OTHER MUSCSKL SYST & CONN TISS DIAGNOSES', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('257', '09', 'TOTAL MASTECTOMY FOR MALIGNANCY W CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('258', '09', 'TOTAL MASTECTOMY FOR MALIGNANCY W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('259', '09', 'SUBTOT MASTECTOMY FOR MALIGNANCY W CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('260', '09', 'SUBTOT MASTECTOMY FOR MALIGNANCY W/O CC', 1, 1, '', '2', '02', 0, 999, 1, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('261', '09', 'BREAST PROC NON-MALIG,EX BIOP&LOC EXCIS', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('262', '09', 'BREAST BIOPSY & LOC EXCIS FOR NON-MALIG', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('263', '09', 'SKN GRFT/DEBRID,SKN ULCR,CELLULIT W CC', 2, 9, '', '2', '02', 0, 999, 12, '1', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('264', '09', 'SKN GRFT/DEBRID,SKN ULCR,CELLULIT W/O CC', 1, 5, '', '2', '02', 0, 999, 7, '1', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('265', '09', 'SKN GRFT/DEBRID,EX SKN ULCR,CELLUL W CC', 2, 4, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('266', '09', 'SKN GRFT/DEBRID,EX SKN ULCR,CELLUL WO CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('267', '09', 'PERIANAL & PILONIDAL PROCEDURES', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('268', '09', 'SKIN,SUBCUT TISSUE&BREAST PLASTIC PROC', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('269', '09', 'OTH SKIN,SUBCUT TISS&BREAST PROC W CC', 2, 6, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('270', '09', 'OTH SKIN,SUBCUT TISS&BREAST PROC W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('271', '09', 'SKIN ULCERS', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('272', '09', 'MAJOR SKIN DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('273', '09', 'MAJOR SKIN DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('274', '09', 'MALIGNANT BREAST DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('275', '09', 'MALIGNANT BREAST DISORDERS W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('276', '09', 'NON-MALIGNANT BREAST DISORDERS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('277', '09', 'CELLULITIS AGE >17 W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('278', '09', 'CELLULITIS AGE >17 W/O CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('279', '09', 'CELLULITIS AGE 0-17', 1, 4, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('280', '09', 'TRAUMA SKN,SUBCUT TIS&BREAST AGE>17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('281', '09', 'TRAUMA SKN,SUBCU TIS&BREAST AGE>17 WO CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('282', '09', 'TRAUMA SKN,SUBCUT TISS&BREAST AGE 0-17', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('283', '09', 'MINOR SKIN DISORDERS W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('284', '09', 'MINOR SKIN DISORDERS W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('285', '10', 'AMPUT LOWR LIMB ENDOCR,NUTR,METAB DISOR', 2, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('286', '10', 'ADRENAL & PITUITARY PROCEDURES', 2, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('287', '10', 'SKN GRFT,WND DBRD ENDOC,NUTR,METAB DISOR', 2, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('288', '10', 'O.R. PROCEDURES FOR OBESITY', 2, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('192', '07', 'PANCREAS,LIVER & SHUNT PROCEDURES W/O CC', 2, 5, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('129', '05', 'CARDIAC ARREST, UNEXPLAINED', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('130', '05', 'PERIPHERAL VASCULAR DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('131', '05', 'PERIPHERAL VASCULAR DISORDERS W/O CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('132', '05', 'ATHEROSCLEROSIS W CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('133', '05', 'ATHEROSCLEROSIS W/O CC', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('134', '05', 'HYPERTENSION', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('135', '05', 'CARD CONGEN & VALV DISOR AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('136', '05', 'CARD CONGEN & VALV DISOR AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('137', '05', 'CARD CONGEN & VALV DISOR AGE 0-17', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('138', '05', 'CARD ARRHYTHMIA & CONDUCTN DISOR W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('139', '05', 'CARD ARRHYTHMIA & CONDUCTN DISOR W/O CC', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('140', '05', 'ANGINA PECTORIS', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('141', '05', 'SYNCOPE & COLLAPSE W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('142', '05', 'SYNCOPE & COLLAPSE W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('143', '05', 'CHEST PAIN', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('144', '05', 'OTH CIRCULATORY SYSTEM DIAGNOSES W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('145', '05', 'OTH CIRCULATORY SYSTEM DIAGNOSES W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('146', '06', 'RECTAL RESECTION W CC', 3, 9, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('147', '06', 'RECTAL RESECTION W/O CC', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('148', '06', 'MAJOR SMALL & LARGE BOWEL PROCS W CC', 3, 10, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('149', '06', 'MAJOR SMALL & LARGE BOWEL PROCS W/O CC', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('150', '06', 'PERITONEAL ADHESIOLYSIS W CC', 3, 9, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('151', '06', 'PERITONEAL ADHESIOLYSIS W/O CC', 1, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('152', '06', 'MINOR SMALL & LARGE BOWEL PROCS W CC', 2, 7, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('153', '06', 'MINOR SMALL & LARGE BOWEL PROCS W/O CC', 1, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('154', '06', 'STOMACH,ESOPH & DUOD PROC AGE >17 W CC', 4, 10, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('155', '06', 'STOMACH,ESOPH & DUOD PROC AGE >17 W/O CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('156', '06', 'STOMACH,ESOPH & DUOD PROC AGE 0-17', 1, 6, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('157', '06', 'ANAL & STOMAL PROCEDURES W CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('158', '06', 'ANAL & STOMAL PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('159', '06', 'HERNIA PROC EXC ING,FEMOR AGE >17 W CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('160', '06', 'HERNIA PROC EXC ING,FEMOR AGE >17 W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('161', '06', 'ING & FEMORAL HERNIA PROC AGE >17 W CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('162', '06', 'ING & FEMORAL HERNIA PROC AGE >17 W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('163', '06', 'HERNIA PROCEDURES AGE 0-17', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('164', '06', 'APPENDECTOMY W COMPLIC PRINC DX W CC', 2, 7, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('165', '06', 'APPENDECTOMY W COMPLIC PRINC DX W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('166', '06', 'APPENDECTOMY W/O COMPLIC PRINC DX W CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('167', '06', 'APPENDECTOMY W/O COMPLIC PRINC DX W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('168', '03', 'MOUTH PROCEDURES W CC', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('169', '03', 'MOUTH PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('170', '06', 'OTHER DIGESTIVE SYSTEM O.R. PROCS W CC', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('171', '06', 'OTHER DIGESTIVE SYSTEM O.R. PROCS W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('172', '06', 'DIGESTIVE MALIGNANCY W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('173', '06', 'DIGESTIVE MALIGNANCY W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('174', '06', 'G.I. HEMORRHAGE W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('175', '06', 'G.I. HEMORRHAGE W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('176', '06', 'COMPLICATED PEPTIC ULCER', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('177', '06', 'UNCOMPLICATED PEPTIC ULCER W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('178', '06', 'UNCOMPLICATED PEPTIC ULCER W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('179', '06', 'INFLAMMATORY BOWEL DISEASE', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('180', '06', 'G.I. OBSTRUCTION W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('181', '06', 'G.I. OBSTRUCTION W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('182', '06', 'ESPHGITIS,GE,MISC DIG DIS AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('183', '06', 'ESPHGITIS,GE,MISC DIG DIS AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('184', '06', 'ESPHGITIS,GE,MISC DIG DIS AGE 0-17', 1, 2, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('185', '03', 'DENT,ORAL DIS EX EXTRACT,RESTOR AGE >17', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('186', '03', 'DENT,ORAL DIS EX EXTRACT,RESTOR AGE 0-17', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('187', '03', 'DENTAL EXTRACTIONS & RESTORATIONS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('188', '06', 'OTHER DIGESTIVE SYSTEM DX AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('189', '06', 'OTHER DIGESTIVE SYSTEM DX AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('190', '06', 'OTHER DIGESTIVE SYSTEM DX AGE 0-17', 1, 4, '', '1', '06', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('191', '07', 'PANCREAS,LIVER & SHUNT PROCEDURES W CC', 4, 10, '', '2', '02', 0, 999, 14, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('098', '04', 'BRONCHITIS & ASTHMA AGE 0-17', 1, 3, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('099', '04', 'RESPIRATORY SIGNS & SYMPTOMS W CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('100', '04', 'RESPIRATORY SIGNS & SYMPTOMS W/O CC', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('101', '04', 'OTHER RESP SYSTEM DIAGNOSES W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('102', '04', 'OTHER RESP SYSTEM DIAGNOSES W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('103', '05', 'HEART TRANSPLANT', 19, 31, '', '2', '02', 0, 999, 52, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('104', '05', 'CARD VALVE OTH MAJ CARDTHOR PROC W CATH', 7, 9, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('105', '05', 'CARD VALVE OTH MAJ CARDTHOR PROC WO CATH', 6, 7, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('106', '05', 'CORONARY BYPASS WITH PTCA', 8, 9, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('107', '05', 'CORONARY BYPASS W CARDIAC CATH', 5, 9, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('108', '05', 'OTHER CARDIOTHORACIC PROCEDURES', 6, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('109', '05', 'CORONARY BYPASS W/O PTCA OR CARDIAC CATH', 4, 7, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('110', '05', 'MAJOR CARDIOVASCULAR PROCS WITH CC', 4, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('111', '05', 'MAJOR CARDIOVASCULAR PROCS W/O CC', 2, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('112', '05', 'PERCUTANEOUS CARDIOVASCULAR PROCEDURES', 2, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('113', '05', 'AMPUT FOR CIRC DISOR EXC UPPR LIMB & TOE', 3, 10, '', '2', '02', 0, 999, 13, '1', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('114', '05', 'UPPR LIMB & TOE AMPUT FOR CIRC DISOR', 2, 6, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('115', '05', 'PERM PACE IMP W AMI,HEART FAIL,SHCK,AICD', 3, 6, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('116', '05', 'OTH PERM CARD PACEMKR IMPL,PTCA W STENT', 2, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('117', '05', 'CARD PACEMKR REVISION EXC DEVICE REPLACE', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('118', '05', 'CARDIAC PACEMAKER DEVICE REPLACEMENT', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('119', '05', 'VEIN LIGATION & STRIPPING', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('120', '05', 'OTHER CIRCULATORY SYSTEM O.R. PROCEDURES', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('121', '05', 'CIRC DISOR W AMI & MAJ COMP DISCH ALIVE', 2, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('122', '05', 'CIRC DISOR W AMI WO MAJ COMP DISCH ALIVE', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('123', '05', 'CIRC DISOR W AMI, EXPIRED', 2, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('124', '05', 'CIRC DIS EX AMI W CARD CATH & COMPLX DX', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('125', '05', 'CIRC DIS EX AMI W CARD CATH WO COMPLX DX', 1, 2, '', '1', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('126', '05', 'ACUTE & SUBACUTE ENDOCARDITIS', 3, 9, '', '1', '01', 0, 999, 12, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('127', '05', 'HEART FAILURE & SHOCK', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('128', '05', 'DEEP VEIN THROMBOPHLEBITIS', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('097', '04', 'BRONCHITIS & ASTHMA AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('001', '01', 'CRANIOTOMY AGE >17 EXCEPT FOR TRAUMA', 3, 6, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('002', '01', 'CRANIOTOMY FOR TRAUMA AGE >17', 3, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('003', '01', 'CRANIOTOMY AGE 0-17', 2, 13, '', '2', '06', 0, 999, 13, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('004', '01', 'SPINAL PROCEDURES', 2, 5, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('005', '01', 'EXTRACRANIAL VASCULAR PROCEDURES', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('006', '01', 'CARPAL TUNNEL RELEASE', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('007', '01', 'PERIPH&CRAN NERV&OTH NERV SYS PROC W CC', 3, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('008', '01', 'PERIPH&CRAN NERV&OTH NERV SYS PROC WO CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('009', '01', 'SPINAL DISORDERS & INJURIES', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('010', '01', 'NERVOUS SYSTEM NEOPLASMS W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('011', '01', 'NERVOUS SYSTEM NEOPLASMS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('012', '01', 'DEGENERATIVE NERVOUS SYSTEM DISORDERS', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('013', '01', 'MULTIPLE SCLEROSIS & CEREBELLAR ATAXIA', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('014', '01', 'SPECIFIC CEREBROVASC DISORDERS EXC TIA', 1, 5, '', '1', '01', 0, 999, 6, '1', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('015', '01', 'TIA AND PRECEREBRAL OCCLUSIONS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('016', '01', 'NONSPECIFIC CEREBROVASC DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('017', '01', 'NONSPECIFIC CEREBROVASC DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('018', '01', 'CRANIAL & PERIPH NERVE DISORDERS W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('019', '01', 'CRANIAL & PERIPH NERVE DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('020', '01', 'NERV SYSTEM INFECT EXC VIRAL MENINGITIS', 3, 8, '', '1', '01', 0, 999, 11, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('021', '01', 'VIRAL MENINGITIS', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('022', '01', 'HYPERTENSIVE ENCEPHALOPATHY', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('023', '01', 'NONTRAUMATIC STUPOR & COMA', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('024', '01', 'SEIZURE & HEADACHE AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('025', '01', 'SEIZURE & HEADACHE AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('026', '01', 'SEIZURE & HEADACHE AGE 0-17', 1, 2, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('027', '01', 'TRAUMATIC STUPOR & COMA,COMA >1 HR', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('028', '01', 'TRAUM STUPOR&COMA,COMA<1 HR,AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('029', '01', 'TRAUM STUPOR&COMA,COMA<1HR,AGE>17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('030', '01', 'TRAUM STUPOR & COMA,COMA <1 HR,AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('031', '01', 'CONCUSSION AGE >17 WITH CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('032', '01', 'CONCUSSION AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('033', '01', 'CONCUSSION AGE 0-17', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('034', '01', 'OTHER DISORDERS OF NERVOUS SYSTEM W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('035', '01', 'OTHER DISORDERS OF NERVOUS SYSTEM W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('036', '02', 'RETINAL PROCEDURES', 1, 1, '', '2', '02', 0, 999, 1, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('037', '02', 'ORBITAL PROCEDURES', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('038', '02', 'PRIMARY IRIS PROCEDURES', 0, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('039', '02', 'LENS PROCEDURES WITH OR W/O VITRECTOMY', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('040', '02', 'EXTRAOCULAR PROCS EXCEPT ORBIT AGE >17', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('041', '02', 'EXTRAOCULAR PROCS EXCEPT ORBIT AGE 0-17', 0, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('042', '02', 'INTRAOCULAR PROCS EXC RETINA,IRIS & LENS', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('043', '02', 'HYPHEMA', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('044', '02', 'ACUTE MAJOR EYE INFECTIONS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('045', '02', 'NEUROLOGICAL EYE DISORDERS', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('046', '02', 'OTHER DISORDERS OF THE EYE AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('047', '02', 'OTHER DISORDERS OF THE EYE AGE>17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('048', '02', 'OTHER DISORDERS OF THE EYE AGE 0-17', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('049', '03', 'MAJOR HEAD & NECK PROCEDURES', 2, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('050', '03', 'SIALOADENECTOMY', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('051', '03', 'SALIVARY GLAND PROCS EXC SIALOADENECTOMY', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('052', '03', 'CLEFT LIP & PALATE REPAIR', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('053', '03', 'SINUS & MASTOID PROCEDURES AGE >17', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('054', '03', 'SINUS & MASTOID PROCEDURES AGE 0-17', 0, 3, '', '2', '06', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('055', '03', 'MISC EAR,NOSE,MOUTH & THROAT PROCEDURES', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('056', '03', 'RHINOPLASTY', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('057', '03', 'T&A PROC,EX TONSLCT/ADNDCT ONLY AGE >17', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('058', '03', 'T&A PROC,EX TONSLCT/ADNDCT ONLY AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('059', '03', 'TONSILLECT &/OR ADENOIDECT ONLY AGE >17', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('060', '03', 'TONSILLECT &/OR ADENOIDECT ONLY AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('061', '03', 'MYRINGOTOMY W TUBE INSERTION AGE >17', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('062', '03', 'MYRINGOTOMY W TUBE INSERTION AGE 0-17', 0, 1, '', '2', '06', 0, 999, 1, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('063', '03', 'OTHER EAR,NOSE,MOUTH & THROAT O.R. PROCS', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('064', '03', 'EAR, NOSE, MOUTH & THROAT MALIGNANCY', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('065', '03', 'DYSEQUILIBRIUM', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('066', '03', 'EPISTAXIS', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('067', '03', 'EPIGLOTTITIS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('068', '03', 'OTITIS MEDIA & URI AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('069', '03', 'OTITIS MEDIA & URI AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('070', '03', 'OTITIS MEDIA & URI AGE 0-17', 0, 2, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('071', '03', 'LARYNGOTRACHEITIS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('072', '03', 'NASAL TRAUMA & DEFORMITY', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('073', '03', 'OTH EAR,NOSE,MOUTH & THROAT DX AGE >17', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('074', '03', 'OTH EAR,NOSE,MOUTH & THROAT DX AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('075', '04', 'MAJOR CHEST PROCEDURES', 3, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('076', '04', 'OTHER RESP SYSTEM O.R. PROCEDURES W CC', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('077', '04', 'OTHER RESP SYSTEM O.R. PROCEDURES W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('078', '04', 'PULMONARY EMBOLISM', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('079', '04', 'RESP INFECT & INFLAM AGE >17 W CC', 2, 7, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('080', '04', 'RESP INFECT & INFLAM AGE >17 W/O CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('081', '04', 'RESP INFECT & INFLAM AGE 0-17', 2, 6, '', '1', '06', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('082', '04', 'RESPIRATORY NEOPLASMS', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('083', '04', 'MAJOR CHEST TRAUMA W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('084', '04', 'MAJOR CHEST TRAUMA W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('085', '04', 'PLEURAL EFFUSION W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('086', '04', 'PLEURAL EFFUSION W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('087', '04', 'PULMONARY EDEMA & RESPIRATORY FAILURE', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('088', '04', 'CHRONIC OBSTRUCTIVE PULMONARY DISEASE', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('089', '04', 'SIMPLE PNEUMONIA & PLEURISY AGE >17 W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('090', '04', 'SIMPLE PNEUMONIA&PLEURISY AGE >17 W/O CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('091', '04', 'SIMPLE PNEUMONIA & PLEURISY AGE 0-17', 1, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('092', '04', 'INTERSTITIAL LUNG DISEASE W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('093', '04', 'INTERSTITIAL LUNG DISEASE W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('094', '04', 'PNEUMOTHORAX WITH CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('095', '04', 'PNEUMOTHORAX W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('096', '04', 'BRONCHITIS & ASTHMA AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('487', '24', 'OTHER MULTIPLE SIGNIFICANT TRAUMA', 2, 6, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('488', '25', 'HIV W EXTENSIVE O.R. PROCEDURE', 5, 12, '', '2', '02', 0, 999, 17, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('489', '25', 'HIV W MAJOR RELATED CONDITION', 2, 6, '', '1', '01', 0, 999, 9, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('490', '25', 'HIV W OR W/O OTHER RELATED CONDITION', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('491', '08', 'MAJ JOINT/LIMB REATTACH PROC, UPP EXTREM', 2, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('492', '17', 'CHEMOTHERAPY W ACUTE LUKEMIA AS SEC DX', 4, 11, '', '1', '01', 0, 999, 16, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('493', '07', 'LAPAROSCOPIC CHOLECYSTECT W/O CDE W CC', 2, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('494', '07', 'LAPAROSCOPIC CHOLECYSTECT W/O CDE W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('495', '00', 'LUNG TRANSPLANT', 9, 13, '', '2', '02', 0, 999, 20, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('496', '08', 'COMB ANTERIOR/POSTERIOR SPINAL FUSION', 6, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('497', '08', 'SPINAL FUSION W CC', 3, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('498', '08', 'SPINAL FUSION W/O CC', 2, 3, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('499', '08', 'BACK & NECK PROC EXC SPINAL FUSION W CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('500', '08', 'BACK & NECK PROC EXC SPINAL FUSION WO CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('501', '08', 'KNEE PROC W PDX OF INFECTION W CC', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('502', '08', 'KNEE PROC W PDX OF INFECTION W/O CC', 1, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('503', '08', 'KNEE PROCEDURES W/O PDX OF INFECTION', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('504', '22', 'EXTENSIVE 3RD DEGREE BURN W SKIN GRAFT', 13, 24, '', '2', '02', 0, 999, 30, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('505', '22', 'EXTENSIVE 3RD DEGREE BURN W/O SKIN GRAFT', 2, 2, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('506', '22', 'FUL TH BRN W GRFT INHAL W CC OR SIG TR', 4, 13, '', '2', '02', 0, 999, 18, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('507', '22', 'FUL TH BRN W GRFT INHAL WO CC OR SIG TR', 2, 7, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('508', '22', 'FUL TH BRN WO GRFT INHAL W CC OR SIG TR', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('509', '22', 'FUL TH BRN WO GRFT INHAL WO CC OR SIG TR', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('510', '22', 'NON-EXTENS BURNS W CC OR SIGNIF TRAUMA', 1, 5, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('511', '22', 'NON-EXTENS BURNS W/O CC OR SIGNIF TRAUMA', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('389', '15', 'FULL TERM NEONATE W MAJOR PROBLEMS', 2, 5, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('390', '15', 'NEONATE W OTHER SIGNIFICANT PROBLEMS', 1, 3, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('391', '15', 'NORMAL NEWBORN', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('392', '16', 'SPLENECTOMY AGE >17', 3, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('393', '16', 'SPLENECTOMY AGE 0-17', 1, 9, '', '2', '06', 0, 999, 9, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('394', '16', 'OTH O.R PROC OF BLOOD&BLOOD FORM ORGANS', 2, 4, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('395', '16', 'RED BLOOD CELL DISORDERS AGE >17', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('396', '16', 'RED BLOOD CELL DISORDERS AGE 0-17', 1, 2, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('397', '16', 'COAGULATION DISORDERS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('398', '16', 'RETICULOENDOTHELIAL & IMMUN DISOR W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('399', '16', 'RETICULOENDOTHELIAL & IMMUN DISOR W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('400', '17', 'LYMPHOMA & LEUKEMIA W MAJOR O.R. PROC', 3, 6, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('401', '17', 'LYMPHOMA&NONACU LEUK OTH O.R PROC W CC', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('402', '17', 'LYMPHOMA&NONACU LEUK OTH O.R PROC WO CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('403', '17', 'LYMPHOMA & NON-ACUTE LEUKEMIA W CC', 2, 6, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('404', '17', 'LYMPHOMA & NON-ACUTE LEUKEMIA W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('405', '17', 'ACUTE LEUKEMIA W/O MAJ O.R PROC AGE 0-17', 2, 5, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('406', '17', 'MYEL DIS/PRLY DIF NEO&MAJ O.R.PROC W CC', 3, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('407', '17', 'MYEL DIS,PRLY DIF NEO&MAJ O.R.PROC WO CC', 1, 4, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('408', '17', 'MYEL DIS,PRLY DIF NEO&OTH O.R.PROC', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('409', '17', 'RADIOTHERAPY', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('410', '17', 'CHEMOTHERAPY W/O ACUTE LUKEMIA AS SEC DX', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('411', '17', 'HISTORY OF MALIGNANCY W/O ENDOSCOPY', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('412', '17', 'HISTORY OF MALIGNANCY W ENDOSCOPY', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('413', '17', 'OTH MYEL DIS/POORLY DIFF NEOPL DX W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('414', '17', 'OTH MYEL DIS/POORLY DIFF NEOPL DX WO CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('415', '18', 'O.R. PROC FOR INFECTIOUS & PARASITIC DIS', 4, 10, '', '2', '02', 0, 999, 14, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('416', '18', 'SEPTICEMIA AGE >17', 2, 6, '', '1', '06', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('417', '18', 'SEPTICEMIA AGE 0-17', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('418', '18', 'POSTOPERATIVE & POST-TRAUMATIC INFECTION', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('419', '18', 'FEVER OF UNKNOWN ORIGIN AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('420', '18', 'FEVER OF UNKNOWN ORIGIN AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('421', '18', 'VIRAL ILLNESS AGE >17', 1, 3, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('422', '18', 'VIRAL ILL&FEVER OF UNKNWN ORIG AGE 0-17', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('423', '18', 'OTH INFECTIOUS & PARASITIC DIS DIAGNOSES', 2, 6, '', '1', '02', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('424', '19', 'O.R PROC W PRINC DX OF MENTAL ILLNESS', 2, 9, '', '2', '07', 0, 999, 14, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('425', '19', 'ACU ADJ REACT & PSYCHOSOCIAL DYSFUNCTION', 1, 3, '', '1', '07', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('426', '19', 'DEPRESSIVE NEUROSES', 1, 3, '', '1', '07', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('427', '19', 'NEUROSES EXCEPT DEPRESSIVE', 1, 3, '', '1', '07', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('428', '19', 'DISORDERS OF PERSONALITY&IMPULSE CONTROL', 1, 4, '', '1', '07', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('429', '19', 'ORGANIC DISTURBANCES&MENTAL RETARDATION', 1, 5, '', '1', '07', 0, 999, 7, '1', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('430', '19', 'PSYCHOSES', 1, 6, '', '1', '07', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('431', '19', 'CHILDHOOD MENTAL DISORDERS', 1, 5, '', '1', '07', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('432', '19', 'OTHER MENTAL DISORDER DIAGNOSES', 1, 3, '', '1', '07', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('433', '20', 'ALCOHOL/DRUG ABUSE, DEPENDENCE, LEFT AMA', 0, 2, '', '1', '08', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('434', '20', 'ALC/DRG ABUSE,DEP, DETOX,OTH TREAT W CC', 1, 4, '', '1', '08', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('435', '20', 'ALC/DRG ABUSE,DEP, DETOX,OTH TREAT WO CC', 0, 3, '', '1', '08', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('436', '20', 'ALC/DRUG DEPENDENCE W REHAB THERAPY', 1, 10, '', '1', '08', 0, 999, 13, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('437', '20', 'ALC/DRUG DEP, COMB REHAB & DETOX THERAPY', 1, 8, '', '1', '08', 0, 999, 9, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('439', '21', 'SKIN GRAFTS FOR INJURIES', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('440', '21', 'WOUND DEBRIDEMENTS FOR INJURIES', 2, 6, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('441', '21', 'HAND PROCEDURES FOR INJURIES', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('442', '21', 'OTHER O.R PROCEDURES FOR INJURIES W CC', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('443', '21', 'OTHER O.R PROCEDURES FOR INJURIES W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('444', '21', 'TRAUMATIC INJURY AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('445', '21', 'TRAUMATIC INJURY AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('446', '21', 'TRAUMATIC INJURY AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('447', '21', 'ALLERGIC REACTIONS AGE >17', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('448', '21', 'ALLERGIC REACTIONS AGE 0-17', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('449', '21', 'POISON&TOXIC EFFECTS DRUGS AGE >17 W CC', 1, 3, '', '1', '08', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('450', '21', 'POISON&TOXIC EFFECTS DRUGS AGE >17 WO CC', 0, 2, '', '1', '08', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('451', '21', 'POISON&TOXIC EFFECTS DRUGS AGE 0-17', 0, 2, '', '1', '08', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('452', '21', 'COMPLICATIONS OF TREATMENT W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('453', '21', 'COMPLICATIONS OF TREATMENT W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('454', '21', 'OTH INJURY,POISON&TOXIC EFFECT DX W CC', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('455', '21', 'OTH INJURY,POISON&TOXIC EFFECT DX W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('461', '23', 'O.R. PROC W DX OTH CONTACT W HEALTH SERV', 1, 2, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('462', '23', 'REHABILITATION', 1, 9, '', '1', '09', 0, 999, 12, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('463', '23', 'SIGNS & SYMPTOMS W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('464', '23', 'SIGNS & SYMPTOMS W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('465', '23', 'AFTERCARE W HIST MALIG AS SECONDARY DX', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('466', '23', 'AFTERCARE W/O HIST MALIG AS SECONDARY DX', 1, 2, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('467', '23', 'OTHER FACTORS INFLUENCING HEALTH STATUS', 1, 2, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('468', '00', 'EXTENS O.R. PROC UNRELATED TO PRINC DX', 4, 9, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('469', '', 'PRINC DX INVALID AS DISCHARGE DIAGNOSIS', 0, 0, '', '', '01', 0, 999, 0, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('470', '', 'UNGROUPABLE', 0, 0, '', '', '', 0, 999, 0, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('471', '08', 'BILAT OR MULT MAJ JOINT PROC, LOW EXTREM', 3, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('473', '17', 'ACU LEUKEMIA W/O MAJOR O.R PROC AGE >17', 4, 8, '', '2', '01', 0, 999, 13, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('475', '04', 'RESP SYSTEM DX WITH VENTILATOR SUPPORT', 4, 8, '', '1', '01', 0, 999, 11, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('476', '00', 'PROSTATIC O.R PROC UNRELATED TO PRINC DX', 2, 8, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('477', '00', 'NON-EXTEN O.R PROC UNRELATED TO PRINC DX', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('478', '05', 'OTHER VASCULAR PROCEDURES W CC', 2, 5, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('479', '05', 'OTHER VASCULAR PROCEDURES W/O CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('480', '00', 'LIVER TRANSPLANT', 9, 15, '', '2', '02', 0, 999, 20, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('481', '00', 'BONE MARROW TRANSPLANT', 9, 24, '', '2', '02', 0, 999, 27, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('482', '00', 'TRACHMY FOR FACE,MOUTH AND NECK DIAG', 4, 10, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('483', '00', 'TRACHMY EX FACE,MOUTH AND NECK DIAG', 16, 34, '', '2', '02', 0, 999, 41, '1', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('484', '24', 'CRANIOTOMY, MULTIPLE SIGNIFICANT TRAUMA', 6, 9, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('485', '24', 'LIMB REATTACH,HIP&FEMUR,MULT SIGN TRAUMA', 3, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('486', '24', 'OTHER O.R. PROC FOR MULTI SIGN TRAUMA', 5, 8, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('384', '14', 'OTH ANTEPARTUM DX W/O MEDICAL COMPLIC', 0, 2, '', '1', '05', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('385', '15', 'NEONATES,DIED OR TRANS ACUTE CARE FACIL', 1, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('386', '15', 'EXTREME IMMATUR,RESP DIST SYND,NEONATE', 5, 18, '', '1', '06', 0, 999, 18, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('387', '15', 'PREMATURITY W MAJOR PROBLEMS', 3, 13, '', '1', '06', 0, 999, 13, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('388', '15', 'PREMATURITY W/O MAJOR PROBLEMS', 2, 9, '', '1', '06', 0, 999, 9, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('325', '11', 'KIDNY,URIN TRACT SIGN,SYMP AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('326', '11', 'KIDNY,URIN TRACT SIGN,SYMP AGE >17 WO CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('327', '11', 'KIDNY,URIN TRACT SIGN,SYMP AGE 0-17', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('328', '11', 'URETHRAL STRICTURE AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('329', '11', 'URETHRAL STRICTURE AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('330', '11', 'URETHRAL STRICTURE AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('331', '11', 'OTH KIDNEY & URIN TRACT DX AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('332', '11', 'OTH KIDNEY & URIN TRACT DX AGE >17 WO CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('333', '11', 'OTH KIDNEY & URIN TRACT DX AGE 0-17', 1, 4, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('334', '12', 'MAJOR MALE PELVIC PROCEDURES W CC', 2, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('335', '12', 'MAJOR MALE PELVIC PROCEDURES W/O CC', 1, 3, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('336', '12', 'TRANSURETHRAL PROSTATECTOMY W CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('337', '12', 'TRANSURETHRAL PROSTATECTOMY W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('338', '12', 'TESTES PROCEDURES, FOR MALIGNANCY', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('339', '12', 'TESTES PROCEDURES, NON-MALIG AGE >17', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('340', '12', 'TESTES PROCEDURES, NON-MALIG AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('341', '12', 'PENIS PROCEDURES', 1, 2, '', '2', '06', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('342', '12', 'CIRCUMCISION AGE >17', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('343', '12', 'CIRCUMCISION AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('344', '12', 'OTH MALE REPRO SYST O.R. PROCS FOR MALIG', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('345', '12', 'OTH MALE REPRO SYST O.R. PROCS EX MALIG', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('346', '12', 'MALIGNANCY, MALE REPRO SYSTEM, W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('347', '12', 'MALIGNANCY, MALE REPRO SYSTEM, W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('348', '12', 'BENIGN PROSTATIC HYPERTROPHY W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('349', '12', 'BENIGN PROSTATIC HYPERTROPHY W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('350', '12', 'INFLAMMATION OF THE MALE REPRO SYSTEM', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('351', '12', 'STERILIZATION, MALE', 0, 1, '', '1', '02', 0, 999, 1, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('352', '12', 'OTHER MALE REPRODUCTIVE SYSTEM DIAGNOSES', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('353', '13', 'PELVIC EVISC,RAD HYSTERECT & RAD VULVECT', 2, 5, '', '2', '05', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('354', '13', 'UTER,ADNEX PROC NON-OV/ADNEX MALIG W CC', 2, 5, '', '2', '05', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('355', '13', 'UTER,ADNEX PROC NON-OV/ADNEX MALIG WO CC', 1, 3, '', '2', '05', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('356', '13', 'FEMALE REPRO SYSTEM RECONSTRUCTIVE PROCS', 1, 2, '', '2', '05', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('357', '13', 'UTER&ADNEX PROC FOR OVAR,ADNEXAL MALIG', 2, 7, '', '2', '05', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('358', '13', 'UTER&ADNEX PROC FOR NON-MALIG W CC', 1, 4, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('359', '13', 'UTER&ADNEX PROC FOR NON-MALIG W/O CC', 1, 3, '', '2', '05', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('360', '13', 'VAGINA, CERVIX & VULVA PROCEDURES', 1, 2, '', '2', '05', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('361', '13', 'LAPAROSCOPY & INCISIONAL TUBAL INTERRUPT', 1, 2, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('362', '13', 'ENDOSCOPIC TUBAL INTERRUPTION', 0, 1, '', '2', '05', 0, 999, 1, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('363', '13', 'D&C,CONIZATION&RADIO-IMPLANT, FOR MALIG', 1, 2, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('364', '13', 'D&C,CONIZATION EXCEPT FOR MALIGNANCY', 1, 3, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('365', '13', 'OTHER FEMALE REPRO SYSTEM O.R. PROC', 2, 5, '', '2', '05', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('366', '13', 'MALIGNANCY, FEMALE REPRO SYSTEM W CC', 1, 5, '', '1', '05', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('367', '13', 'MALIGNANCY, FEMALE REPRO SYSTEM W/O CC', 1, 2, '', '1', '05', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('368', '13', 'INFECTIONS, FEMALE REPRODUCTIVE SYSTEM', 1, 5, '', '1', '05', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('369', '13', 'MENSTRUAL&OTHER FEMALE REPRO SYST DISOR', 1, 2, '', '1', '05', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('370', '14', 'CESAREAN SECTION W CC', 1, 4, '', '2', '04', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('371', '14', 'CESAREAN SECTION W/O CC', 1, 3, '', '2', '04', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('372', '14', 'VAGINAL DELIVERY W COMPLIC DIAGNOSES', 1, 3, '', '1', '03', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('373', '14', 'VAGINAL DELIVERY W/O COMPLIC DIAGNOSES', 0, 2, '', '1', '03', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('374', '14', 'VAGINAL DELIVERY W STERIL &/OR D&C', 1, 3, '', '2', '03', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('375', '14', 'VAG DELIV W O.R. PROC EX STERIL &/OR D&C', 1, 4, '', '2', '03', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('376', '14', 'POSTPART & POST ABORT DX W/O O.R. PROC', 1, 3, '', '1', '03', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('377', '14', 'POSTPART & POST ABORT DX W O.R. PROC', 1, 3, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('378', '14', 'ECTOPIC PREGNANCY', 1, 2, '', '1', '05', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('379', '14', 'THREATENED ABORTION', 0, 2, '', '1', '05', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('380', '14', 'ABORTION W/O D&C', 0, 2, '', '1', '05', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('381', '14', 'ABORTION W D&C,ASPIR CURETT,HYSTEROTOMY', 1, 2, '', '2', '05', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('382', '14', 'FALSE LABOR', 0, 1, '', '1', '05', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('383', '14', 'OTH ANTEPARTUM DX W MEDICAL COMPLIC', 1, 3, '', '1', '05', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('289', '10', 'PARATHYROID PROCEDURES', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('290', '10', 'THYROID PROCEDURES', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('291', '10', 'THYROGLOSSAL PROCEDURES', 1, 1, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('292', '10', 'OTH ENDOCR,NUTRIT,METAB O.R. PROC W CC', 2, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('293', '10', 'OTH ENDOCR,NUTRIT,METAB O.R. PROC W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('294', '10', 'DIABETES AGE >35', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('295', '10', 'DIABETES AGE 0-35', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('296', '10', 'NUTRIT & MISC METAB DISOR AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('297', '10', 'NUTRIT & MISC METAB DISOR AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('298', '10', 'NUTRIT & MISC METAB DISOR AGE 0-17', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('299', '10', 'INBORN ERRORS OF METABOLISM', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('300', '10', 'ENDOCRINE DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('301', '10', 'ENDOCRINE DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('302', '11', 'KIDNEY TRANSPLANT', 3, 8, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('303', '11', 'KIDNEY,URETR & MAJ BLADDR PROC FOR NEOPL', 2, 7, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('304', '11', 'KIDNY,URETR&MAJ BLADDR PROC NONNEO W CC', 2, 6, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('305', '11', 'KIDNY,URETR&MAJ BLADDR PROC NONNEO WO CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('306', '11', 'PROSTATECTOMY W CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('307', '11', 'PROSTATECTOMY W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('308', '11', 'MINOR BLADDER PROCEDURES W CC', 2, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('309', '11', 'MINOR BLADDER PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('310', '11', 'TRANSURETHRAL PROCEDURES W CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('311', '11', 'TRANSURETHRAL PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('312', '11', 'URETHRAL PROCEDURES, AGE >17 W CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('313', '11', 'URETHRAL PROCEDURES, AGE >17 W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('314', '11', 'URETHRAL PROCEDURES, AGE 0-17', 0, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('315', '11', 'OTHER KIDNEY & URINARY TRACT O.R. PROCS', 2, 4, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('316', '11', 'RENAL FAILURE', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('317', '11', 'ADMIT FOR RENAL DIALYSIS', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('318', '11', 'KIDNEY & URINARY TRACT NEOPLASMS W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('319', '11', 'KIDNEY & URINARY TRACT NEOPLASMS W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('320', '11', 'KIDNEY,URIN TRACT INFECT AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('321', '11', 'KIDNEY,URIN TRACT INFECT AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('322', '11', 'KIDNEY,URIN TRACT INFECT AGE 0-17', 0, 3, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('323', '11', 'URINARY STONES W CC,&/OR ESW LITHOTRIPSY', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('324', '11', 'URINARY STONES W/O CC', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'I')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('479', '05', 'OTHER VASCULAR PROCEDURES W/O CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('480', '00', 'LIVER TRANSPLANT', 11, 18, '', '2', '02', 0, 999, 24, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('481', '00', 'BONE MARROW TRANSPLANT', 8, 24, '', '2', '02', 0, 999, 26, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('482', '00', 'TRACHMY FOR FACE,MOUTH AND NECK DIAG', 4, 11, '', '2', '02', 0, 999, 14, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('483', '00', 'TRACHMY EX FACE,MOUTH AND NECK DIAG', 15, 34, '', '2', '02', 0, 999, 42, '1', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('484', '24', 'CRANIOTOMY, MULTIPLE SIGNIFICANT TRAUMA', 5, 12, '', '2', '02', 0, 999, 15, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('485', '24', 'LIMB REATTACH,HIP&FEMUR,MULT SIGN TRAUMA', 3, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('486', '24', 'OTHER O.R. PROC FOR MULTI SIGN TRAUMA', 5, 11, '', '2', '02', 0, 999, 14, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('487', '24', 'OTHER MULTIPLE SIGNIFICANT TRAUMA', 2, 6, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('488', '25', 'HIV W EXTENSIVE O.R. PROCEDURE', 5, 15, '', '2', '02', 0, 999, 20, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('489', '25', 'HIV W MAJOR RELATED CONDITION', 2, 7, '', '1', '01', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('490', '25', 'HIV W OR W/O OTHER RELATED CONDITION', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('491', '08', 'MAJ JOINT/LIMB REATTACH PROC, UPP EXTREM', 2, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('492', '17', 'CHEMOTHERAPY W ACUTE LUKEMIA AS SEC DX', 5, 14, '', '1', '01', 0, 999, 19, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('493', '07', 'LAPAROSCOPIC CHOLECYSTECT W/O CDE W CC', 2, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('494', '07', 'LAPAROSCOPIC CHOLECYSTECT W/O CDE W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('495', '00', 'LUNG TRANSPLANT', 9, 14, '', '2', '02', 0, 999, 16, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('496', '08', 'COMB ANTERIOR/POSTERIOR SPINAL FUSION', 6, 9, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('497', '08', 'SPINAL FUSION EXCEPT CERVICAL W CC', 3, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('498', '08', 'SPINAL FUSION EXCEPT CERVICAL W/O CC', 2, 4, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('499', '08', 'BACK & NECK PROC EXC SPINAL FUSION W CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('500', '08', 'BACK & NECK PROC EXC SPINAL FUSION WO CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('501', '08', 'KNEE PROC W PDX OF INFECTION W CC', 3, 10, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('502', '08', 'KNEE PROC W PDX OF INFECTION W/O CC', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('503', '08', 'KNEE PROCEDURES W/O PDX OF INFECTION', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('504', '22', 'EXTENSIVE 3RD DEGREE BURN W SKIN GRAFT', 14, 29, '', '2', '02', 0, 999, 35, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('505', '22', 'EXTENSIVE 3RD DEGREE BURN W/O SKIN GRAFT', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('506', '22', 'FUL TH BRN W GRFT INHAL W CC OR SIG TR', 5, 16, '', '2', '02', 0, 999, 20, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('507', '22', 'FUL TH BRN W GRFT INHAL WO CC OR SIG TR', 2, 7, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('508', '22', 'FUL TH BRN WO GRFT INHAL W CC OR SIG TR', 1, 6, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('509', '22', 'FUL TH BRN WO GRFT INHAL WO CC OR SIG TR', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('510', '22', 'NON-EXTENS BURNS W CC OR SIGNIF TRAUMA', 1, 6, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('511', '22', 'NON-EXTENS BURNS W/O CC OR SIGNIF TRAUMA', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('512', '00', 'SIMULTANEOUS PANCREAS/KIDNEY TRANSPLANT', 6, 13, '', '2', '02', 0, 999, 15, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('513', '00', 'PANCREAS TRANSPLANT', 6, 10, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('514', '05', 'CARDIAC DEFIBRILLATOR IMPL W CARD CATH', 6, 7, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('515', '05', 'CARDIAC DEFIBRILLATOR IMPL W/O CARD CATH', 5, 4, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('516', '05', 'PERCUTANEOUS CARDIOVASC PROC W AMI', 3, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('517', '05', 'PERC CARD PROC W COR ART STENT W/O AMI', 2, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('518', '05', 'PERC CARD PROC W/O COR ART STENT OR AMI', 2, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('519', '08', 'CERVICAL SPINAL FUSION W CC', 2, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('520', '08', 'CERVICAL SPINAL FUSION W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('521', '20', 'ALCOHOL/DRUG ABUSE OR DEPENDENCE W CC', 1, 5, '', '1', '08', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('522', '20', 'ALC/DRUG ABUSE, DEPEND W REHAB W/O CC', 1, 9, '', '1', '08', 0, 999, 10, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('523', '20', 'ALC/DRUG ABUSE, DEPEND W/O REHAB W/O CC', 0, 4, '', '1', '08', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('433', '20', 'ALCOHOL/DRUG ABUSE, DEPENDENCE, LEFT AMA', 0, 2, '', '1', '08', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('439', '21', 'SKIN GRAFTS FOR INJURIES', 2, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('440', '21', 'WOUND DEBRIDEMENTS FOR INJURIES', 2, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('441', '21', 'HAND PROCEDURES FOR INJURIES', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('442', '21', 'OTHER O.R PROCEDURES FOR INJURIES W CC', 3, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('443', '21', 'OTHER O.R PROCEDURES FOR INJURIES W/O CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('444', '21', 'TRAUMATIC INJURY AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('445', '21', 'TRAUMATIC INJURY AGE >17 W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('446', '21', 'TRAUMATIC INJURY AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('447', '21', 'ALLERGIC REACTIONS AGE >17', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('448', '21', 'ALLERGIC REACTIONS AGE 0-17', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('449', '21', 'POISON&TOXIC EFFECTS DRUGS AGE >17 W CC', 1, 3, '', '1', '08', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('450', '21', 'POISON&TOXIC EFFECTS DRUGS AGE >17 WO CC', 0, 2, '', '1', '08', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('451', '21', 'POISON&TOXIC EFFECTS DRUGS AGE 0-17', 0, 2, '', '1', '08', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('452', '21', 'COMPLICATIONS OF TREATMENT W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('453', '21', 'COMPLICATIONS OF TREATMENT W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('454', '21', 'OTH INJURY,POISON&TOXIC EFFECT DX W CC', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('455', '21', 'OTH INJURY,POISON&TOXIC EFFECT DX W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('461', '23', 'O.R. PROC W DX OTH CONTACT W HEALTH SERV', 1, 2, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('462', '23', 'REHABILITATION', 1, 10, '', '1', '09', 0, 999, 12, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('463', '23', 'SIGNS & SYMPTOMS W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('464', '23', 'SIGNS & SYMPTOMS W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('465', '23', 'AFTERCARE W HIST MALIG AS SECONDARY DX', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('466', '23', 'AFTERCARE W/O HIST MALIG AS SECONDARY DX', 1, 2, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('467', '23', 'OTHER FACTORS INFLUENCING HEALTH STATUS', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('468', '00', 'EXTENS O.R. PROC UNRELATED TO PRINC DX', 4, 11, '', '2', '02', 0, 999, 15, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('469', '00', 'PRINC DX INVALID AS DISCHARGE DIAGNOSIS', 0, 0, '', '0', '01', 0, 999, 0, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('470', '00', 'UNGROUPABLE', 0, 0, '', '0', '', 0, 999, 0, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('471', '08', 'BILAT OR MULT MAJ JOINT PROC, LOW EXTREM', 3, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('473', '17', 'ACU LEUKEMIA W/O MAJOR O.R PROC AGE >17', 4, 10, '', '2', '01', 0, 999, 15, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('475', '04', 'RESP SYSTEM DX WITH VENTILATOR SUPPORT', 4, 10, '', '1', '01', 0, 999, 13, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('476', '00', 'PROSTATIC O.R PROC UNRELATED TO PRINC DX', 2, 10, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('477', '00', 'NON-EXTEN O.R PROC UNRELATED TO PRINC DX', 2, 7, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('478', '05', 'OTHER VASCULAR PROCEDURES W CC', 2, 6, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('376', '14', 'POSTPART & POST ABORT DX W/O O.R. PROC', 0, 2, '', '1', '03', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('377', '14', 'POSTPART & POST ABORT DX W O.R. PROC', 2, 4, '', '2', '05', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('378', '14', 'ECTOPIC PREGNANCY', 1, 2, '', '1', '05', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('379', '14', 'THREATENED ABORTION', 0, 2, '', '1', '05', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('380', '14', 'ABORTION W/O D&C', 0, 2, '', '1', '05', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('381', '14', 'ABORTION W D&C,ASPIR CURETT,HYSTEROTOMY', 1, 2, '', '2', '05', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('382', '14', 'FALSE LABOR', 0, 1, '', '1', '05', 0, 999, 1, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('383', '14', 'OTH ANTEPARTUM DX W MEDICAL COMPLIC', 0, 3, '', '1', '05', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('384', '14', 'OTH ANTEPARTUM DX W/O MEDICAL COMPLIC', 0, 2, '', '1', '05', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('385', '15', 'NEONATES,DIED OR TRANS ACUTE CARE FACIL', 1, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('386', '15', 'EXTREME IMMATUR,RESP DIST SYND,NEONATE', 5, 18, '', '1', '06', 0, 999, 18, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('387', '15', 'PREMATURITY W MAJOR PROBLEMS', 3, 13, '', '1', '06', 0, 999, 13, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('388', '15', 'PREMATURITY W/O MAJOR PROBLEMS', 2, 9, '', '1', '06', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('389', '15', 'FULL TERM NEONATE W MAJOR PROBLEMS', 3, 9, '', '1', '06', 0, 999, 16, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('390', '15', 'NEONATE W OTHER SIGNIFICANT PROBLEMS', 1, 4, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('391', '15', 'NORMAL NEWBORN', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('392', '16', 'SPLENECTOMY AGE >17', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('393', '16', 'SPLENECTOMY AGE 0-17', 1, 9, '', '2', '06', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('394', '16', 'OTH O.R PROC OF BLOOD&BLOOD FORM ORGANS', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('395', '16', 'RED BLOOD CELL DISORDERS AGE >17', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('396', '16', 'RED BLOOD CELL DISORDERS AGE 0-17', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('397', '16', 'COAGULATION DISORDERS', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('398', '16', 'RETICULOENDOTHELIAL & IMMUN DISOR W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('399', '16', 'RETICULOENDOTHELIAL & IMMUN DISOR W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('400', '17', 'LYMPHOMA & LEUKEMIA W MAJOR O.R. PROC', 3, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('401', '17', 'LYMPHOMA&NONACU LEUK OTH O.R PROC W CC', 3, 10, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('402', '17', 'LYMPHOMA&NONACU LEUK OTH O.R PROC WO CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('403', '17', 'LYMPHOMA & NON-ACUTE LEUKEMIA W CC', 2, 7, '', '1', '01', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('404', '17', 'LYMPHOMA & NON-ACUTE LEUKEMIA W/O CC', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('405', '17', 'ACUTE LEUKEMIA W/O MAJ O.R PROC AGE 0-17', 2, 5, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('406', '17', 'MYEL DIS/PRLY DIF NEO&MAJ O.R.PROC W CC', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('407', '17', 'MYEL DIS,PRLY DIF NEO&MAJ O.R.PROC WO CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('408', '17', 'MYEL DIS,PRLY DIF NEO&OTH O.R.PROC', 2, 6, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('409', '17', 'RADIOTHERAPY', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('410', '17', 'CHEMOTHERAPY W/O ACUTE LUKEMIA AS SEC DX', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('411', '17', 'HISTORY OF MALIGNANCY W/O ENDOSCOPY', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('412', '17', 'HISTORY OF MALIGNANCY W ENDOSCOPY', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('413', '17', 'OTH MYEL DIS/POORLY DIFF NEOPL DX W CC', 1, 6, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('414', '17', 'OTH MYEL DIS/POORLY DIFF NEOPL DX WO CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('415', '18', 'O.R. PROC FOR INFECTIOUS & PARASITIC DIS', 4, 13, '', '2', '02', 0, 999, 16, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('416', '18', 'SEPTICEMIA AGE >17', 2, 6, '', '1', '06', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('417', '18', 'SEPTICEMIA AGE 0-17', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('418', '18', 'POSTOPERATIVE & POST-TRAUMATIC INFECTION', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('419', '18', 'FEVER OF UNKNOWN ORIGIN AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('420', '18', 'FEVER OF UNKNOWN ORIGIN AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('421', '18', 'VIRAL ILLNESS AGE >17', 1, 3, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('422', '18', 'VIRAL ILL&FEVER OF UNKNWN ORIG AGE 0-17', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('423', '18', 'OTH INFECTIOUS & PARASITIC DIS DIAGNOSES', 2, 7, '', '1', '02', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('424', '19', 'O.R PROC W PRINC DX OF MENTAL ILLNESS', 2, 11, '', '2', '07', 0, 999, 16, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('425', '19', 'ACU ADJ REACT & PSYCHOSOCIAL DYSFUNCTION', 1, 3, '', '1', '07', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('426', '19', 'DEPRESSIVE NEUROSES', 1, 4, '', '1', '07', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('427', '19', 'NEUROSES EXCEPT DEPRESSIVE', 1, 4, '', '1', '07', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('428', '19', 'DISORDERS OF PERSONALITY&IMPULSE CONTROL', 1, 5, '', '1', '07', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('429', '19', 'ORGANIC DISTURBANCES&MENTAL RETARDATION', 1, 5, '', '1', '07', 0, 999, 7, '1', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('430', '19', 'PSYCHOSES', 1, 7, '', '1', '07', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('431', '19', 'CHILDHOOD MENTAL DISORDERS', 1, 5, '', '1', '07', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('432', '19', 'OTHER MENTAL DISORDER DIAGNOSES', 1, 3, '', '1', '07', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('001', '01', 'CRANIOTOMY AGE >17 EXCEPT FOR TRAUMA', 3, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('002', '01', 'CRANIOTOMY FOR TRAUMA AGE >17', 3, 9, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('003', '01', 'CRANIOTOMY AGE 0-17', 2, 13, '', '2', '06', 0, 999, 13, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('004', '01', 'SPINAL PROCEDURES', 2, 6, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('005', '01', 'EXTRACRANIAL VASCULAR PROCEDURES', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('006', '01', 'CARPAL TUNNEL RELEASE', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('007', '01', 'PERIPH&CRAN NERV&OTH NERV SYS PROC W CC', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('008', '01', 'PERIPH&CRAN NERV&OTH NERV SYS PROC WO CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('009', '01', 'SPINAL DISORDERS & INJURIES', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('010', '01', 'NERVOUS SYSTEM NEOPLASMS W CC', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('011', '01', 'NERVOUS SYSTEM NEOPLASMS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('012', '01', 'DEGENERATIVE NERVOUS SYSTEM DISORDERS', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('013', '01', 'MULTIPLE SCLEROSIS & CEREBELLAR ATAXIA', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('014', '01', 'SPECIFIC CEREBROVASC DISORDERS EXC TIA', 1, 5, '', '1', '01', 0, 999, 6, '1', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('015', '01', 'TIA AND PRECEREBRAL OCCLUSIONS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('016', '01', 'NONSPECIFIC CEREBROVASC DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('017', '01', 'NONSPECIFIC CEREBROVASC DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('018', '01', 'CRANIAL & PERIPH NERVE DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('019', '01', 'CRANIAL & PERIPH NERVE DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('020', '01', 'NERV SYSTEM INFECT EXC VIRAL MENINGITIS', 3, 9, '', '1', '01', 0, 999, 11, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('021', '01', 'VIRAL MENINGITIS', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('022', '01', 'HYPERTENSIVE ENCEPHALOPATHY', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('023', '01', 'NONTRAUMATIC STUPOR & COMA', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('024', '01', 'SEIZURE & HEADACHE AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('025', '01', 'SEIZURE & HEADACHE AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('026', '01', 'SEIZURE & HEADACHE AGE 0-17', 1, 2, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('027', '01', 'TRAUMATIC STUPOR & COMA,COMA >1 HR', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('028', '01', 'TRAUM STUPOR&COMA,COMA<1 HR,AGE >17 W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('029', '01', 'TRAUM STUPOR&COMA,COMA<1HR,AGE>17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('030', '01', 'TRAUM STUPOR & COMA,COMA <1 HR,AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('031', '01', 'CONCUSSION AGE >17 WITH CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('032', '01', 'CONCUSSION AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('033', '01', 'CONCUSSION AGE 0-17', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('034', '01', 'OTHER DISORDERS OF NERVOUS SYSTEM W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('035', '01', 'OTHER DISORDERS OF NERVOUS SYSTEM W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('036', '02', 'RETINAL PROCEDURES', 1, 1, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('037', '02', 'ORBITAL PROCEDURES', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('038', '02', 'PRIMARY IRIS PROCEDURES', 0, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('039', '02', 'LENS PROCEDURES WITH OR W/O VITRECTOMY', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('040', '02', 'EXTRAOCULAR PROCS EXCEPT ORBIT AGE >17', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('041', '02', 'EXTRAOCULAR PROCS EXCEPT ORBIT AGE 0-17', 0, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('042', '02', 'INTRAOCULAR PROCS EXC RETINA,IRIS & LENS', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('043', '02', 'HYPHEMA', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('044', '02', 'ACUTE MAJOR EYE INFECTIONS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('045', '02', 'NEUROLOGICAL EYE DISORDERS', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('046', '02', 'OTHER DISORDERS OF THE EYE AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('047', '02', 'OTHER DISORDERS OF THE EYE AGE>17 W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('048', '02', 'OTHER DISORDERS OF THE EYE AGE 0-17', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('049', '03', 'MAJOR HEAD & NECK PROCEDURES', 2, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('050', '03', 'SIALOADENECTOMY', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('051', '03', 'SALIVARY GLAND PROCS EXC SIALOADENECTOMY', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('052', '03', 'CLEFT LIP & PALATE REPAIR', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('053', '03', 'SINUS & MASTOID PROCEDURES AGE >17', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('054', '03', 'SINUS & MASTOID PROCEDURES AGE 0-17', 0, 3, '', '2', '06', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('055', '03', 'MISC EAR,NOSE,MOUTH & THROAT PROCEDURES', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('056', '03', 'RHINOPLASTY', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('057', '03', 'T&A PROC,EX TONSLCT/ADNDCT ONLY AGE >17', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('058', '03', 'T&A PROC,EX TONSLCT/ADNDCT ONLY AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('059', '03', 'TONSILLECT &/OR ADENOIDECT ONLY AGE >17', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('060', '03', 'TONSILLECT &/OR ADENOIDECT ONLY AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('061', '03', 'MYRINGOTOMY W TUBE INSERTION AGE >17', 1, 3, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('062', '03', 'MYRINGOTOMY W TUBE INSERTION AGE 0-17', 0, 1, '', '2', '06', 0, 999, 1, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('063', '03', 'OTHER EAR,NOSE,MOUTH & THROAT O.R. PROCS', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('064', '03', 'EAR, NOSE, MOUTH & THROAT MALIGNANCY', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('065', '03', 'DYSEQUILIBRIUM', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('066', '03', 'EPISTAXIS', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('067', '03', 'EPIGLOTTITIS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('068', '03', 'OTITIS MEDIA & URI AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('069', '03', 'OTITIS MEDIA & URI AGE >17 W/O CC', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('070', '03', 'OTITIS MEDIA & URI AGE 0-17', 0, 2, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('071', '03', 'LARYNGOTRACHEITIS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('072', '03', 'NASAL TRAUMA & DEFORMITY', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('073', '03', 'OTH EAR,NOSE,MOUTH & THROAT DX AGE >17', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('074', '03', 'OTH EAR,NOSE,MOUTH & THROAT DX AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('075', '04', 'MAJOR CHEST PROCEDURES', 3, 9, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('076', '04', 'OTHER RESP SYSTEM O.R. PROCEDURES W CC', 3, 10, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('077', '04', 'OTHER RESP SYSTEM O.R. PROCEDURES W/O CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('078', '04', 'PULMONARY EMBOLISM', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('079', '04', 'RESP INFECT & INFLAM AGE >17 W CC', 2, 8, '', '1', '01', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('080', '04', 'RESP INFECT & INFLAM AGE >17 W/O CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('081', '04', 'RESP INFECT & INFLAM AGE 0-17', 2, 6, '', '1', '06', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('082', '04', 'RESPIRATORY NEOPLASMS', 1, 6, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('083', '04', 'MAJOR CHEST TRAUMA W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('084', '04', 'MAJOR CHEST TRAUMA W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('085', '04', 'PLEURAL EFFUSION W CC', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('086', '04', 'PLEURAL EFFUSION W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('087', '04', 'PULMONARY EDEMA & RESPIRATORY FAILURE', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('088', '04', 'CHRONIC OBSTRUCTIVE PULMONARY DISEASE', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('089', '04', 'SIMPLE PNEUMONIA & PLEURISY AGE >17 W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('090', '04', 'SIMPLE PNEUMONIA&PLEURISY AGE >17 W/O CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('091', '04', 'SIMPLE PNEUMONIA & PLEURISY AGE 0-17', 1, 4, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('092', '04', 'INTERSTITIAL LUNG DISEASE W CC', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('093', '04', 'INTERSTITIAL LUNG DISEASE W/O CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('094', '04', 'PNEUMOTHORAX WITH CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('095', '04', 'PNEUMOTHORAX W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('096', '04', 'BRONCHITIS & ASTHMA AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('097', '04', 'BRONCHITIS & ASTHMA AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('098', '04', 'BRONCHITIS & ASTHMA AGE 0-17', 1, 3, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('099', '04', 'RESPIRATORY SIGNS & SYMPTOMS W CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('100', '04', 'RESPIRATORY SIGNS & SYMPTOMS W/O CC', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('101', '04', 'OTHER RESP SYSTEM DIAGNOSES W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('102', '04', 'OTHER RESP SYSTEM DIAGNOSES W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('103', '05', 'HEART TRANSPLANT', 20, 39, '', '2', '02', 0, 999, 58, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('104', '05', 'CARD VALVE OTH MAJ CARDTHOR PROC W CATH', 8, 13, '', '2', '02', 0, 999, 15, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('105', '05', 'CARD VALVE OTH MAJ CARDTHOR PROC WO CATH', 6, 9, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('106', '05', 'CORONARY BYPASS WITH PTCA', 7, 11, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('107', '05', 'CORONARY BYPASS W CARDIAC CATH', 5, 10, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('108', '05', 'OTHER CARDIOTHORACIC PROCEDURES', 6, 9, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('109', '05', 'CORONARY BYPASS W/O PTCA OR CARDIAC CATH', 4, 7, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('110', '05', 'MAJOR CARDIOVASCULAR PROCS WITH CC', 4, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('111', '05', 'MAJOR CARDIOVASCULAR PROCS W/O CC', 2, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('113', '05', 'AMPUT FOR CIRC DISOR EXC UPPR LIMB & TOE', 3, 10, '', '2', '02', 0, 999, 13, '1', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('114', '05', 'UPPR LIMB & TOE AMPUT FOR CIRC DISOR', 2, 7, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('115', '05', 'PERM PMKR W AMI,HEART FAIL,SHCK,AICD,GN', 3, 7, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('116', '05', 'OTH PERMANENT CARDIAC PACEMAKER IMPLANT', 2, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('117', '05', 'CARD PACEMKR REVISION EXC DEVICE REPLACE', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('118', '05', 'CARDIAC PACEMAKER DEVICE REPLACEMENT', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('119', '05', 'VEIN LIGATION & STRIPPING', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('120', '05', 'OTHER CIRCULATORY SYSTEM O.R. PROCEDURES', 2, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('121', '05', 'CIRC DISOR W AMI & MAJ COMP DISCH ALIVE', 2, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('122', '05', 'CIRC DISOR W AMI WO MAJ COMP DISCH ALIVE', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('123', '05', 'CIRC DISOR W AMI, EXPIRED', 2, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('124', '05', 'CIRC DIS EX AMI W CARD CATH & COMPLX DX', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('125', '05', 'CIRC DIS EX AMI W CARD CATH WO COMPLX DX', 1, 2, '', '1', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('126', '05', 'ACUTE & SUBACUTE ENDOCARDITIS', 3, 10, '', '1', '01', 0, 999, 13, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('127', '05', 'HEART FAILURE & SHOCK', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('128', '05', 'DEEP VEIN THROMBOPHLEBITIS', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('129', '05', 'CARDIAC ARREST, UNEXPLAINED', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('130', '05', 'PERIPHERAL VASCULAR DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('131', '05', 'PERIPHERAL VASCULAR DISORDERS W/O CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('132', '05', 'ATHEROSCLEROSIS W CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('133', '05', 'ATHEROSCLEROSIS W/O CC', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('134', '05', 'HYPERTENSION', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('135', '05', 'CARD CONGEN & VALV DISOR AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('136', '05', 'CARD CONGEN & VALV DISOR AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('137', '05', 'CARD CONGEN & VALV DISOR AGE 0-17', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('138', '05', 'CARD ARRHYTHMIA & CONDUCTN DISOR W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('139', '05', 'CARD ARRHYTHMIA & CONDUCTN DISOR W/O CC', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('140', '05', 'ANGINA PECTORIS', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('141', '05', 'SYNCOPE & COLLAPSE W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('142', '05', 'SYNCOPE & COLLAPSE W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('143', '05', 'CHEST PAIN', 1, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('144', '05', 'OTH CIRCULATORY SYSTEM DIAGNOSES W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('145', '05', 'OTH CIRCULATORY SYSTEM DIAGNOSES W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('146', '06', 'RECTAL RESECTION W CC', 3, 10, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('147', '06', 'RECTAL RESECTION W/O CC', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('148', '06', 'MAJOR SMALL & LARGE BOWEL PROCS W CC', 4, 11, '', '2', '02', 0, 999, 13, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('149', '06', 'MAJOR SMALL & LARGE BOWEL PROCS W/O CC', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('150', '06', 'PERITONEAL ADHESIOLYSIS W CC', 3, 10, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('151', '06', 'PERITONEAL ADHESIOLYSIS W/O CC', 1, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('152', '06', 'MINOR SMALL & LARGE BOWEL PROCS W CC', 2, 7, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('153', '06', 'MINOR SMALL & LARGE BOWEL PROCS W/O CC', 1, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('154', '06', 'STOMACH,ESOPH & DUOD PROC AGE >17 W CC', 4, 12, '', '2', '02', 0, 999, 15, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('155', '06', 'STOMACH,ESOPH & DUOD PROC AGE >17 W/O CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('156', '06', 'STOMACH,ESOPH & DUOD PROC AGE 0-17', 1, 6, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('157', '06', 'ANAL & STOMAL PROCEDURES W CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('158', '06', 'ANAL & STOMAL PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('159', '06', 'HERNIA PROC EXC ING,FEMOR AGE >17 W CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('160', '06', 'HERNIA PROC EXC ING,FEMOR AGE >17 W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('161', '06', 'ING & FEMORAL HERNIA PROC AGE >17 W CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('162', '06', 'ING & FEMORAL HERNIA PROC AGE >17 W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('163', '06', 'HERNIA PROCEDURES AGE 0-17', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('164', '06', 'APPENDECTOMY W COMPLIC PRINC DX W CC', 2, 8, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('165', '06', 'APPENDECTOMY W COMPLIC PRINC DX W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('166', '06', 'APPENDECTOMY W/O COMPLIC PRINC DX W CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('167', '06', 'APPENDECTOMY W/O COMPLIC PRINC DX W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('168', '03', 'MOUTH PROCEDURES W CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('169', '03', 'MOUTH PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('170', '06', 'OTHER DIGESTIVE SYSTEM O.R. PROCS W CC', 3, 9, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('171', '06', 'OTHER DIGESTIVE SYSTEM O.R. PROCS W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('172', '06', 'DIGESTIVE MALIGNANCY W CC', 1, 6, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('173', '06', 'DIGESTIVE MALIGNANCY W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('174', '06', 'G.I. HEMORRHAGE W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('175', '06', 'G.I. HEMORRHAGE W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('176', '06', 'COMPLICATED PEPTIC ULCER', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('177', '06', 'UNCOMPLICATED PEPTIC ULCER W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('178', '06', 'UNCOMPLICATED PEPTIC ULCER W/O CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('179', '06', 'INFLAMMATORY BOWEL DISEASE', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('180', '06', 'G.I. OBSTRUCTION W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('181', '06', 'G.I. OBSTRUCTION W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('182', '06', 'ESPHGITIS,GE,MISC DIG DIS AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('183', '06', 'ESPHGITIS,GE,MISC DIG DIS AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('184', '06', 'ESPHGITIS,GE,MISC DIG DIS AGE 0-17', 0, 2, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('185', '03', 'DENT,ORAL DIS EX EXTRACT,RESTOR AGE >17', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('186', '03', 'DENT,ORAL DIS EX EXTRACT,RESTOR AGE 0-17', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('187', '03', 'DENTAL EXTRACTIONS & RESTORATIONS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('188', '06', 'OTHER DIGESTIVE SYSTEM DX AGE >17 W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('189', '06', 'OTHER DIGESTIVE SYSTEM DX AGE >17 W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('190', '06', 'OTHER DIGESTIVE SYSTEM DX AGE 0-17', 1, 4, '', '1', '06', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('191', '07', 'PANCREAS,LIVER & SHUNT PROCEDURES W CC', 5, 12, '', '2', '02', 0, 999, 16, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('192', '07', 'PANCREAS,LIVER & SHUNT PROCEDURES W/O CC', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('193', '07', 'BIL PROC W CC, EX ONLY CHOLCYST W/WO CDE', 4, 12, '', '2', '02', 0, 999, 14, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('194', '07', 'BIL PROC WO CC,EX ONLY CHOLCYST W/WO CDE', 2, 6, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('195', '07', 'CHOLECYSTECTOMY W C.D.E. W CC', 3, 9, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('196', '07', 'CHOLECYSTECTOMY W C.D.E. W/O CC', 2, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('197', '07', 'CHOLECYSTMY,EX LAPSCPC W/O C.D.E. W CC', 3, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('198', '07', 'CHOLECYSTMY,EX LAPSCPC W/O C.D.E. W/O CC', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('199', '07', 'HEPATOBIL DIAGNOSTIC PROC FOR MALIGNANCY', 3, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('200', '07', 'HEPATOBIL DIAGNOSTIC PROC FOR NON-MALIG', 3, 8, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('201', '07', 'OTHER HEPATOBIL OR PANCREAS O.R. PROC', 4, 12, '', '2', '02', 0, 999, 16, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('202', '07', 'CIRRHOSIS & ALCOHOLIC HEPATITIS', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('203', '07', 'MALIGNANCY OF HEPATOBIL SYST OR PANCREAS', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('204', '07', 'DISORDERS OF PANCREAS EXCEPT MALIGNANCY', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('205', '07', 'DISOR LIVER, EX MALIG,CIRR,ALC HEPA W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('206', '07', 'DISOR LIVER,EX MALIG,CIRR,ALC HEPA WO CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('207', '07', 'DISORDERS OF THE BILIARY TRACT W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('208', '07', 'DISORDERS OF THE BILIARY TRACT W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('209', '08', 'MAJ JOINT/LIMB REATTACH PROC, LOW EXTREM', 2, 5, '', '2', '02', 0, 999, 5, '2', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('210', '08', 'HIP&FEMUR PROC,EX MAJ JNT,AGE >17 W CC', 2, 6, '', '2', '02', 0, 999, 7, '2', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('211', '08', 'HIP&FEMUR PROC,EX MAJ JNT,AGE >17 W/O CC', 1, 5, '', '2', '02', 0, 999, 5, '2', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('212', '08', 'HIP&FEMUR PROC,EX MAJ JNT,AGE 0-17', 1, 11, '', '2', '06', 0, 999, 11, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('213', '08', 'AMPUT FOR MUSCSKL SYST & CONN TISS DISOR', 2, 8, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('216', '08', 'BIOPSIES OF MUSCSKL SYST & CONN TISSUE', 2, 8, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('217', '08', 'WND DBRD,SK GRFT EX HAND,MUSSKL,CONN TIS', 3, 11, '', '2', '02', 0, 999, 15, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('218', '08', 'LW EXT&HUM PROC,EX HIP,FT,FEM >17 W CC', 2, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('219', '08', 'LW EXT&HUM PROC,EX HIP,FT,FEM >17 W/O CC', 1, 3, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('220', '08', 'LW EXT&HUM PROC,EX HIP,FT,FEM 0-17', 1, 5, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('223', '08', 'MAJ SHLDR/ELBOW,OTH UPPR EXTR PROC W CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('224', '08', 'SHLDR,ELBW,FOREARM PROC,EX MAJ JNT WO CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('225', '08', 'FOOT PROCEDURES', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('226', '08', 'SOFT TISSUE PROCEDURES W CC', 2, 5, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('227', '08', 'SOFT TISSUE PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('228', '08', 'MAJ THUMB/JOINT/OTH HAND/WRIST PROC W CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('229', '08', 'HAND/WRIST PROC,EXC MAJ JNT PROC,W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('230', '08', 'LOC EXCIS,REMOV INT FIX DEV HIP,FEMUR', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('231', '08', 'LOC EXCIS,REMOV INT FIX DEV EX HIP,FEMUR', 1, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('232', '08', 'ARTHROSCOPY', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('233', '08', 'OTH MUSCSKL & CONN TISS O.R. PROC W CC', 2, 6, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('234', '08', 'OTH MUSCSKL & CONN TISS O.R. PROC W/O CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('235', '08', 'FRACTURES OF FEMUR', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('236', '08', 'FRACTURES OF HIP & PELVIS', 1, 4, '', '1', '01', 0, 999, 5, '1', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('237', '08', 'SPRAIN,STRAIN,DISLOC OF HIP,PELVIS,THIGH', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('238', '08', 'OSTEOMYELITIS', 1, 7, '', '1', '01', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('239', '08', 'PATH FX & MUSCSKL & CONNECT TISSUE MALIG', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('240', '08', 'CONNECTIVE TISSUE DISORDERS W CC', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('241', '08', 'CONNECTIVE TISSUE DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('242', '08', 'SEPTIC ARTHRITIS', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('243', '08', 'MEDICAL BACK PROBLEMS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('244', '08', 'BONE DIS & SPECIFIC ARTHROPATHIES W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('245', '08', 'BONE DIS & SPECIFIC ARTHROPATHIES W/O CC', 0, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('246', '08', 'NON-SPECIFIC ARTHROPATHIES', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('247', '08', 'SIGNS&SYMPTOMS OF MUSCSKL SYST&CONN TISS', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('248', '08', 'TENDONITIS, MYOSITIS & BURSITIS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('249', '08', 'AFTERCARE, MUSCSKL SYST & CONN TISSUE', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('250', '08', 'FX,SPR,STR,DSL FRARM,HAND,FT >17 W CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('251', '08', 'FX,SPR,STR,DSL FRARM,HAND,FT >17 W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('252', '08', 'FX,SPR,STR,DSL FRARM,HAND,FT 0-17', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('253', '08', 'FX,SPR,STR,DSL UARM,LWLG EX FT >17 W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('254', '08', 'FX,SPR,STR,DSL UARM,LWLG EX FT >17 WO CC', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('255', '08', 'FX,SPR,STR,DSL UARM,LWLG EX FT 0-17', 0, 3, '', '1', '06', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('256', '08', 'OTHER MUSCSKL SYST & CONN TISS DIAGNOSES', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('257', '09', 'TOTAL MASTECTOMY FOR MALIGNANCY W CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('258', '09', 'TOTAL MASTECTOMY FOR MALIGNANCY W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('259', '09', 'SUBTOT MASTECTOMY FOR MALIGNANCY W CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('260', '09', 'SUBTOT MASTECTOMY FOR MALIGNANCY W/O CC', 1, 1, '', '2', '02', 0, 999, 1, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('261', '09', 'BREAST PROC NON-MALIG,EX BIOP&LOC EXCIS', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('262', '09', 'BREAST BIOPSY & LOC EXCIS FOR NON-MALIG', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('263', '09', 'SKN GRFT/DEBRID,SKN ULCR,CELLULIT W CC', 2, 9, '', '2', '02', 0, 999, 12, '1', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('264', '09', 'SKN GRFT/DEBRID,SKN ULCR,CELLULIT W/O CC', 1, 6, '', '2', '02', 0, 999, 7, '1', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('265', '09', 'SKN GRFT/DEBRID,EX SKN ULCR,CELLUL W CC', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('266', '09', 'SKN GRFT/DEBRID,EX SKN ULCR,CELLUL WO CC', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('267', '09', 'PERIANAL & PILONIDAL PROCEDURES', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('268', '09', 'SKIN,SUBCUT TISSUE&BREAST PLASTIC PROC', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('269', '09', 'OTH SKIN,SUBCUT TISS&BREAST PROC W CC', 2, 7, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('270', '09', 'OTH SKIN,SUBCUT TISS&BREAST PROC W/O CC', 1, 2, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('271', '09', 'SKIN ULCERS', 1, 6, '', '1', '01', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('272', '09', 'MAJOR SKIN DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('273', '09', 'MAJOR SKIN DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('274', '09', 'MALIGNANT BREAST DISORDERS W CC', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('275', '09', 'MALIGNANT BREAST DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('276', '09', 'NON-MALIGNANT BREAST DISORDERS', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('277', '09', 'CELLULITIS AGE >17 W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('278', '09', 'CELLULITIS AGE >17 W/O CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('279', '09', 'CELLULITIS AGE 0-17', 1, 4, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('280', '09', 'TRAUMA SKN,SUBCUT TIS&BREAST AGE>17 W CC', 1, 4, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('281', '09', 'TRAUMA SKN,SUBCU TIS&BREAST AGE>17 WO CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('282', '09', 'TRAUMA SKN,SUBCUT TISS&BREAST AGE 0-17', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('283', '09', 'MINOR SKIN DISORDERS W CC', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('284', '09', 'MINOR SKIN DISORDERS W/O CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('285', '10', 'AMPUT LOWR LIMB ENDOCR,NUTR,METAB DISOR', 2, 9, '', '2', '02', 0, 999, 11, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('286', '10', 'ADRENAL & PITUITARY PROCEDURES', 2, 5, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('287', '10', 'SKN GRFT,WND DBRD ENDOC,NUTR,METAB DISOR', 2, 9, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('288', '10', 'O.R. PROCEDURES FOR OBESITY', 2, 5, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('289', '10', 'PARATHYROID PROCEDURES', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('290', '10', 'THYROID PROCEDURES', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('291', '10', 'THYROGLOSSAL PROCEDURES', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('292', '10', 'OTH ENDOCR,NUTRIT,METAB O.R. PROC W CC', 3, 9, '', '2', '02', 0, 999, 12, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('293', '10', 'OTH ENDOCR,NUTRIT,METAB O.R. PROC W/O CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('294', '10', 'DIABETES AGE >35', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('295', '10', 'DIABETES AGE 0-35', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('296', '10', 'NUTRIT & MISC METAB DISOR AGE >17 W CC', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('297', '10', 'NUTRIT & MISC METAB DISOR AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('298', '10', 'NUTRIT & MISC METAB DISOR AGE 0-17', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('299', '10', 'INBORN ERRORS OF METABOLISM', 1, 4, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('300', '10', 'ENDOCRINE DISORDERS W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('301', '10', 'ENDOCRINE DISORDERS W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('302', '11', 'KIDNEY TRANSPLANT', 3, 8, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('303', '11', 'KIDNEY,URETR & MAJ BLADDR PROC FOR NEOPL', 2, 8, '', '2', '02', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('304', '11', 'KIDNY,URETR&MAJ BLADDR PROC NONNEO W CC', 2, 7, '', '2', '02', 0, 999, 10, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('305', '11', 'KIDNY,URETR&MAJ BLADDR PROC NONNEO WO CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('306', '11', 'PROSTATECTOMY W CC', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('307', '11', 'PROSTATECTOMY W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('308', '11', 'MINOR BLADDER PROCEDURES W CC', 2, 5, '', '2', '02', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('309', '11', 'MINOR BLADDER PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('310', '11', 'TRANSURETHRAL PROCEDURES W CC', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('311', '11', 'TRANSURETHRAL PROCEDURES W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('312', '11', 'URETHRAL PROCEDURES, AGE >17 W CC', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('313', '11', 'URETHRAL PROCEDURES, AGE >17 W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('314', '11', 'URETHRAL PROCEDURES, AGE 0-17', 0, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('315', '11', 'OTHER KIDNEY & URINARY TRACT O.R. PROCS', 2, 5, '', '2', '02', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('316', '11', 'RENAL FAILURE', 1, 6, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('317', '11', 'ADMIT FOR RENAL DIALYSIS', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('318', '11', 'KIDNEY & URINARY TRACT NEOPLASMS W CC', 1, 5, '', '1', '01', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('319', '11', 'KIDNEY & URINARY TRACT NEOPLASMS W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('320', '11', 'KIDNEY,URIN TRACT INFECT AGE >17 W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('321', '11', 'KIDNEY,URIN TRACT INFECT AGE >17 W/O CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('322', '11', 'KIDNEY,URIN TRACT INFECT AGE 0-17', 1, 4, '', '1', '06', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('323', '11', 'URINARY STONES W CC,&/OR ESW LITHOTRIPSY', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('324', '11', 'URINARY STONES W/O CC', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('325', '11', 'KIDNY,URIN TRACT SIGN,SYMP AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('326', '11', 'KIDNY,URIN TRACT SIGN,SYMP AGE >17 WO CC', 0, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('327', '11', 'KIDNY,URIN TRACT SIGN,SYMP AGE 0-17', 0, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('328', '11', 'URETHRAL STRICTURE AGE >17 W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('329', '11', 'URETHRAL STRICTURE AGE >17 W/O CC', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('330', '11', 'URETHRAL STRICTURE AGE 0-17', 0, 2, '', '1', '06', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('331', '11', 'OTH KIDNEY & URIN TRACT DX AGE >17 W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('332', '11', 'OTH KIDNEY & URIN TRACT DX AGE >17 WO CC', 1, 3, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('333', '11', 'OTH KIDNEY & URIN TRACT DX AGE 0-17', 1, 4, '', '1', '06', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('334', '12', 'MAJOR MALE PELVIC PROCEDURES W CC', 2, 4, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('335', '12', 'MAJOR MALE PELVIC PROCEDURES W/O CC', 1, 3, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('336', '12', 'TRANSURETHRAL PROSTATECTOMY W CC', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('337', '12', 'TRANSURETHRAL PROSTATECTOMY W/O CC', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('338', '12', 'TESTES PROCEDURES, FOR MALIGNANCY', 1, 4, '', '2', '02', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('339', '12', 'TESTES PROCEDURES, NON-MALIG AGE >17', 1, 3, '', '2', '02', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('340', '12', 'TESTES PROCEDURES, NON-MALIG AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('341', '12', 'PENIS PROCEDURES', 1, 2, '', '2', '06', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('342', '12', 'CIRCUMCISION AGE >17', 1, 2, '', '2', '02', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('343', '12', 'CIRCUMCISION AGE 0-17', 0, 2, '', '2', '06', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('344', '12', 'OTH MALE REPRO SYST O.R. PROCS FOR MALIG', 1, 2, '', '2', '02', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('345', '12', 'OTH MALE REPRO SYST O.R. PROCS EX MALIG', 1, 3, '', '2', '02', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('346', '12', 'MALIGNANCY, MALE REPRO SYSTEM, W CC', 1, 5, '', '1', '01', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('347', '12', 'MALIGNANCY, MALE REPRO SYSTEM, W/O CC', 1, 2, '', '1', '01', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('348', '12', 'BENIGN PROSTATIC HYPERTROPHY W CC', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('349', '12', 'BENIGN PROSTATIC HYPERTROPHY W/O CC', 0, 2, '', '1', '01', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('350', '12', 'INFLAMMATION OF THE MALE REPRO SYSTEM', 1, 4, '', '1', '01', 0, 999, 5, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('351', '12', 'STERILIZATION, MALE', 0, 1, '', '1', '02', 0, 999, 1, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('352', '12', 'OTHER MALE REPRODUCTIVE SYSTEM DIAGNOSES', 1, 3, '', '1', '01', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('353', '13', 'PELVIC EVISC,RAD HYSTERECT & RAD VULVECT', 2, 5, '', '2', '05', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('354', '13', 'UTER,ADNEX PROC NON-OV/ADNEX MALIG W CC', 2, 5, '', '2', '05', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('355', '13', 'UTER,ADNEX PROC NON-OV/ADNEX MALIG WO CC', 1, 3, '', '2', '05', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('356', '13', 'FEMALE REPRO SYSTEM RECONSTRUCTIVE PROCS', 1, 2, '', '2', '05', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('357', '13', 'UTER&ADNEX PROC FOR OVAR,ADNEXAL MALIG', 2, 8, '', '2', '05', 0, 999, 9, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('358', '13', 'UTER&ADNEX PROC FOR NON-MALIG W CC', 1, 4, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('359', '13', 'UTER&ADNEX PROC FOR NON-MALIG W/O CC', 1, 3, '', '2', '05', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('360', '13', 'VAGINA, CERVIX & VULVA PROCEDURES', 1, 2, '', '2', '05', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('361', '13', 'LAPAROSCOPY & INCISIONAL TUBAL INTERRUPT', 1, 2, '', '2', '05', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('362', '13', 'ENDOSCOPIC TUBAL INTERRUPTION', 0, 1, '', '2', '05', 0, 999, 1, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('363', '13', 'D&C,CONIZATION&RADIO-IMPLANT, FOR MALIG', 1, 3, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('364', '13', 'D&C,CONIZATION EXCEPT FOR MALIGNANCY', 1, 3, '', '2', '05', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('365', '13', 'OTHER FEMALE REPRO SYSTEM O.R. PROC', 2, 6, '', '2', '05', 0, 999, 8, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('366', '13', 'MALIGNANCY, FEMALE REPRO SYSTEM W CC', 1, 6, '', '1', '05', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('367', '13', 'MALIGNANCY, FEMALE REPRO SYSTEM W/O CC', 1, 2, '', '1', '05', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('368', '13', 'INFECTIONS, FEMALE REPRODUCTIVE SYSTEM', 1, 6, '', '1', '05', 0, 999, 7, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('369', '13', 'MENSTRUAL&OTHER FEMALE REPRO SYST DISOR', 1, 2, '', '1', '05', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('370', '14', 'CESAREAN SECTION W CC', 1, 5, '', '2', '04', 0, 999, 6, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('371', '14', 'CESAREAN SECTION W/O CC', 1, 3, '', '2', '04', 0, 999, 4, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('372', '14', 'VAGINAL DELIVERY W COMPLIC DIAGNOSES', 1, 3, '', '1', '03', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('373', '14', 'VAGINAL DELIVERY W/O COMPLIC DIAGNOSES', 0, 2, '', '1', '03', 0, 999, 2, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('374', '14', 'VAGINAL DELIVERY W STERIL &/OR D&C', 1, 2, '', '2', '03', 0, 999, 3, '0', 'HCFA', 'J')

insert into ActiveAdvice.dbo.DRGCode (DRGcode, MDC, DRGtitle, DRGweight, DRGMeanLOS, DRGgroup, DRGcategory, DRGserviceclass, DRGlowtrim, DRGhightrim, DRGnewmeanLOS, DRGtop20, DRGType, DRGversion)
    VALUES('375', '14', 'VAG DELIV W O.R. PROC EX STERIL &/OR D&C', 1, 2, '', '2', '03', 0, 999, 2, '0', 'HCFA', 'J')

