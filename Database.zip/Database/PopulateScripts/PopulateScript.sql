/* This script populates SecurityFALevels table with the required Functional Access Levels */

INSERT INTO SecurityFALevels (FALevelName)
VALUES ('File Maintenance')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Code Tables')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Intake')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Patient summary')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Patient information')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Problems')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Events')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Reviews')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Diagnostics & Procedures')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Referrals')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Clinical Management service')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Care Management')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Maternichek')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Workers compensation')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Guidelines')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Reports')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Contacts')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Worklists')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Activities')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Notes')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('System Administratin & Utilities')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Plan')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Provider')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Letter Setup')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Letter generate batch')
GO
INSERT INTO SecurityFALevels (FALevelName)
VALUES ('Letter send')
GO



